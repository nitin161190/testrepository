package com.wayfair.registration.api.config;

import feign.Retryer;

public class FeignClientRetryer extends Retryer.Default {
  public FeignClientRetryer() {
    super(1000, 9000, 3);
  }
}
