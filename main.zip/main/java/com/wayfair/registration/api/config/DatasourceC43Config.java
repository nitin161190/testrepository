package com.wayfair.registration.api.config;

import com.zaxxer.hikari.HikariDataSource;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(
    entityManagerFactoryRef = "c43EntityManager",
    transactionManagerRef = "c43TransactionManager"
)
public class DatasourceC43Config {

  @Value("${spring.jpa.properties.hibernate.dialect}")
  private String dialect;

  @Value("${spring.jpa.properties.hibernate.default_schema}")
  private String defaultSchema;

  @Bean("c43EntityManager")
  public LocalContainerEntityManagerFactoryBean c4EntityManager(
      @Qualifier("c43HikariDataSource") DataSource dataSource) {
    LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(dataSource);
    em.setPackagesToScan("com.wayfair.registration.api.domain.entity", "com.wayfair.registration.api.request.entity");
    em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
    em.setJpaPropertyMap(Map.of(
        "hibernate.dialect", dialect,
        "hibernate.default_schema", defaultSchema));

    return em;
  }

  @Bean("c43DataSourceProperties")
  @ConfigurationProperties(prefix = "spring.datasources.c43")
  public DataSourceProperties c4DataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean("c43HikariDataSource")
  public HikariDataSource c4HikariDataSource(@Qualifier("c43DataSourceProperties") DataSourceProperties properties) {
    return properties.initializeDataSourceBuilder().type(HikariDataSource.class)
        .build();
  }

  @Bean("c43TransactionManager")
  public PlatformTransactionManager c4TransactionManager(
      @Qualifier("c43EntityManager") LocalContainerEntityManagerFactoryBean entityManagerFactoryBean) {
    JpaTransactionManager transactionManager = new JpaTransactionManager();
    transactionManager.setEntityManagerFactory(entityManagerFactoryBean.getObject());
    return transactionManager;
  }

  @Bean(name = "c43DataSourceTransactionManager")
  @Autowired
  public DataSourceTransactionManager c4DataSourceTransactionManager(
      @Qualifier("c43HikariDataSource") DataSource datasource) {
    return new DataSourceTransactionManager(datasource);
  }
}
