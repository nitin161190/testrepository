package com.wayfair.registration.api.config;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import javax.persistence.AttributeConverter;
import lombok.NoArgsConstructor;

@NoArgsConstructor
public class OffsetDateTimeConverter implements AttributeConverter<OffsetDateTime, String> {

  private static final String MSSQL_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss.SSSSS ZZZZZ";

  @Override
  public String convertToDatabaseColumn(OffsetDateTime offsetDateTime) {
    if (offsetDateTime == null) {
      return null;
    }

    return DateTimeFormatter.ofPattern(MSSQL_DATE_FORMAT).format(offsetDateTime);
  }

  @Override
  public OffsetDateTime convertToEntityAttribute(String dateAsString) {
    if (dateAsString == null) {
      return null;
    }

    return OffsetDateTime.parse(dateAsString, DateTimeFormatter.ofPattern(MSSQL_DATE_FORMAT));
  }

}