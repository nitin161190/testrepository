package com.wayfair.registration.api.config;

import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;
import org.springframework.http.HttpStatus;

public class FeignClientErrorDecoder implements ErrorDecoder {

  private static final int INTERNAL_SERVER_ERROR = HttpStatus.INTERNAL_SERVER_ERROR.value();

  private final ErrorDecoder defaultErrorDecoder = new Default();

  @Override
  public Exception decode(String s, Response response) {

    if (response.status() >= INTERNAL_SERVER_ERROR) {
      return new RetryableException(response.status(), response.reason(), response.request().httpMethod(),
          null, response.request());
    }

    return defaultErrorDecoder.decode(s, response);
  }
}
