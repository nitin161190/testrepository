package com.wayfair.registration.api.config;

import com.zaxxer.hikari.HikariDataSource;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(basePackages = {
    "com.wayfair.registration.api.purchaseorder",
    "com.wayfair.registration.api.bulkregistration"},
    entityManagerFactoryRef = "c149EntityManager",
    transactionManagerRef = "c149TransactionManager")
public class DatasourceC149Config {

  @Value("${spring.jpa.properties.hibernate.dialect}")
  private String dialect;

  @Value("${spring.jpa.properties.hibernate.default_schema}")
  private String defaultSchema;

  @Primary
  @Bean("c149EntityManager")
  public LocalContainerEntityManagerFactoryBean c149EntityManager(
      @Qualifier("c149HikariDataSource") DataSource dataSource
  ) {
    LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(dataSource);
    em.setPackagesToScan(
        "com.wayfair.registration.api.purchaseorder.entity",
        "com.wayfair.registration.api.bulkregistration.entity"
    );
    em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
    em.setJpaPropertyMap(
        Map.of(
            "hibernate.dialect", dialect,
            "hibernate.default_schema", defaultSchema,
            "hibernate.jdbc.batch_size", 20,
            "hibernate.order_inserts", true,
            "hibernate.order_updates", true
        )
    );

    return em;
  }

  @Primary
  @Bean("c149DataSourceProperties")
  @ConfigurationProperties(prefix = "spring.datasources.c149")
  public DataSourceProperties c149DataSourceProperties() {
    return new DataSourceProperties();
  }

  @Primary
  @Bean("c149HikariDataSource")
  public HikariDataSource c149HikariDataSource(
      @Qualifier("c149DataSourceProperties") DataSourceProperties properties
  ) {
    return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
  }

  @Primary
  @Bean("c149TransactionManager")
  public PlatformTransactionManager c149TransactionManager(
      @Qualifier("c149EntityManager")
      LocalContainerEntityManagerFactoryBean entityManagerFactoryBean
  ) {
    JpaTransactionManager transactionManager = new JpaTransactionManager();
    transactionManager.setEntityManagerFactory(entityManagerFactoryBean.getObject());
    return transactionManager;
  }

  @Bean(name = "c149DataSourceTransactionManager")
  @Autowired
  public DataSourceTransactionManager c149DataSourceTransactionManager(
      @Qualifier("c149HikariDataSource") DataSource datasource
  ) {
    return new DataSourceTransactionManager(datasource);
  }
}
