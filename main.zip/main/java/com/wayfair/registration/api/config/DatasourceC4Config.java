package com.wayfair.registration.api.config;

import com.zaxxer.hikari.HikariDataSource;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableJpaRepositories(
    basePackages = {
        "com.wayfair.registration.api.orderproduct",
        "com.wayfair.registration.api.request"},
    entityManagerFactoryRef = "c4EntityManager",
    transactionManagerRef = "c4TransactionManager"
)
public class DatasourceC4Config {

  @Value("${spring.jpa.properties.hibernate.dialect}")
  private String dialect;

  @Value("${spring.jpa.properties.hibernate.default_schema}")
  private String defaultSchema;

  @Bean("c4EntityManager")
  public LocalContainerEntityManagerFactoryBean c4EntityManager(
      @Qualifier("c4HikariDataSource") DataSource dataSource) {
    LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
    em.setDataSource(dataSource);
    em.setPackagesToScan(
        "com.wayfair.registration.api.domain.entity",
        "com.wayfair.registration.api.request.entity",
        "com.wayfair.registration.api.purchaseorder.documents.ucc"
    );
    em.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
    em.setJpaPropertyMap(Map.of(
        "hibernate.dialect", dialect,
        "hibernate.default_schema", defaultSchema));

    return em;
  }

  @Bean("c4DataSourceProperties")
  @ConfigurationProperties(prefix = "spring.datasources.c4")
  public DataSourceProperties c4DataSourceProperties() {
    return new DataSourceProperties();
  }

  @Bean("c4HikariDataSource")
  public HikariDataSource c4HikariDataSource(@Qualifier("c4DataSourceProperties") DataSourceProperties properties) {
    return properties.initializeDataSourceBuilder().type(HikariDataSource.class)
        .build();
  }

  @Bean("c4TransactionManager")
  public PlatformTransactionManager c4TransactionManager(
      @Qualifier("c4EntityManager") LocalContainerEntityManagerFactoryBean entityManagerFactoryBean) {
    JpaTransactionManager transactionManager = new JpaTransactionManager();
    transactionManager.setEntityManagerFactory(entityManagerFactoryBean.getObject());
    return transactionManager;
  }

  @Bean(name = "c4DataSourceTransactionManager")
  @Autowired
  public DataSourceTransactionManager c4DataSourceTransactionManager(
      @Qualifier("c4HikariDataSource") DataSource datasource) {
    return new DataSourceTransactionManager(datasource);
  }
}
