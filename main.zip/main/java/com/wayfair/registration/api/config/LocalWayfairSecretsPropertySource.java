package com.wayfair.registration.api.config;

import com.wayfair.crypto.Passwords;
import java.nio.file.Files;
import java.nio.file.Path;
import lombok.SneakyThrows;
import org.springframework.core.env.PropertySource;

public class LocalWayfairSecretsPropertySource extends PropertySource<Path> {
  private static final String PREFIX = "wayfair.secrets.";

  public LocalWayfairSecretsPropertySource(Path wayfairDir) {
    super(PREFIX, wayfairDir);
  }

  @SneakyThrows
  @Override
  public String getProperty(String name) {
    if (!name.startsWith(PREFIX)) {
      return null;
    }

    if (!Files.isDirectory(source)) {
      throw new IllegalStateException(String.format(
          "Trying to resolve %s, but couldn't find the wayfair directory at %s. "
          + "Do you need to configure WF_CREDENTIALS_PATH?",
          name,
          source));
    }

    return Passwords.get(
        name.substring(PREFIX.length()), source.resolve("") + "/", null);
  }
}
