package com.wayfair.registration.api.config;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsRuntimeWiring;
import com.wayfair.registration.api.graphql.scalars.CustomDateTimeScalar;
import graphql.schema.GraphQLScalarType;
import graphql.schema.idl.RuntimeWiring;

@DgsComponent
public class GraphQLScalars {

  @DgsRuntimeWiring
  public RuntimeWiring.Builder addScalar(RuntimeWiring.Builder builder) {
    return builder.scalar(GraphQLScalarType.newScalar()
        .name("DateTime")
        .coercing(new CustomDateTimeScalar())
        .build());
  }
}
