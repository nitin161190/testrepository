package com.wayfair.registration.api.config;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import org.springframework.boot.context.event.ApplicationEnvironmentPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;

public class LocalConfigurationApplicationContextInitializer
    implements ApplicationListener<ApplicationEnvironmentPreparedEvent> {

  private static final String WF_CREDENTIALS_PATH_ENV_VAR = "WF_CREDENTIALS_PATH";
  private static final String LOCAL_PROFILE = "local";

  @Override
  public void onApplicationEvent(ApplicationEnvironmentPreparedEvent applicationEnvironmentPreparedEvent) {
    ConfigurableEnvironment environment = applicationEnvironmentPreparedEvent.getEnvironment();

    if (Arrays.asList(environment.getActiveProfiles()).contains(LOCAL_PROFILE)) {
      MutablePropertySources propertySources = environment.getPropertySources();

      Path wayfairDir = Paths.get(System.getenv(WF_CREDENTIALS_PATH_ENV_VAR));

      propertySources.addLast(new LocalWayfairSecretsPropertySource(wayfairDir));
    }
  }
}