package com.wayfair.registration.api.service;

import com.wayfair.toggles.ToggleController;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class FeatureToggleService {
  private final ToggleController toggleController;
  private final int defaultStoreId;

  public FeatureToggleService(
      ToggleController toggleController,
      @Value("${wayfair.toggles.defaultStoreId}") int defaultStoreId
  ) {
    this.toggleController = toggleController;
    this.defaultStoreId = defaultStoreId;
  }

  public boolean isEnabled(String featureToggleName, boolean defaultValue) {
    try {
      return toggleController.isEnabled(featureToggleName, defaultStoreId, defaultValue);
    } catch (Exception ex) {
      log.warn("Toggle controller threw an exception, returning default value {}", defaultValue, ex);
      return defaultValue;
    }
  }
}

