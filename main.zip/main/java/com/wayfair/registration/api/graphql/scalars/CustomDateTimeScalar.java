package com.wayfair.registration.api.graphql.scalars;

import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;

public class CustomDateTimeScalar implements Coercing<CustomDateTime, String> {
  @Override
  public String serialize(Object dataFetcherResult) throws CoercingSerializeException {
    if (dataFetcherResult instanceof CustomDateTime) {
      return ((CustomDateTime) dataFetcherResult).getOffsetDateTime();
    }
    throw new CoercingSerializeException("Unsupported type " + dataFetcherResult.getClass());
  }

  @Override
  public CustomDateTime parseValue(Object input) throws CoercingParseValueException {
    var ourFancyDateTime = new CustomDateTime();
    ourFancyDateTime.setOffsetDateTime(input.toString());
    return ourFancyDateTime;
  }

  @Override
  public CustomDateTime parseLiteral(Object input) throws CoercingParseLiteralException {
    if (input instanceof StringValue) {
      var ourFancyDateTime = new CustomDateTime();
      ourFancyDateTime.setOffsetDateTime(((StringValue) input).getValue());
      return ourFancyDateTime;
    }

    throw new CoercingParseLiteralException("Value is not a valid ISO date time");
  }
}
