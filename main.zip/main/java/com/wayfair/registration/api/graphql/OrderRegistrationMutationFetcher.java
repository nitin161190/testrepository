package com.wayfair.registration.api.graphql;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsMutation;
import com.netflix.graphql.dgs.InputArgument;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersPayload;
import com.wayfair.registration.api.purchaseorder.PurchaseOrderService;
import com.wayfair.registration.api.util.MdcUtil;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestHeader;

@DgsComponent
@RequiredArgsConstructor
public class OrderRegistrationMutationFetcher {

  static final String HEADER_USER_ID = "X-SUPPLIER-USER-ID";

  private final PurchaseOrderService purchaseOrderService;

  @DgsMutation
  @PreAuthorize("@auth.userCanAccessSupplier(#userId, #input.getSupplierId())")
  public SoOrderManagementRegisterOrdersPayload soOrderManagementRegisterOrders(
      @InputArgument("input") SoOrderManagementRegisterOrdersInput input,
      @RequestHeader(HEADER_USER_ID) String userId
  ) {
    MdcUtil.init(input);

    SoOrderManagementRegisterOrdersPayload soOrderManagementRegisterOrdersPayload =
        purchaseOrderService.bulkRegistration(input, null, Integer.valueOf(userId));

    MDC.clear();
    return soOrderManagementRegisterOrdersPayload;
  }
}
