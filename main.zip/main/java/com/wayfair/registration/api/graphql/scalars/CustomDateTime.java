package com.wayfair.registration.api.graphql.scalars;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import lombok.Data;

@Data
public class CustomDateTime {
  private String offsetDateTime;

  public static CustomDateTime from(OffsetDateTime offsetDateTime) {
    var ourFancyDateTime = new CustomDateTime();
    ourFancyDateTime.setOffsetDateTime(offsetDateTime.toString());
    return ourFancyDateTime;
  }

  public String getOffsetDateTime() {
    return offsetDateTime;
  }

  public LocalDate toLocalDate() {
    return parse().toLocalDate();
  }

  public LocalDateTime toLocalDateTime() {
    return parse().toLocalDateTime();
  }

  private OffsetDateTime parse() {
    return OffsetDateTime.parse(offsetDateTime);
  }
}
