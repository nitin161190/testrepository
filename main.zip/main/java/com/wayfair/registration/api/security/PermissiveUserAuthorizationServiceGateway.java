package com.wayfair.registration.api.security;

import java.util.Set;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Permits all request it receives. Useful for local application runs.
 */
@Profile("user-authorization.permissive")
@Component
@Slf4j
public class PermissiveUserAuthorizationServiceGateway implements UserAuthorizationServiceGateway {
  static final Set<Integer> BLOCK_USER_IDS = Set.of(1);

  @Override
  public boolean isAuthorizedToReadWriteSupplier(Integer userId, Integer supplierId) {
    if (BLOCK_USER_IDS.contains(userId)) {
      log.warn("User {} not authorized for read/write access to supplier {}!", userId, supplierId);
      return false;
    }
    log.warn("Authorizing user {} to read/write supplier {}.", userId, supplierId);
    return true;
  }
}
