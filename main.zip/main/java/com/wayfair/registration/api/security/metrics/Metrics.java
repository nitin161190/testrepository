package com.wayfair.registration.api.security.metrics;

import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import io.micrometer.core.instrument.Timer;
import java.util.List;
import java.util.function.Supplier;
import org.springframework.stereotype.Component;

@Component
public class Metrics {
  private static final String EXCEPTION_TAG = "exception";
  private static final String USER_AUTH_PREFIX = "user_authorization.";
  private static final String USER_AUTH_SERVICE_TIME = USER_AUTH_PREFIX + "service_time";
  private static final String USER_AUTH_SERVICE_FAILURE = USER_AUTH_PREFIX + "service_failure";
  private static final String USER_AUTH_FAILURE = USER_AUTH_PREFIX + "failure";
  private static final String USER_AUTH_FAILURE_TYPE_TAG = "type";
  private static final String USER_AUTH_SERVICE_FAILURE_EXCEPTION_TAG = EXCEPTION_TAG;
  private static final String USER_AUTH_SERVICE_FAILURE_EXCEPTION_MSG_TAG = "exception_msg";
  private static final String USER_TAG = "user";
  private static final String SUPPLIER_TAG = "supplier";

  private final MeterRegistry meterRegistry;
  private final Timer userAuthServiceTimer;

  public Metrics(MeterRegistry meterRegistry) {
    this.meterRegistry = meterRegistry;
    userAuthServiceTimer = Timer.builder(USER_AUTH_SERVICE_TIME)
        .publishPercentileHistogram()
        .register(meterRegistry);
  }

  public <T> T timeUserAuthorizationServiceRequest(Supplier<T> request) {
    return userAuthServiceTimer.record(request);
  }

  public void recordUserAuthorizationServiceFailure(Exception e) {
    var tags = List.of(
        Tag.of(USER_AUTH_SERVICE_FAILURE_EXCEPTION_TAG, e.getClass().getSimpleName()),
        Tag.of(USER_AUTH_SERVICE_FAILURE_EXCEPTION_MSG_TAG, e.getMessage() != null ? e.getMessage() : "none")
    );
    meterRegistry.counter(USER_AUTH_SERVICE_FAILURE, tags).increment();
  }

  public void recordUserAuthorizationFailure(String userId, String supplierId) {
    var tags = List.of(
        Tag.of(USER_AUTH_FAILURE_TYPE_TAG, UserAuthorizationFailureType.FORBIDDEN.name()),
        Tag.of(USER_TAG, userId),
        Tag.of(SUPPLIER_TAG, supplierId)
    );
    meterRegistry.counter(USER_AUTH_FAILURE, tags).increment();
  }

  public enum UserAuthorizationFailureType {
    FORBIDDEN, USER_NOT_FOUND, UNKNOWN
  }
}
