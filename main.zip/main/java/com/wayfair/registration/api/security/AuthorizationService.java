package com.wayfair.registration.api.security;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service("auth")
@Slf4j
public class AuthorizationService {
  private final UserAuthorizationServiceGateway userServiceGateway;

  public AuthorizationService(UserAuthorizationServiceGateway userServiceGateway) {
    this.userServiceGateway = userServiceGateway;
  }

  /**
   * Whether the {@code userId} is permitted access to {@code supplierId}'s data.
   */
  public boolean userCanAccessSupplier(Integer userId, Integer supplierId) {
    try {
      return userServiceGateway.isAuthorizedToReadWriteSupplier(userId, supplierId);
    } catch (Exception e) {
      log.error("UserAuthorizationServiceGateway failed unexpectedly for user {} request.", userId, e);
      return false;
    }
  }
}
