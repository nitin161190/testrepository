package com.wayfair.registration.api.security;

/**
 * Gateway to user-authorization-service - a central registry allowing evaluation of user permission against an asset.
 */
public interface UserAuthorizationServiceGateway {
  boolean isAuthorizedToReadWriteSupplier(Integer userId, Integer supplierId);
}
