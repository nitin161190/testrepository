package com.wayfair.registration.api.security;

import com.google.common.annotations.VisibleForTesting;
import com.wayfair.registration.api.security.metrics.Metrics;
import com.wayfair.user.authorization.library.model.Resource;
import com.wayfair.user.authorization.library.model.ResourceType;
import com.wayfair.user.authorization.library.model.Subject;
import com.wayfair.user.authorization.library.model.SubjectType;
import com.wayfair.user.authorization.library.spring.AuthorizationService;
import datadog.trace.api.Trace;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("!user-authorization.permissive")
@Component
@Slf4j
public class UserAuthorizationServiceGatewayAuthZLibraryAdapter implements UserAuthorizationServiceGateway {
  @VisibleForTesting
  static final String AUTHZ_NAMESPACE = "order-management";
  @VisibleForTesting
  static final String AUTHZ_PERMISSION_WRITE = "write-dropship-orders";

  private final AuthorizationService authZService;
  private final Metrics metrics;

  public UserAuthorizationServiceGatewayAuthZLibraryAdapter(Metrics metrics, AuthorizationService authZService) {
    this.authZService = authZService;
    this.metrics = metrics;
  }

  @Override
  @Trace(resourceName = "user-authorization-service")
  public boolean isAuthorizedToReadWriteSupplier(Integer userId, Integer supplierId) {
    try {
      System.out.println("inside AuthzLibraryAdapter");
      var userIdString = String.valueOf(userId);
      var supplierIdString = String.valueOf(supplierId);
      log.info("Trying to authorize user {} for read/write access to supplier {}...", userId, supplierId);
      var isAuthorized = metrics.timeUserAuthorizationServiceRequest(() -> execute(userIdString, supplierIdString));
      System.out.println("isAuthorized"+isAuthorized);
      if (!isAuthorized) {
        System.out.println("inside if block"+isAuthorized);
        log.warn("User {} not authorized for read/write access to supplier {}!", userId, supplierId);
        metrics.recordUserAuthorizationFailure(userIdString, supplierIdString);
      }
      return isAuthorized;
    } catch (Exception e) {
      log.error("user-authorization-service requests failed for authorization request for user {}.", userId, e);
      metrics.recordUserAuthorizationServiceFailure(e);
      return false;
    }
  }

  private boolean execute(String userId, String supplierId) {
    System.out.println("execute"+userId +""+supplierId);
    return authZService.isAuthorized(
        new Subject(SubjectType.USER_ID, String.valueOf(userId)),
        new Resource(ResourceType.LEGACY_SUPPLIER, String.valueOf(supplierId)),
        AUTHZ_NAMESPACE,
        AUTHZ_PERMISSION_WRITE
    );
  }
}
