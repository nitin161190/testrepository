package com.wayfair.registration.api.request.carton.productcarton.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CartonDimensions {
  double height;
  double width;
  double length;
  double weight;
  double volume;
  int measurementId;
}