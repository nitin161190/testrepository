package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.domain.ShipClass;
import com.wayfair.registration.api.request.entity.CountrySupplierPrintLabelConfig;
import com.wayfair.registration.api.request.entity.SupplierPrintLabelConfig;
import com.wayfair.registration.api.request.repositoryc4.RegistrationPORepository;
import datadog.trace.api.Trace;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class SupplierLabelPrintConfigService {

  private final RegistrationPORepository registrationPORepository;

  @Trace
  public List<SupplierPrintLabelConfig> getLabelPrintConfigForSupplier(int supplierId, int warehouseId, int countryId) {
    List<SupplierPrintLabelConfig> supplierDefaultConfig =
        registrationPORepository.getLabelPrintConfigForSupplier(supplierId);
    List<CountrySupplierPrintLabelConfig> supplierCountryConfig =
        registrationPORepository.getCountrySpecificPrintConfig(supplierId);

    return getLabelPrintConfigForSupplierByCountry(
        warehouseId, supplierDefaultConfig, supplierCountryConfig, countryId);
  }

  @Trace
  public List<SupplierPrintLabelConfig> getLabelPrintConfigForSupplierByCountry(
      int warehouseId,
      @NotNull List<SupplierPrintLabelConfig> defaultConfig,
      @NotNull List<CountrySupplierPrintLabelConfig> supplierCountryConfig,
      int countryId
  ) {

    List<CountrySupplierPrintLabelConfig> countryConfig = supplierCountryConfig.stream()
        .filter(config -> config.getMtxDestCyId() != null && config.getMtxDestCyId().equals(countryId)
            && config.getSupplierId() != null && config.getSupplierId().equals(warehouseId))
        .collect(Collectors.toList());

    for (CountrySupplierPrintLabelConfig config : countryConfig) {
      SupplierPrintLabelConfig supplierPrintLabelConfig = defaultConfig.stream()
          .filter(filter -> filter.getSupplierId().equals(warehouseId))
          .findFirst()
          .orElse(null);

      if (supplierPrintLabelConfig == null) {
        log.warn("Unable to get supplier label print config for supplier: {}", warehouseId);
        continue;
      }

      if (config.getMtxRestricted() == null) {
        // If the MatrixRestricted value is not set, we don't need to override the value.
        continue;
      }

      switch (Objects.requireNonNull(ShipClass.valueOf(config.getMtxShipClassId()))) {
        case SMALL_PARCEL:
          supplierPrintLabelConfig
              .setSuExtranetEnableSP(config.getMtxRestricted() == 0
                  && supplierPrintLabelConfig.isSuExtranetEnableSP());

          break;
        case TRUCK_FREIGHT:
        case TRUCK_LOAD:
          supplierPrintLabelConfig
              .setSuExtranetEnableLTL(config.getMtxRestricted() == 0
                  && supplierPrintLabelConfig.isSuExtranetEnableLTL());
          break;
        case WHITE_GLOVE:
          supplierPrintLabelConfig
              .setSuExtranetEnableWG(config.getMtxRestricted() == 0
                  && supplierPrintLabelConfig.isSuExtranetEnableWG());
          break;
        default:
          break;
      }
    }

    return defaultConfig;
  }
}
