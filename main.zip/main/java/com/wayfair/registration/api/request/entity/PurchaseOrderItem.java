package com.wayfair.registration.api.request.entity;

import java.math.BigDecimal;
import java.math.BigInteger;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(
    name = "RegistrationPoItemMapping",
    entities = {
        @EntityResult(
            entityClass = PurchaseOrderItem.class,
            fields = {
                @FieldResult(name = "opID", column = "OpID"),
                @FieldResult(name = "itemId", column = "ItemId"),
                @FieldResult(name = "poNum", column = "PONum"),
                @FieldResult(name = "rpId", column = "RpID"),
                @FieldResult(name = "opQty", column = "OpQty"),
                @FieldResult(name = "manufacturerPartID", column = "ManufacturerPartID"),
                @FieldResult(name = "prManuPartNum", column = "PrManuPartNum"),
                @FieldResult(name = "prName", column = "PrName"),
                @FieldResult(name = "prWeight", column = "PrWeight"),
                @FieldResult(name = "opPrSKU", column = "OpPrSKU"),
                @FieldResult(name = "prMinOrderQty", column = "PrMinOrderQty"),
                @FieldResult(name = "refProdID", column = "RefProdID"),
                @FieldResult(name = "piID1", column = "PiID1"),
                @FieldResult(name = "piID2", column = "PiID2"),
                @FieldResult(name = "piID3", column = "PiID3")
            }
        )
    }
)
public class PurchaseOrderItem {

  @Id
  BigInteger opID;
  String itemId;
  Integer poNum;
  Integer rpId;
  Integer opQty;
  Long manufacturerPartID;
  String prManuPartNum;
  String prName;
  BigDecimal prWeight;
  String opPrSKU;
  Integer prMinOrderQty;
  String refProdID;
  Integer piID1;
  Integer piID2;
  Integer piID3;
}

