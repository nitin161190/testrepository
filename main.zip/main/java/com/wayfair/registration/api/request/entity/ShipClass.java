package com.wayfair.registration.api.request.entity;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(name = "ShipClassMapping",
    entities = {@EntityResult(entityClass = ShipClass.class,
        fields = {
            @FieldResult(name = "fullPoNumber", column = "FullPoNumber"),
            @FieldResult(name = "storePrefix", column = "PoStorePrefix"),
            @FieldResult(name = "poNum", column = "PoNum"),
            @FieldResult(name = "rpId", column = "RpID"),
            @FieldResult(name = "shipClass", column = "ActualShipClass")})})
public class ShipClass {

  @Id
  String fullPoNumber;
  String storePrefix;
  String poNum;
  String rpId;
  Integer shipClass;
}
