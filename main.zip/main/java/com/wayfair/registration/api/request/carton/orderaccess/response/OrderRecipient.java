package com.wayfair.registration.api.request.carton.orderaccess.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class OrderRecipient {

  @JsonProperty("OpReID")
  private Long opReID;

  @JsonProperty("OpReAddress1")
  private String opReAddress1;

  @JsonProperty("OpReAddress2")
  private String opReAddress2;

  @JsonProperty("OpReFullName")
  private String opReFullName;

  @JsonProperty("OpReEmailAddress")
  private String opReEmailAddress;

  @JsonProperty("OpRePostalCode")
  private String opRePostalCode;

  @JsonProperty("OpReContactAtPhone")
  private String opReContactAtPhone;

  @JsonProperty("OpReCityName")
  private String opReCityName;

  @JsonProperty("StShortName")
  private String stShortName;

  @JsonProperty("CyShortName")
  private String cyShortName;
}
