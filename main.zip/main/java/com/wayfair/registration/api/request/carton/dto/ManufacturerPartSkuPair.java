package com.wayfair.registration.api.request.carton.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@ToString
@EqualsAndHashCode
@RequiredArgsConstructor
@Getter
public class ManufacturerPartSkuPair {
  private final Long manufacturerPartNumber;
  private final String sku;
}
