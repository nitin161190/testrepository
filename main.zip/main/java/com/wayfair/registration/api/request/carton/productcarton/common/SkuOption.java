package com.wayfair.registration.api.request.carton.productcarton.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
@EqualsAndHashCode
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SkuOption {
  public static final int DEFAULT_OPTION_ID = 0;

  String sku;
  int option1Id = DEFAULT_OPTION_ID;
  int option2Id = DEFAULT_OPTION_ID;
  int option3Id = DEFAULT_OPTION_ID;
  String optionString;
  String optionSetCacheKey;
}