package com.wayfair.registration.api.request.entity;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(name = "SupplierPrintLabelConfigMapping",
    entities = {@EntityResult(entityClass = SupplierPrintLabelConfig.class,
        fields = {@FieldResult(name = "supplierId", column = "SuID"),
            @FieldResult(name = "suExtranetEnableLTL", column = "SuExtranetEnableLTL"),
            @FieldResult(name = "suExtranetEnableWG", column = "SuExtranetEnableWG"),
            @FieldResult(name = "suExtranetEnableSP", column = "SuExtranetEnableSP"),
            @FieldResult(name = "suExtranetEnableRP", column = "SuExtranetEnableRP"),
            @FieldResult(name = "suPartsShipOnSupplierAccount",
                column = "SuPartsShipOnSupplierAccount")})})
public class SupplierPrintLabelConfig {

  @Id
  Integer supplierId;
  boolean suExtranetEnableLTL;
  boolean suExtranetEnableWG;
  boolean suExtranetEnableSP;
  boolean suExtranetEnableRP;
  boolean suPartsShipOnSupplierAccount;

}
