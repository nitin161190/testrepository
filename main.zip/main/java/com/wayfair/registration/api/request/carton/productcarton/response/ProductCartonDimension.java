package com.wayfair.registration.api.request.carton.productcarton.response;

import com.wayfair.registration.api.request.carton.productcarton.common.SkuOption;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ProductCartonDimension {
  SkuOption skuOptionSet;
  List<CartonDimensions> cartonDimensions;
}