package com.wayfair.registration.api.request.entity;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@SqlResultSetMapping(name = "CarrierInfoMapping",
    entities = {@EntityResult(entityClass = CarrierInfo.class,
        fields = {
            @FieldResult(name = "carrierId", column = "CrID"),
            @FieldResult(name = "carrierName", column = "CrName"),
            @FieldResult(name = "crMetaPackEnabled", column = "CrMetaPackEnabled"),
            @FieldResult(name = "carrierTsId", column = "CrTsID")})})
public class CarrierInfo {

  @Id
  int carrierId;
  String carrierName;
  Integer carrierTsId;
  Boolean crMetaPackEnabled;
}
