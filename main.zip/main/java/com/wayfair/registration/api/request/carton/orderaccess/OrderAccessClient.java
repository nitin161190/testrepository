package com.wayfair.registration.api.request.carton.orderaccess;

import com.wayfair.registration.api.request.carton.orderaccess.response.OrderProduct;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "order-access", url = "${order-access.url}")
public interface OrderAccessClient {

  @GetMapping(
      value = "/v0/purchase-orders/{purchaseOrderNumber}/order-products",
      headers = {
          "x-wayfair-team=supplier-outbound",
          "x-wayfair-product=order-registration"}
  )
  List<OrderProduct> retrieveOrderProductsForPo(@PathVariable("purchaseOrderNumber") int purchaseOrderNumber);

}
