package com.wayfair.registration.api.request.mapper;

import com.wayfair.registration.api.purchaseorder.dto.PhpDateTime;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.request.entity.PurchaseOrder;
import java.util.Date;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RequestPurchaseOrderRegistrationPoMapper {
  @Mapping(target = "rpID", source = "rpId")
  @Mapping(target = "isLabelPrintEnabledForCarrier", source = "labelPrintEnabledForCarrier")
  RegistrationPo fromRequestPurchaseOrderToRegistrationPo(PurchaseOrder purchaseOrder);

  default PhpDateTime map(Date date) {
    return date != null ? new PhpDateTime(date.toString()) : null;
  }
}
