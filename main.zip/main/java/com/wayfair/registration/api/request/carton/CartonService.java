package com.wayfair.registration.api.request.carton;

import com.wayfair.registration.api.request.carton.dto.CartonData;
import com.wayfair.registration.api.request.carton.dto.ManufacturerPartSkuPair;
import com.wayfair.registration.api.request.carton.orderaccess.OrderAccessClient;
import com.wayfair.registration.api.request.carton.orderaccess.response.OrderProduct;
import com.wayfair.registration.api.request.carton.productcarton.ProductCartonClient;
import com.wayfair.registration.api.request.carton.productcarton.request.CallerContext;
import com.wayfair.registration.api.request.carton.productcarton.request.ProductCartronsByManufacturerPartIdRequest;
import com.wayfair.registration.api.request.carton.productcarton.response.ProductCartonsResponse;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CartonService {

  private static final String APPLICATION_NAME = "so-registration-api";
  private static final String METHOD_NAME = "getCartonDataForPo";

  private final OrderAccessClient orderAccessClient;
  private final ProductCartonClient productCartonClient;

  public Map<ManufacturerPartSkuPair, CartonData> getCartonDataForPo(int purchaseOrderNumber) {
    // TODO This call will have to be refactored and moved one layer up. We would like to use these results
    // TODO in the creation of the items in the registration request.
    List<OrderProduct> orderProducts = orderAccessClient.retrieveOrderProductsForPo(purchaseOrderNumber);

    log.info("Order Access API response for PO {} is {}", purchaseOrderNumber, orderProducts);

    List<Long> manufacturerPartIds = orderProducts.stream()
        .map(OrderProduct::getManufacturerPartId)
        .distinct()
        .collect(Collectors.toList());

    ProductCartronsByManufacturerPartIdRequest productCartonsRequest =
        ProductCartronsByManufacturerPartIdRequest.builder()
            .manufacturerPartIds(manufacturerPartIds)
            .callerContext(CallerContext.builder()
                .applicationName(APPLICATION_NAME)
                .methodName(METHOD_NAME)
                .build())
            .build();
    List<ProductCartonsResponse> productCartonsResponse =
        productCartonClient.getCartonDimensionsByManufacturerPartId(productCartonsRequest);

    log.info("Product Carton API response for PO {} is {}", purchaseOrderNumber, productCartonsResponse);

    return buildSkuToCartonDataMap(orderProducts, productCartonsResponse);
  }

  private Map<ManufacturerPartSkuPair, CartonData> buildSkuToCartonDataMap(List<OrderProduct> orderProducts,
      List<ProductCartonsResponse> productCartonsResponses) {

    Map<Long, CartonData> manufacturerPartIdToMeasurementId = productCartonsResponses.stream()
        .filter(Objects::nonNull)
        .filter(
            productCartonsResponse -> productCartonsResponse.getManufacturerPart() != null
                && !productCartonsResponse.getProductCartons().isEmpty()
        )
        .collect(Collectors.toMap(
            productCartonResponse -> productCartonResponse.getManufacturerPart().getId(),
            productCartonResponse -> CartonData.builder()
                .measurementId(productCartonResponse
                    .getProductCartons().get(0).getCartonDimensions().getMeasurementId())
                .build(),
            (existingEntry, newEntry) -> existingEntry
        ));

    List<ManufacturerPartSkuPair> manufacturerPartSkuPairs = orderProducts.stream()
        .map(orderProduct -> new ManufacturerPartSkuPair(orderProduct.getManufacturerPartId(),
            orderProduct.getOpPrSKU()))
        .distinct()
        .collect(Collectors.toList());

    return manufacturerPartSkuPairs.stream()
        .collect(Collectors.toMap(
                manufacturerPartSkuPair -> manufacturerPartSkuPair,
                manufacturerPartSkuPair -> {
                  if (!manufacturerPartIdToMeasurementId
                      .containsKey(manufacturerPartSkuPair.getManufacturerPartNumber())) {
                    throw new IllegalStateException(
                        String.format("Measurement ID not found for manufacturer part number %s",
                            manufacturerPartSkuPair.getManufacturerPartNumber()));
                  }
                  return CartonData.builder()
                      .measurementId(manufacturerPartIdToMeasurementId.get(
                          manufacturerPartSkuPair.getManufacturerPartNumber()).getMeasurementId())
                      .build();
                }
            )
        );
  }
}
