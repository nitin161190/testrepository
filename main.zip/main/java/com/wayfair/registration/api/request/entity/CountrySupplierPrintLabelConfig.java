package com.wayfair.registration.api.request.entity;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(name = "CountrySupplierPrintLabelConfigMapping",
    entities = {@EntityResult(entityClass = CountrySupplierPrintLabelConfig.class,
        fields = {
            @FieldResult(name = "mtxId", column = "MtxID"),
            @FieldResult(name = "supplierId", column = "SuID"),
            @FieldResult(name = "mtxShipClassId", column = "MtxShipClassID"),
            @FieldResult(name = "mtxRestricted", column = "MtxRestricted"),
            @FieldResult(name = "mtxDestCyId", column = "MtxDestCyID")})})
public class CountrySupplierPrintLabelConfig {

  @Id
  int mtxId;
  Integer supplierId;
  Integer mtxShipClassId;
  /**
   * Defines shipping-restriction for the country.
   */
  Integer mtxRestricted;
  /**
   * Country ID.
   */
  Integer mtxDestCyId;
}
