package com.wayfair.registration.api.request.carton.dto;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
public class CartonData {

  int measurementId;

}
