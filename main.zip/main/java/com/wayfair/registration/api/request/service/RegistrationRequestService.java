package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.domain.ShipSpeed;
import com.wayfair.registration.api.domain.SupplierLabelCountType;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import com.wayfair.registration.api.purchaseorder.dto.MeasurementUnitType;
import com.wayfair.registration.api.purchaseorder.dto.PhpDateTime;
import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.PoItemData;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItem;
import com.wayfair.registration.api.purchaseorder.dto.TranslationHelper;
import com.wayfair.registration.api.request.carton.CartonService;
import com.wayfair.registration.api.request.carton.dto.CartonData;
import com.wayfair.registration.api.request.carton.dto.ManufacturerPartSkuPair;
import com.wayfair.registration.api.request.dto.RegistrationRequest;
import com.wayfair.registration.api.request.entity.CarrierInfo;
import com.wayfair.registration.api.request.repositoryc4.SupplierRepository;
import com.wayfair.registration.api.service.FeatureToggleService;
import com.wayfair.registration.api.util.SubEntityMapping;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.NotImplementedException;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrationRequestService {
  private static final String VALIDATION_ERROR_NOT_THE_OWNER_SUPPLIER = "errorPODoesNotBelongToSupplier";
  private static final String ENABLE_REGISTRATION_WITH_OPID_MAPPING = "so_enable_order_registration_with_op_id_mapping";

  private final SupplierRepository supplierRepository;
  private final CarrierInfoService carrierInfoService;
  private final RegistrationPOService registrationPOService;
  private final FeatureToggleService featureToggleService;
  private final CartonService cartonService;

  public RegistrationRequest prepareRegistrationRequest(
      @NotNull List<PoData> purchaseOrderList, int supplierId, Integer extranetUserId, Integer employeeId
  ) {
    List<RegistrationPo> registrationPoList = prepareRegistrationPurchaseOrderData(purchaseOrderList, supplierId);

    return RegistrationRequest.builder()
        .poList(registrationPoList)
        .supplierId(supplierId)
        .extranetUserId(extranetUserId)
        .employeeId(employeeId)
        .build();
  }

  public List<RegistrationPo> prepareRegistrationPurchaseOrderData(
      @NotNull List<PoData> purchaseOrderList, int supplierId
  ) {
    if (purchaseOrderList.isEmpty()) {
      return Collections.emptyList();
    }

    List<Integer> rpIds = purchaseOrderList.stream()
        .filter(po -> po.getFullPurchaseOrderNumber().getRPId().isPresent())
        .map(po -> po.getFullPurchaseOrderNumber().getRPId().get())
        .collect(Collectors.toList());

    if (!rpIds.isEmpty()) {
      throw new NotImplementedException();
    }

    List<Integer> supplierFamilyIdsBySupplierList = supplierRepository.getSupplierFamilyIdsBySupplierList(supplierId);
    Optional<Integer> subentityBySupplierId = supplierRepository.getSubEntityBySupplierId(supplierId);
    boolean hasSubEntityNorthAmerica = SubEntityMapping.isNorthAmerica(subentityBySupplierId.orElse(0));

    List<FullPurchaseOrderNumber> fullPoNumbers = purchaseOrderList.stream()
        .map(fullPONumber -> new FullPurchaseOrderNumber(fullPONumber.getFullPurchaseOrderNumber().getFullPONumber()))
        .collect(Collectors.toList());
    List<RegistrationPo> immutableRegistrationData = registrationPOService
        .getRegistrationPoData(fullPoNumbers, supplierId);

    // Make the List mutable so we can modify it.
    List<RegistrationPo> registrationData = new ArrayList<>(immutableRegistrationData);

    boolean opIdMappingEnabled = featureToggleService
        .isEnabled(ENABLE_REGISTRATION_WITH_OPID_MAPPING, false);

    log.debug("Process registration request : {}", registrationData);
    for (PoData poData : purchaseOrderList) {
      int purchaseOrderNumber = poData.getFullPurchaseOrderNumber().getPONumber();

      Map<ManufacturerPartSkuPair, CartonData> cartonDataMap = cartonService.getCartonDataForPo(purchaseOrderNumber);

      log.info("CartonDataMap for PO {} is {}", purchaseOrderNumber, cartonDataMap);

      Optional<RegistrationPo> poOptional = registrationData.stream()
          .filter(registrationPo -> registrationPo.getFullPONumber()
              .equals(poData.getFullPurchaseOrderNumber().getFullPONumber()))
          .findFirst();

      // If the registration PO is not present in the list we get from DB query,
      // that means that this PO doesn't belong to the given supplier family.
      // Hence, marking the PO as invalid.
      if (poOptional.isEmpty()) {
        RegistrationPo registrationPo = RegistrationPo.builder()
            .poNum(purchaseOrderNumber)
            .poStorePrefix(poData.getFullPurchaseOrderNumber().getStorePrefix())
            .isValid(false)
            .validationError(
                new TranslationHelper(VALIDATION_ERROR_NOT_THE_OWNER_SUPPLIER,
                    Map.of(
                        "poNum", poData.getFullPurchaseOrderNumber().getFullPONumber(),
                        "supplierId", String.valueOf(supplierId)
                    )
                )
            )
            .build();

        poData.getFullPurchaseOrderNumber().getRPId().ifPresent(registrationPo::setRpID);
        registrationData.add(registrationPo);

        continue;
      }

      RegistrationPo purchaseOrder = poOptional.get();

      // Override warehouse if we are getting data from user input
      if (poData.getWarehouseId() != null
          && supplierFamilyIdsBySupplierList.contains(poData.getWarehouseId())) {
        purchaseOrder.setSuID(poData.getWarehouseId());
      }

      // Override RFP date if we are getting it from user input
      if (poData.getRfpDate() != null) {
        PhpDateTime oldDate = purchaseOrder.getRequestForPickupDate();
        purchaseOrder.setRequestForPickupDate(new PhpDateTime(poData.getRfpDate().toString()));

        if (oldDate != null && !oldDate.equals(purchaseOrder.getRequestForPickupDate())) {
          purchaseOrder.setIsRFPDateChanged(true);
        } else {
          purchaseOrder.setIsRFPDateChanged(false);
        }
      }

      // TODO: Setting this flag to match the monolith implementation.
      //  We should investigate and find out if it is needed.
      if (poData.isRegistrationRequired()) {
        purchaseOrder.setIsRegistrationUpdateRequired(poData.isRegistrationRequired());
      }

      if (poData.getCarrierId() != null || poData.getThirdPartyCarrierId() != null) {
        Integer selectedCarrierId = poData.getCarrierId();
        Integer selectedThirdPartyCarrierId = poData.getThirdPartyCarrierId();

        if (!Objects.equals(purchaseOrder.getCrID(), selectedCarrierId)
            || !Objects.equals(purchaseOrder.getTsID(), selectedThirdPartyCarrierId)) {
          log.info(
              "Received different carrier in payload. Po: {} old CrID: {}, new CrID: {}, old TsID: {}, new TsID: {}.",
              purchaseOrder.getFullPONumber(),
              purchaseOrder.getCrID(),
              selectedCarrierId,
              purchaseOrder.getTsID(),
              selectedThirdPartyCarrierId
          );

          Optional<CarrierInfo> carrierInfo = carrierInfoService
              .getCarrierInfoForByShippingCarrierIdOrThirdPartyCarrierId(selectedCarrierId,
                  selectedThirdPartyCarrierId);
          if (carrierInfo.isEmpty()) {
            String message = String.format(
                "Could not find carrier info for the given ship carrier: %s or third party carrier: %s",
                selectedCarrierId, selectedThirdPartyCarrierId);
            log.error(message);
            throw new RuntimeException(message);
          }
          log.info("Successfully fetched carrier info: {} for PO: {}", carrierInfo, poData.getFullPoNumber());

          CarrierInfo crInfo = carrierInfo.get();
          purchaseOrder.setCrID(selectedCarrierId);
          purchaseOrder.setCrName(crInfo.getCarrierName());
          purchaseOrder.setTsID(crInfo.getCarrierTsId());
          purchaseOrder.setIsCarrierChanged(true);
        }
      }

      // Override ship class if we are getting it from user input
      // We only allow to change ship class for replacement part
      // Following logic is only required for replacement parts
      // We are still going to call monolith for replacement parts
      // because of some unresolved dependencies.
      if (purchaseOrder.getRpID() != null
          && !checkAndHandleShipClassChangeRequest(poData, purchaseOrder, hasSubEntityNorthAmerica)
      ) {
        // TODO: has to be handled properly, when monolith dependency is removed
        continue;
      }

      // Override item weight and item piece count if we have user input
      if (poData.getItems() != null && !poData.getItems().isEmpty()) {
        log.info("Process PO Data for Item Weight and Count : {}", poData);
        if (purchaseOrder.getLabelCountType() == SupplierLabelCountType.ONE_LABEL_PER_ORDER.getValue()
            && hasCartonCountChanged(purchaseOrder, poData)) {
          // in case supplier has setting `single label per order`
          // and during registration they changed the label count
          // then we assume that supplier wants to print `single label per box`
          log.info("Update POData LabelCountType to 1 Label/box for PO : {}", poData.getFullPurchaseOrderNumber());
          purchaseOrder.setLabelCountType(SupplierLabelCountType.ONE_LABEL_PER_BOX.getValue());
        }

        poData.getItems().forEach((key, inputItem) -> purchaseOrder.setItems(
            purchaseOrder.getItems().stream().map(item -> {
              log.info(
                  "Processing Item Data for PO: {}, ItemData : {}, Supplier-Input : {}",
                  item.getOpID(),
                  item,
                  inputItem
              );

              var manufacturerPartSkuPair = new ManufacturerPartSkuPair(item.getManufacturerPartID(),
                  item.getOpPrSKU());
              if (cartonDataMap.get(manufacturerPartSkuPair) == null) {
                throw new IllegalStateException(
                    "Could not retrieve carton data for PO " + poData.getFullPurchaseOrderNumber()
                        .getFullPONumber());
              }

              int measurementId = cartonDataMap.get(manufacturerPartSkuPair).getMeasurementId();
              item.setMeasurementUnitType(MeasurementUnitType.fromMeasurementId(measurementId));

              if (item.getRpId() != null
                  && item.getRpId().equals(poData.getFullPurchaseOrderNumber().getRPId().orElse(null))) {
                item.setRefProdID(inputItem.getPartNumber());
              }

              String comparableValue = (opIdMappingEnabled && inputItem.getOrderProductId() != null
                  && inputItem.getOrderProductId() > 0) ? item.getOpID().toString() : item.getRefProdID();

              // If OpID is present, let's use OpID as mapping key
              if (key.equals(comparableValue)) {
                if (inputItem.getUnitWeight() != null) {
                  log.info("Updating Item Weight for OP : {}. Old Weight : {}. New Weight : {}",
                      item.getOpID(),
                      item.getPrWeight(),
                      inputItem.getUnitWeight()
                  );
                  item.setPrWeight(inputItem.getUnitWeight());
                }
                if (inputItem.getPieceCount() != null && inputItem.getPieceCount() >= 0) {
                  log.info("Updating Item Piece Count for OP : {}. Old Count : {}. New Count : {}",
                      item.getOpID(),
                      item.getPieceCount(),
                      inputItem.getPieceCount()
                  );
                  item.setPieceCount(inputItem.getPieceCount());
                }
                if (inputItem.getPieceType() != null) {
                  item.setPieceType(inputItem.getPieceType());
                }

                item.setCartons(item.getCartons().stream().map(carton -> {
                  log.info("Processing Carton data : {}", carton);
                  BigDecimal totalWeight = item.getPrWeight().multiply(BigDecimal.valueOf(item.getOpQty()));
                  int pieceCount = item.getPieceCount() > 0 ? item.getPieceCount() : 1;
                  carton.setItemCartonWeight(
                      totalWeight.divide(BigDecimal.valueOf(pieceCount), 2, RoundingMode.CEILING));

                  if (inputItem.getFreightClass() != null) {
                    carton.setBoxClass(inputItem.getFreightClass());
                  }

                  if (inputItem.getNmfc() != null) {
                    carton.setBoxNmfc(inputItem.getNmfc());
                  }
                  log.info("Completed processing Carton data : {}", carton);

                  return carton;
                }).collect(Collectors.toList()));
              }

              return item;
            }).collect(Collectors.toList())
        ));

      }

      purchaseOrder.setIsPOPalletized(poData.isPalletized());
      purchaseOrder.setPalletWeight(poData.getPalletWeight());
      purchaseOrder.setPalletCount(poData.getPalletCount());

      if (Boolean.TRUE.equals(isPieceCountValid(purchaseOrder))) {
        purchaseOrder.setIsValid(true);
      } else {
        purchaseOrder.setIsValid(false);
        purchaseOrder.setValidationError(
            TranslationHelper.builder()
                .messageId("errorInvalidRequestMissingTotalPieceCount")
                .build()
        );
      }
    }

    return registrationData;
  }

  private boolean checkAndHandleShipClassChangeRequest(
      PoData poData,
      RegistrationPo registrationPo,
      boolean hasSubentityNorthAmerica
  ) {
    FullPurchaseOrderNumber fullPurchaseOrderNumber = poData.getFullPurchaseOrderNumber();
    Optional<Integer> rpId = fullPurchaseOrderNumber.getRPId();

    // Following logic should only be executed for RP orders.
    if (rpId.isEmpty()) {
      return true;
    }

    if (poData.getCarrierId() != null || poData.getThirdPartyCarrierId() != null) {
      Optional<CarrierInfo> carrierInfo = carrierInfoService.getCarrierInfoForByShippingCarrierIdOrThirdPartyCarrierId(
          poData.getCarrierId(), poData.getThirdPartyCarrierId());

      if (carrierInfo.isEmpty()) {
        return false;
      }
      log.info("Successfully fetched carrier info: {} for PO: {}", carrierInfo, poData.getFullPoNumber());

      registrationPo.setCrID(carrierInfo.get().getCarrierId());
      registrationPo.setCrName(carrierInfo.get().getCarrierName());
      registrationPo.setTsID(carrierInfo.get().getCarrierTsId());
    }

    if (poData.getShipClassId() == null) {
      return true;
    }

    // TODO: Complete this flow before enabling replacement part request creation in decoupled app.
    if (poData.getShipClassId() == com.wayfair.registration.api.domain.ShipClass.SMALL_PARCEL.getShipClassId()) {
      registrationPo.setShipClass(poData.getShipClassId());

      // Change ship speed to GROUND for NA and small parcel courier for EU
      int shipSpeed = hasSubentityNorthAmerica
          ? ShipSpeed.METHOD_GROUND.getShipSpeedId()
          : ShipSpeed.METHOD_SMALL_PARCEL_COURIER.getShipSpeedId();

      registrationPo.setSpID(shipSpeed);
    }

    throw new NotImplementedException();
  }

  private Boolean isPieceCountValid(RegistrationPo purchaseOrder) {
    Optional<Integer> totalPieceCount = purchaseOrder.getItems().stream()
        .map(RegistrationPoItem::getPieceCount)
        .reduce(Integer::sum);

    return totalPieceCount.isPresent() && totalPieceCount.get() > 0;
  }

  @NotNull
  private Boolean hasCartonCountChanged(RegistrationPo purchaseOrderFromDB, PoData purchaseOrderFromUserInput) {
    // Caldulate if total carton count has changed
    Optional<Integer> totalPieceCountDB = purchaseOrderFromDB.getItems().stream()
        .map(RegistrationPoItem::getPieceCount)
        .reduce(Integer::sum);

    Optional<Integer> totalPieceCountUserInput = purchaseOrderFromUserInput.getItems().values().stream()
        .map(PoItemData::getPieceCount)
        .reduce(Integer::sum);

    return !totalPieceCountDB.equals(totalPieceCountUserInput);
  }
}
