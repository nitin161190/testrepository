package com.wayfair.registration.api.request.mapper;

import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItemCarton;
import com.wayfair.registration.api.request.entity.PurchaseOrderItemCarton;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RequestPurchaseOrderItemCartonRegistrationPoItemCartonMapper {
  RegistrationPoItemCarton fromRequestPurchaseOrderItemCartonToRegistrationPoItemCarton(PurchaseOrderItemCarton carton);
}
