package com.wayfair.registration.api.request.repositoryc4;

import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
public class SupplierRepository {

  private final EntityManager entityManager;

  public SupplierRepository(@Qualifier("c4EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public List<Integer> getSupplierFamilyIdsBySupplierList(int supplierId) {
    return entityManager.createNativeQuery(""
        + "      SELECT ISNULL(suParent.SuParentSuID,suParent.SuID) "
        + "       FROM csn_order.dbo.tblSupplier suParent WITH (NOLOCK) WHERE SuID = :supplier_id"
        + "      UNION"
        + "      SELECT SuID"
        + "      FROM csn_order.dbo.tblSupplier WITH (NOLOCK)"
        + "      WHERE SuParentSuID in ("
        + "       SELECT ISNULL(suParent.SuParentSuID,suParent.SuID) "
        + "       FROM csn_order.dbo.tblSupplier suParent WITH (NOLOCK) "
        + "       WHERE suParent.SuID = :supplier_id ) "
        + "")
        .setParameter("supplier_id", supplierId)
        .getResultList();
  }

  public Optional<Integer> getSubEntityBySupplierId(int supplierId) {
    return Optional.ofNullable((Integer) entityManager.createNativeQuery(""
        + "      SELECT"
        + "        SuStyID"
        + "      FROM"
        + "        csn_order.dbo.tblSupplier WITH (NOLOCK)"
        + "      WHERE"
        + "        SuID = :supplierId")
        .setParameter("supplierId", supplierId)
        .getSingleResult());
  }
}
