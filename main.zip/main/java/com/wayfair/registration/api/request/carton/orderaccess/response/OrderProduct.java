package com.wayfair.registration.api.request.carton.orderaccess.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrderProduct {

  @JsonProperty("Options")
  List<OrderOptions> options;

  @JsonProperty("OpID")
  private long opID;

  @JsonProperty("OpOrID")
  private long opOrID;

  @JsonProperty("OpCrID")
  private int opCrID;

  @JsonProperty("OpPrPrice")
  private float opPrPrice;

  @JsonProperty("OpTsID")
  private int opTsID;

  @JsonProperty("OpPrSKU")
  private String opPrSKU;

  @JsonProperty("PurchaseOrder")
  private PurchaseOrder purchaseOrder;

  @JsonProperty("OpQty")
  private Integer opQty;

  @JsonProperty("ReplacementParts")
  private List<OrderReplacementPart> replacementParts;

  @JsonProperty("Returns")
  private List<OrderReturn> returns;

  @JsonProperty("OpComponentManufacturerPartID")
  private Long manufacturerPartId;

}
