package com.wayfair.registration.api.request.mapper;

import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItem;
import com.wayfair.registration.api.request.entity.PurchaseOrderItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface RequestPurchaseOrderItemRegistrationPoItemMapper {
  @Mapping(target = "pieceCount", ignore = true)
  @Mapping(target = "pieceType", ignore = true)
  @Mapping(target = "cartons", ignore = true)
  RegistrationPoItem fromRequestPurchaseOrderItemToRegistrationPoItem(PurchaseOrderItem purchaseOrderItem);
}
