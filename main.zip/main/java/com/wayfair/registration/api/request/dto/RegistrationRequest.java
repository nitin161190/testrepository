package com.wayfair.registration.api.request.dto;

import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import java.util.List;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RegistrationRequest {

  List<RegistrationPo> poList;
  Integer supplierId;
  Integer extranetUserId;
  Integer employeeId;
}
