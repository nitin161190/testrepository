package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.domain.ShipClass;
import com.wayfair.registration.api.labeldata.LabelDataClient;
import com.wayfair.registration.api.labeldata.LabelDataHistoryRequest;
import com.wayfair.registration.api.labeldata.LabelDataHistoryResponse;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import com.wayfair.registration.api.purchaseorder.dto.PhpDateTime;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItem;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItemCarton;
import com.wayfair.registration.api.purchaseorder.entity.RequestForPickupDate;
import com.wayfair.registration.api.purchaseorder.persistence.CustomPurchaseOrderRepository;
import com.wayfair.registration.api.request.entity.PurchaseOrder;
import com.wayfair.registration.api.request.entity.PurchaseOrderItem;
import com.wayfair.registration.api.request.entity.PurchaseOrderItemCarton;
import com.wayfair.registration.api.request.entity.SupplierPrintLabelConfig;
import com.wayfair.registration.api.request.mapper.RequestPurchaseOrderItemCartonRegistrationPoItemCartonMapper;
import com.wayfair.registration.api.request.mapper.RequestPurchaseOrderItemRegistrationPoItemMapper;
import com.wayfair.registration.api.request.mapper.RequestPurchaseOrderRegistrationPoMapper;
import com.wayfair.registration.api.request.repositoryc4.RegistrationPORepository;
import com.wayfair.registration.api.service.FeatureToggleService;
import datadog.trace.api.Trace;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class RegistrationPOService {

  private static final String ENABLE_RP_CARTONS_DIMENSIONS_HARDCODING = "enable_rp_cartons_dimensions_hardcoding";

  private final CustomPurchaseOrderRepository purchaseOrderRepository;
  private final RegistrationPORepository registrationPORepository;
  private final LabelDataClient labelDataClient;
  private final RequestPurchaseOrderRegistrationPoMapper poMapper;
  private final RequestPurchaseOrderItemRegistrationPoItemMapper poItemMapper;
  private final RequestPurchaseOrderItemCartonRegistrationPoItemCartonMapper poItemCartonMapper;
  private final SupplierLabelPrintConfigService supplierDefaultConfigService;
  private final FeatureToggleService featureToggleService;

  @Trace
  public List<RegistrationPo> getRegistrationPoData(List<FullPurchaseOrderNumber> poNumbers, int supplierId) {
    if (poNumbers.isEmpty()) {
      return Collections.emptyList();
    }

    List<String> fullPONumbers = poNumbers.stream()
        .map(FullPurchaseOrderNumber::getFullPONumber)
        .collect(Collectors.toList());

    List<LabelDataHistoryResponse> labelDataHistoryResponse = labelDataClient.history(
        new LabelDataHistoryRequest(fullPONumbers));

    List<RequestForPickupDate> registeredPOData = purchaseOrderRepository.getRegisteredPOData(poNumbers);

    List<PurchaseOrder> requestPos = registrationPORepository.getOrdersData(poNumbers, supplierId);

    /* The query retrieving these PurchaseOrders is returning duplicate entries due to the
     * internationalTransshipLinehaulID field. Converting it to a Set is a quick and dirty way to mask the issue.
     * The order is important, hence why the processing is done sequentially. */
    Set<PurchaseOrder> uniqueRequestPos = new HashSet<>(requestPos);

    List<RegistrationPo> posData = uniqueRequestPos.stream()
        .map(poMapper::fromRequestPurchaseOrderToRegistrationPo)
        .collect(Collectors.toList());

    List<PurchaseOrderItem> requestPoItems = registrationPORepository.getPOItemsData(poNumbers);
    List<RegistrationPoItem> poItemsData = requestPoItems.stream()
        .map(poItemMapper::fromRequestPurchaseOrderItemToRegistrationPoItem)
        .collect(Collectors.toList());

    List<RegistrationPoItemCarton> itemsCartonsDataForPO = getCartonsData(poItemsData, posData).stream()
        .map(poItemCartonMapper::fromRequestPurchaseOrderItemCartonToRegistrationPoItemCarton)
        .collect(Collectors.toList());

    log.info("Fetched carton dimensions {}", itemsCartonsDataForPO);

    for (RegistrationPo registrationPo : posData) {
      String fullPoNumber = registrationPo.getFullPONumber();
      registrationPo.setIsRegistered(false);

      if (registrationPo.getRpID() != null) {
        // Set the RFP date from ExoRfpDate if the RP is already registered
        getByRPId(registeredPOData, registrationPo.getRpID()).ifPresent(rfpDate -> {
          registrationPo.setRequestForPickupDate(new PhpDateTime(rfpDate.getRequestForPickupDate()));
          registrationPo.setIsRegistered(true);
        });
      } else {
        getByPONum(registeredPOData, registrationPo.getPoNum()).ifPresent(rfpDate -> {
          registrationPo.setRequestForPickupDate(new PhpDateTime(rfpDate.getRequestForPickupDate()));
          registrationPo.setIsRegistered(true);
        });
      }

      // TODO: Explore if this is helpful, if not, let's remove un-necessary dependency
      labelDataHistoryResponse.stream()
          .filter(label -> label.getShipmentIdentifier().equals(fullPoNumber))
          .findFirst()
          .ifPresent(label -> registrationPo.setShippingLabel(label.getLabelPath()));

      List<SupplierPrintLabelConfig> labelPrintConfigForSupplierByCountry =
          supplierDefaultConfigService.getLabelPrintConfigForSupplier(
              supplierId,
              registrationPo.getSuID(),
              registrationPo.getRecipientCountryID()
          );

      labelPrintConfigForSupplierByCountry.stream()
          .filter(labelConfig -> labelConfig.getSupplierId().equals(registrationPo.getSuID()))
          .findFirst()
          .ifPresent(labelConfig -> {
            registrationPo.setIsLTLLabelPrintEnabled(labelConfig.isSuExtranetEnableLTL());
            registrationPo.setIsWGLabelPrintEnabled(labelConfig.isSuExtranetEnableWG());
            if (registrationPo.getRpID() != null) {
              registrationPo.setIsSPLabelPrintEnabled(labelConfig.isSuExtranetEnableRP());
            } else {
              registrationPo.setIsSPLabelPrintEnabled(labelConfig.isSuExtranetEnableSP());
            }
          });

      poItemsData.forEach(registrationPoItem -> {
        registrationPoItem.setCartons(itemsCartonsDataForPO.stream()
            .filter(carton -> Objects.equals(carton.getOpID(), registrationPoItem.getOpID()))
            .collect(Collectors.toList()));

        // We came to know a new business rule. We have tblOrderProductDetails.OdPrMinOrderQty, it means that the item
        // is sold in set of these many item.
        // For e.g, if a cup has a OdPrMinOrderQty = 6, that means user can only order the cup in multiple of 6.
        // So, valid OpQty for this order would be 6, 12, 18...
        // Now in order to find default pieceCount, we have to devide the OpQty by OdPrMinOrderQty
        int odPrMinQty = registrationPoItem.getPrMinOrderQty() != null && registrationPoItem.getPrMinOrderQty() > 0
            ? registrationPoItem.getPrMinOrderQty()
            : 1;

        int actualOpQty = registrationPoItem.getOpQty() / odPrMinQty;

        registrationPoItem.setPieceCount(
            registrationPoItem.getCartons().size() * actualOpQty);
      });

      registrationPo.setItems(poItemsData.stream()
          .filter(registrationPoItem ->
              Objects.equals(registrationPoItem.getPoNum(), registrationPo.getPoNum())
                  && Objects.equals(registrationPoItem.getRpId(), registrationPo.getRpID()))
          .collect(Collectors.toList()));
    }

    return posData;
  }

  private List<PurchaseOrderItemCarton> getCartonsData(List<RegistrationPoItem> items, List<RegistrationPo> posData) {
    var rpItemsOpIdsWithSmallParcel = items.stream()
        .filter(item -> item.getRpId() != null && hasSmallParcelShipClass(item, posData))
        .map(RegistrationPoItem::getOpID)
        .collect(Collectors.toList());

    if (
        featureToggleService.isEnabled(ENABLE_RP_CARTONS_DIMENSIONS_HARDCODING, false)
            && !CollectionUtils.isEmpty(rpItemsOpIdsWithSmallParcel)
    ) {
      var poItemCartonsRp = registrationPORepository.getHardcodedItemsCartonsDataForRP(rpItemsOpIdsWithSmallParcel);
      var poItemsOpIds = items.stream()
          //either POs or RPs with ship class not equal to Small Parcel
          .filter(item -> item.getRpId() == null
              || (item.getRpId() != null && !hasSmallParcelShipClass(item, posData)))
          .map(RegistrationPoItem::getOpID)
          .collect(Collectors.toList());
      var poItemCartonsPo = registrationPORepository.getItemsCartonsDataForPO(poItemsOpIds);

      return Stream.concat(poItemCartonsPo.stream(), poItemCartonsRp.stream())
          .collect(Collectors.toList());
    }
    return registrationPORepository.getItemsCartonsDataForPO(
        items.stream().map(RegistrationPoItem::getOpID).collect(Collectors.toList())
    );
  }

  private boolean hasSmallParcelShipClass(RegistrationPoItem item, List<RegistrationPo> posData) {
    return posData.stream()
        .anyMatch(data -> isPoNumAndRpIdMatching(item, data) && isShipClassSmallParcel(data));
  }

  private boolean isPoNumAndRpIdMatching(RegistrationPoItem item, RegistrationPo data) {
    return item.getRpId().equals(data.getRpID())
        && item.getPoNum().equals(data.getPoNum());
  }

  private boolean isShipClassSmallParcel(RegistrationPo data) {
    return data.getShipClass() != null
        && data.getShipClass() == ShipClass.SMALL_PARCEL.getShipClassId();
  }

  private Optional<RequestForPickupDate> getByRPId(List<RequestForPickupDate> registeredPOData, Integer rpID) {
    return registeredPOData.stream()
        .filter(requestForPickupDate -> Objects.equals(requestForPickupDate.getRpId(), rpID))
        .filter(requestForPickupDate -> requestForPickupDate.getRequestForPickupDate() != null)
        .findFirst();
  }

  private Optional<RequestForPickupDate> getByPONum(List<RequestForPickupDate> registeredPOData, Integer poNum) {
    return registeredPOData.stream()
        .filter(requestForPickupDate -> Objects.equals(requestForPickupDate.getPoNum(), poNum))
        .filter(requestForPickupDate -> requestForPickupDate.getRequestForPickupDate() != null)
        .findFirst();
  }
}
