package com.wayfair.registration.api.request;

import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import java.util.List;

public interface RegistrationRequestCreator {
  public List<RegistrationPo> createRegistrationRequest(
      int supplierId, List<PoData> poDataList, Integer extranetUserId, Integer employeeId);
}
