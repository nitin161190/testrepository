package com.wayfair.registration.api.request.carton.productcarton;

import com.wayfair.registration.api.request.carton.productcarton.request.CartonDimensionsRequest;
import com.wayfair.registration.api.request.carton.productcarton.request.ProductCartronsByManufacturerPartIdRequest;
import com.wayfair.registration.api.request.carton.productcarton.response.CartonDimensionsResponse;
import com.wayfair.registration.api.request.carton.productcarton.response.ProductCartonsResponse;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

@FeignClient(value = "product-carton", url = "${product-carton.url}")
public interface ProductCartonClient {

  @GetMapping(value = "/api/pcs/cartonDimensions/bySku")
  CartonDimensionsResponse getCartonDimensionsBySku(CartonDimensionsRequest request);

  @GetMapping(value = "/api/pcs/productCartons/byManufacturerPartId")
  List<ProductCartonsResponse> getCartonDimensionsByManufacturerPartId(
      ProductCartronsByManufacturerPartIdRequest request);
}
