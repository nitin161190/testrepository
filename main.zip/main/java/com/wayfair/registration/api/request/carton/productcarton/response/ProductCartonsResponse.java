package com.wayfair.registration.api.request.carton.productcarton.response;

import com.wayfair.registration.api.request.carton.productcarton.common.ManufacturerPart;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
public class ProductCartonsResponse {
  ManufacturerPart manufacturerPart;
  List<ProductCartons> productCartons;
}
