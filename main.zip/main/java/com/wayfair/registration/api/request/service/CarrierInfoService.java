package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.request.entity.CarrierInfo;
import com.wayfair.registration.api.request.repositoryc4.CarrierRepository;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class CarrierInfoService {
  private final CarrierRepository carrierRepository;

  public Optional<CarrierInfo> getCarrierInfoForByShippingCarrierIdOrThirdPartyCarrierId(Integer carrierId,
      Integer thirdPartyCarrierId) {
    // TODO: Remove this conditional block when the API stops accepting CrID
    if (thirdPartyCarrierId == null) {
      log.info("Fetching carrier info by carrier id: {}", carrierId);
      return getCarrierInfoByCarrierId(carrierId);
    }
    log.info("Fetching carrier info by third party carrier id: {}", thirdPartyCarrierId);

    return carrierRepository.getCarrierInfoByThirdPartyCarrierId(thirdPartyCarrierId);
  }

  private Optional<CarrierInfo> getCarrierInfoByCarrierId(Integer carrierId) {
    if (carrierId == null) {
      return Optional.empty();
    }
    Optional<CarrierInfo> carrierInfo = carrierRepository.getCarrierInfoByCarrierId(carrierId);

    // HACK: There may be cases when the CrTsID is not set and in these cases we will try to get
    // the TsID from table tblThirdPartyCarrier. To make this change safer the TsID will be reset
    // only in cases when there is 1-1 relation between ThirdPartyCarrier and ShipCarrier for
    // given carrier id.
    // TODO: This is a temporary solution, as a long term solution we'll request clients to send the
    //  ThirdPartyCarrierID instead of the ShipCarrierID
    if (carrierInfo.isPresent() && carrierInfo.get().getCarrierTsId() == null) {
      log.warn("Third party carrier id is not set in tblplShipCarrier for given carrier id: {}. Fetching the "
              + "third party carrier from tblThirdPartyCarrier.", carrierId);
      var thirdPartyCarrierIds = carrierRepository.getCarrierInfoFromThirdPartyCarrierByCarrierId(carrierId);
      if ((long) thirdPartyCarrierIds.size() == 1) {
        carrierInfo = Optional.ofNullable(thirdPartyCarrierIds.get(0));
      } else {
        log.warn("Found multiple or no third party carriers for given carrier id: {}. The TsID will not be set.",
            carrierId);
      }
    }

    return carrierInfo;
  }
}
