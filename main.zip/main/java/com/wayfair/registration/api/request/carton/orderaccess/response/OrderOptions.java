package com.wayfair.registration.api.request.carton.orderaccess.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class OrderOptions {

  @JsonProperty("PiID")
  private long piID;

  @JsonProperty("PiName")
  private String piName;

  @JsonProperty("PiCategory")
  private String piCategory;

  @JsonProperty("OpPiCost")
  private Double opPiCost;

}