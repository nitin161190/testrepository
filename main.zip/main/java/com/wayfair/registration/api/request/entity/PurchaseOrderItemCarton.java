package com.wayfair.registration.api.request.entity;

import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItemCarton;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(name = "RegistrationPoItemCartonMapping",
    entities = {@EntityResult(entityClass = PurchaseOrderItemCarton.class,
        fields = {
            @FieldResult(name = "id", column = "ID"),
            @FieldResult(name = "opID", column = "OpID"),
            @FieldResult(name = "boxClass", column = "BoxClass"),
            @FieldResult(name = "boxNmfc", column = "BoxNMFC"),
            @FieldResult(name = "itemCartonWeight", column = "ItemCartonWeight"),
            @FieldResult(name = "itemCartonHeight", column = "ItemCartonHeight"),
            @FieldResult(name = "itemCartonWidth", column = "ItemCartonWidth"),
            @FieldResult(name = "itemCartonDepth", column = "ItemCartonDepth"),})})
public class PurchaseOrderItemCarton {

  @Id
  String id;  // Added this just to satisfy JPA/Spring to make this class an Entity. OpID is not unique for cartons.
  BigInteger opID;
  String boxClass;
  String boxNmfc;
  BigDecimal itemCartonWeight;
  BigDecimal itemCartonHeight;
  BigDecimal itemCartonWidth;
  BigDecimal itemCartonDepth;
}
