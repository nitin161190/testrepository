package com.wayfair.registration.api.request.carton.orderaccess.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrder {

  @JsonProperty("PONum")
  private long poNum;

  @JsonProperty("OpCurrentPONum")
  private long opCurrentPONum;

  @JsonProperty("PoStorePrefix")
  private String poStorePrefix;

  @JsonProperty("SuName")
  private String suName;

  @JsonProperty("OpSuID")
  private int opSuID;

  @JsonProperty("OpSuParentSuID")
  private int opSuParentSuID;

  @JsonProperty("SuParentSuName")
  private String suParentSuName;

  @JsonProperty("WholesalePrice")
  private float wholesalePrice;

  @JsonProperty("WholesaleCurrency")
  private String wholesaleCurrency;

  @JsonProperty("CostQuoteID")
  private String costQuoteID;

  @JsonProperty("PpID")
  private long ppIDppID;

  @JsonProperty("RefProdID")
  private String refProdID;

}
