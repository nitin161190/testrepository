package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.service.FeatureToggleService;
import java.util.Collections;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;


@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrationRequestServiceProxy {
  private static final String USE_DECOUPLED_REQUEST_CREATION = "use_decoupled_registration_request_creation";

  private final FeatureToggleService featureToggleService;
  private final RegistrationRequestCreatorMonolith requestCreatorMonolith;
  private final RegistrationRequestCreatorDecoupled requestCreatorDecoupled;

  public List<RegistrationPo> createRegistrationRequest(
      int supplierId, List<PoData> poDataList, Integer extranetUserId, Integer employeeId) {
    MDC.put("input_data", poDataList.toString());
    MDC.put("supplier_id", String.valueOf(supplierId));
    MDC.put("extranet_user_id", String.valueOf(extranetUserId));
    MDC.put("employee_id", String.valueOf(employeeId));

    boolean containsRp = poDataList.get(0).getFullPurchaseOrderNumber().getRPId().isPresent();

    List<RegistrationPo> registrationRequest;
    if (!containsRp && featureToggleService.isEnabled(USE_DECOUPLED_REQUEST_CREATION, false)) {
      try {
        registrationRequest = requestCreatorDecoupled.createRegistrationRequest(
            supplierId, poDataList, extranetUserId, employeeId);
      } catch (Exception ex) {
        log.error("Exception when creating decoupled RegistrationPo for poData {}", poDataList, ex);
        registrationRequest = Collections.emptyList();
      }
      log.info("Returning decoupled RegistrationPo response {}", registrationRequest);
    } else {
      registrationRequest =
          requestCreatorMonolith.createRegistrationRequest(supplierId, poDataList, extranetUserId, employeeId);
      log.info("Returning monolith RegistrationPo response {}", registrationRequest);
    }
    return registrationRequest;
  }
}
