package com.wayfair.registration.api.request.carton.productcarton.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CallerContext {
  String applicationName;
  String methodName;
}