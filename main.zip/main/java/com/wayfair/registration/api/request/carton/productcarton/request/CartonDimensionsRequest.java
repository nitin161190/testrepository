package com.wayfair.registration.api.request.carton.productcarton.request;

import com.wayfair.registration.api.request.carton.productcarton.common.SkuOption;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CartonDimensionsRequest {

  List<SkuOption> skuOptionSets;
  CallerContext callerContext;

}