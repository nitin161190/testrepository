package com.wayfair.registration.api.request.carton.orderaccess.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import lombok.extern.jackson.Jacksonized;

@Data
@Builder
@Jacksonized
@ToString
@AllArgsConstructor
public class OrderReturn {

  @JsonProperty("RnID")
  private String rnID;

}
