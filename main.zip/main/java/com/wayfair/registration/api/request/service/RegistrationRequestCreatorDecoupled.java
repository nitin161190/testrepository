package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.TranslationHelper;
import com.wayfair.registration.api.purchaseorder.validation.ValidationService;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderFailedValidation;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderValidationFailureDetails;
import com.wayfair.registration.api.request.RegistrationRequestCreator;
import io.micrometer.core.annotation.Timed;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrationRequestCreatorDecoupled implements RegistrationRequestCreator {

  private final RegistrationRequestService registrationRequestService;
  private final ValidationService validationService;

  @Override
  @Timed
  public List<RegistrationPo> createRegistrationRequest(
      int supplierId, List<PoData> poDataList, Integer extranetUserId, Integer employeeId) {

    if (poDataList == null || poDataList.isEmpty()) {
      return Collections.emptyList();
    }

    log.debug("[Registration Request Creation] Decoupled call for Prepare-registration-data : {}", poDataList);

    List<RegistrationPo> registrationDataResponse = registrationRequestService
        .prepareRegistrationRequest(poDataList, supplierId, extranetUserId, employeeId)
        .getPoList();

    log.info("[Registration Request Creation] Prepare-registration-data Response : {}", registrationDataResponse);

    List<ShippingDocumentType> shippingDocumentTypes = poDataList.get(0).getShippingDocumentTypes();

    registrationDataResponse.forEach(registrationPo -> {
      Optional<PurchaseOrderFailedValidation> validation =
          validationService.validateRegistrationPo(shippingDocumentTypes, registrationPo);

      validation.ifPresent(failedValidation -> {
        registrationPo.setIsValid(false);
        PurchaseOrderValidationFailureDetails failureDetails =
            failedValidation.getPurchaseOrderValidationFailureDetails().stream().findFirst().get();
        registrationPo.setValidationError(TranslationHelper.builder()
            .messageId(failureDetails.getTranslationHelper().getMessageId())
            .params(failureDetails.getTranslationHelper().getParams())
            .build());
      });
    });


    if (registrationDataResponse.isEmpty()) {
      log.error("Empty user input SupplierId: {}, UserInput: {}", supplierId, poDataList);
      return Collections.emptyList();
    }

    return registrationDataResponse;
  }

}
