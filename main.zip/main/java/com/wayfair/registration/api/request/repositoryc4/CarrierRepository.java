package com.wayfair.registration.api.request.repositoryc4;

import com.wayfair.registration.api.request.entity.CarrierInfo;
import java.util.List;
import java.util.Optional;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Repository
public class CarrierRepository {

  private final EntityManager entityManager;

  public CarrierRepository(@Qualifier("c4EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public Optional<CarrierInfo> getCarrierInfoByCarrierId(Integer carrierId) {
    return Optional.ofNullable((CarrierInfo) entityManager.createNativeQuery(
            "SELECT CrID, CrName, CrTsID, CrMetaPackEnabled "
                + " FROM csn_order.dbo.tblplShipCarrier WITH (NOLOCK)"
                + " WHERE CrID=:cr_id", "CarrierInfoMapping")
        .setParameter("cr_id", carrierId)
        .getSingleResult());
  }

  @SuppressWarnings("unchecked")
  public List<CarrierInfo> getCarrierInfoFromThirdPartyCarrierByCarrierId(Integer carrierId) {
    return entityManager.createNativeQuery(
            "SELECT CrID, CrName, TsID AS CrTsID, CrMetaPackEnabled "
                + " FROM csn_order.dbo.tblplShipCarrier WITH (NOLOCK)"
                + " JOIN csn_order.dbo.tblThirdPartyCarrier WITH (NOLOCK) ON TsDefaultCrID = CrID"
                + " WHERE CrID=:cr_id", "CarrierInfoMapping")
        .setParameter("cr_id", carrierId)
        .getResultList();
  }

  public Optional<CarrierInfo> getCarrierInfoByThirdPartyCarrierId(Integer thirdPartyCarrierId) {
    try {
      return Optional.ofNullable((CarrierInfo) entityManager.createNativeQuery(
              "SELECT CrID, CrName, TsID AS CrTsID, CrMetaPackEnabled "
                  + " FROM csn_order.dbo.tblplShipCarrier WITH (NOLOCK)"
                  + " JOIN csn_order.dbo.tblThirdPartyCarrier WITH (NOLOCK) ON TsDefaultCrID = CrID"
                  + " WHERE TsID=:ts_id", "CarrierInfoMapping")
          .setParameter("ts_id", thirdPartyCarrierId)
          .getSingleResult());
    } catch (NoResultException e) {
      return Optional.empty();
    }
  }
}
