package com.wayfair.registration.api.request.entity;

import java.math.BigInteger;
import java.sql.Date;
import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;


@Entity
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(
    name = "RegistrationPOMapping",
    entities = {
        @EntityResult(
            entityClass = PurchaseOrder.class,
            fields = {
                @FieldResult(name = "fullPoNumber", column = "FullPoNumber"),
                @FieldResult(name = "poStorePrefix", column = "PoStorePrefix"),
                @FieldResult(name = "poNum", column = "PONum"),
                @FieldResult(name = "rpId", column = "RpID"),
                @FieldResult(name = "orID", column = "OrID"),
                @FieldResult(name = "soID", column = "SoID"),
                @FieldResult(name = "mkcID", column = "MkcID"),
                @FieldResult(name = "recipientCountryID", column = "RecipientCountryID"),
                @FieldResult(name = "recipientPostalCode", column = "RecipientPostalCode"),
                @FieldResult(name = "suAddress1", column = "SuAddress1"),
                @FieldResult(name = "suAddress2", column = "SuAddress2"),
                @FieldResult(name = "suAddress3", column = "SuAddress3"),
                @FieldResult(name = "suCityName", column = "SuCityName"),
                @FieldResult(name = "suStName", column = "SuStName"),
                @FieldResult(name = "suPostalCode", column = "SuPostalCode"),
                @FieldResult(name = "suCountry", column = "SuCountry"),
                @FieldResult(name = "suCountryID", column = "SuCountryID"),
                @FieldResult(name = "suID", column = "SuID"),
                @FieldResult(name = "suName", column = "SuName"),
                @FieldResult(name = "suContactNamePrimary", column = "SuContactNamePrimary"),
                @FieldResult(name = "suPhoneNumberPrimary", column = "SuPhoneNumberPrimary"),
                @FieldResult(name = "suFaxNumberPrimary", column = "SuFaxNumberPrimary"),
                @FieldResult(name = "suPhoneExtensionPrimary", column = "SuPhoneExtensionPrimary"),
                @FieldResult(name = "labelCountType", column = "labelCountType"),
                @FieldResult(name = "crName", column = "CrName"),
                @FieldResult(name = "labelPrintEnabledForCarrier", column = "isLabelPrintEnabledForCarrier"),
                @FieldResult(name = "crID", column = "CrID"),
                @FieldResult(name = "spID", column = "SpID"),
                @FieldResult(name = "poDate", column = "PODate"),
                @FieldResult(name = "estShipDate", column = "EstShipDate"),
                @FieldResult(name = "tsID", column = "TsID"),
                @FieldResult(name = "scac", column = "Scac"),
                @FieldResult(name = "shipClass", column = "ShipClass"),
                @FieldResult(name = "isWayFairBigParcelFulfillment", column = "IsWayFairBigParcelFulfillment"),
                @FieldResult(name = "packingSlip", column = "PackingSlip"),
                @FieldResult(name = "transShipAgentID", column = "TransShipAgentID"),
                @FieldResult(name = "internationalTransshipLinehaulID", column = "InternationalTransshipLinehaulID"),
                @FieldResult(name = "isSupplierShippingPartsOnOwnAccount",
                    column = "isSupplierShippingPartsOnOwnAccount"),
                @FieldResult(name = "isLTLLabelPrintEnabled", column = "isLTLLabelPrintEnabled"),
                @FieldResult(name = "isWGLabelPrintEnabled", column = "isWGLabelPrintEnabled"),
                @FieldResult(name = "isSPLabelPrintEnabled", column = "isSPLabelPrintEnabled"),
                @FieldResult(name = "isRPLabelPrintEnabled", column = "isRPLabelPrintEnabled"),
                @FieldResult(name = "supplierSubEntityID", column = "SupplierSubEntityID"),
                @FieldResult(name = "orderProductType", column = "OrderProductType"),
                @FieldResult(name = "shipVia", column = "ShipVia"),
                @FieldResult(name = "poStatusCode", column = "POStatusCode"),
                @FieldResult(name = "rpStatusCode", column = "RpStatusCode"),
            }
        )
    }
)
@EqualsAndHashCode(exclude = "internationalTransshipLinehaulID")
public class PurchaseOrder {
  @Id
  String fullPoNumber;
  String poStorePrefix;
  Integer poNum;
  Integer rpId;
  BigInteger orID;
  Integer soID;
  Integer mkcID;
  Integer recipientCountryID;
  String recipientPostalCode;
  String suAddress1;
  String suAddress2;
  String suAddress3;
  String suCityName;
  String suStName;
  String suPostalCode;
  String suCountry;
  Integer suCountryID;
  Integer suID;
  String suName;
  String suContactNamePrimary;
  String suPhoneNumberPrimary;
  String suFaxNumberPrimary;
  String suPhoneExtensionPrimary;
  Integer labelCountType;
  String crName;
  boolean labelPrintEnabledForCarrier = false;
  Integer crID;
  Integer spID;
  Date poDate;
  Date estShipDate;
  Integer tsID;
  String scac;
  Integer shipClass;
  String packingSlip;
  Integer transShipAgentID;
  Boolean isWayFairBigParcelFulfillment;
  Integer internationalTransshipLinehaulID;
  Boolean isLTLLabelPrintEnabled = Boolean.FALSE;
  Boolean isWGLabelPrintEnabled = Boolean.FALSE;
  Boolean isSPLabelPrintEnabled = Boolean.FALSE;
  Boolean isRPLabelPrintEnabled = Boolean.FALSE;
  Boolean isSupplierShippingPartsOnOwnAccount;
  Integer supplierSubEntityID;
  Integer orderProductType;
  Integer shipVia;
  Integer poStatusCode;
  Integer rpStatusCode;
}
