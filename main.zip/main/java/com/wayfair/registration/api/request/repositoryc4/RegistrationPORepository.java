package com.wayfair.registration.api.request.repositoryc4;

import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import com.wayfair.registration.api.request.entity.CountrySupplierPrintLabelConfig;
import com.wayfair.registration.api.request.entity.PurchaseOrder;
import com.wayfair.registration.api.request.entity.PurchaseOrderItem;
import com.wayfair.registration.api.request.entity.PurchaseOrderItemCarton;
import com.wayfair.registration.api.request.entity.ShipClass;
import com.wayfair.registration.api.request.entity.SupplierPrintLabelConfig;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Slf4j
@Repository
@SuppressWarnings("checkstyle:LineLength")
public class RegistrationPORepository {

  private static final Integer SMALL_PARCEL = 1;
  private static final Integer TRUCK_FREIGHT = 2;
  private static final Integer WHITE_GLOVE = 3;

  private final EntityManager entityManager;

  public RegistrationPORepository(@Qualifier("c4EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public List<CountrySupplierPrintLabelConfig> getCountrySpecificPrintConfig(int supplierId) {
    return entityManager.createNativeQuery(""
                + "SELECT"
                + "    m.MtxID,"
                + "    se.SuID,"
                + "    m.MtxShipClassID,"
                + "    m.MtxRestricted,"
                + "    m.MtxDestCyID"
                + "  FROM  csn_order.dbo.tblSupplierExt se WITH (NOLOCK)"
                + "  LEFT JOIN csn_shiprates.dbo.tblMatrix m WITH (NOLOCK) ON MtxEntID=se.SuID AND MtxEntEtyID = 1"
                + "  Where se.SuID IN (select SuID FROM csn_order.dbo.fnGetSupplierFamily(:supplierId))  "
                + "   AND m.MtxID IS NOT NULL ",
            "CountrySupplierPrintLabelConfigMapping")
        .setParameter("supplierId", supplierId)
        .getResultList();
  }

  public List<SupplierPrintLabelConfig> getLabelPrintConfigForSupplier(int supplierId) {
    return entityManager.createNativeQuery(""
                + "SELECT "
                + "  se.SuID,"
                + "  IIF(ISNULL(Matrix3rdPartyLTLShipSettings.Ships3rdParty, 0) = 1 AND ISNULL(SuExtranetEnableLTL, "
                + "0) = 1, 1, 0)"
                + "      AS SuExtranetEnableLTL, "
                + "  IIF(ISNULL(Matrix3rdPartyWGShipSettings.Ships3rdParty, 0) = 1 AND ISNULL(SuExtranetEnableWG, 0) "
                + "= 1, 1, 0) "
                + "      AS SuExtranetEnableWG, "
                + "  IIF(ISNULL(Matrix3rdPartySPShipSettings.Ships3rdParty, 0) = 1 AND ISNULL(SuExtranetEnableSP, 0) "
                + "= 1, 1, 0) "
                + "      AS SuExtranetEnableSP, "
                + "  IIF(ISNULL(Matrix3rdPartySPShipSettings.Ships3rdParty, 0) = 1 AND ISNULL(SuExtranetEnableRP, 0) "
                + "= 1, 1, 0) "
                + "      AS SuExtranetEnableRP, "
                + "  ISNULL(se.SuPartsShipOnSupplierAccount, 0) AS SuPartsShipOnSupplierAccount"
                + " FROM  csn_order.dbo.tblSupplierExt se WITH (NOLOCK)"
                + " OUTER APPLY (SELECT TOP 1 MtxActive AS Ships3rdParty"
                + "          FROM csn_shiprates.dbo.tblMatrix WITH (NOLOCK)"
                + "          WHERE MtxDestCyID IS NULL"
                + "            AND MtxShipClassID = 1"
                + "            AND MtxEntID = se.SuID"
                + "            AND MtxEntEtyID = 1"
                + "          ) AS Matrix3rdPartySPShipSettings"
                + " OUTER APPLY (SELECT TOP 1 MtxActive AS Ships3rdParty"
                + "        FROM csn_shiprates.dbo.tblMatrix WITH (NOLOCK)"
                + "        WHERE MtxDestCyID IS NULL"
                + "          AND MtxShipClassID = 2"
                + "          AND MtxEntID = se.SuID"
                + "          AND MtxEntEtyID = 1"
                + "       ) AS Matrix3rdPartyLTLShipSettings"
                + " OUTER APPLY (SELECT TOP 1 MtxActive AS Ships3rdParty"
                + "        FROM csn_shiprates.dbo.tblMatrix WITH (NOLOCK)"
                + "        WHERE MtxDestCyID IS NULL"
                + "          AND MtxShipClassID = 3"
                + "           AND MtxEntID = se.SuID"
                + "           AND MtxEntEtyID = 1"
                + "        ) AS Matrix3rdPartyWGShipSettings"
                + " WHERE se.SuID IN (select SuID FROM csn_order.dbo.fnGetSupplierFamily(:supplier_id))",
            "SupplierPrintLabelConfigMapping")
        .setParameter("supplier_id", supplierId)
        .getResultList();
  }

  /**
   * TODO: This method is used in monolith but I don't think this is needed for registration scope.
   *    Should be cleanedup later.
   */
  public List<ShipClass> getActualShipClass(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    StringBuilder query = new StringBuilder();

    List<Integer> poNumbers = getPONumbers(fullPurchaseOrderNumbers);
    if (!poNumbers.isEmpty()) {
      query.append(""
          + "          SELECT "
          + "             CONCAT(po.PoStorePrefix, op.OpCurrentPONum) AS FullPoNumber,"
          + "             po.PoStorePrefix, "
          + "             op.OpCurrentPONum AS PoNum, "
          + "             NULL AS RpID, "
          + "             MAX(sp.SpClassID) AS ActualShipClass"
          + "          FROM csn_order.dbo.tblOrderProduct op WITH(NOLOCK)"
          + "          JOIN csn_order.dbo.tblPurchaseOrder po WITH(NOLOCK) ON po.PONum = op.OpCurrentPONum"
          + "          JOIN csn_product.dbo.tblplShipSpeed sp WITH(NOLOCK) ON sp.SpID=op.OpSpID"
          + "          WHERE OpCurrentPONum IN ( " + commaSeparatedNumbers(poNumbers) + " )"
          + "          GROUP BY po.PoStorePrefix, op.OpCurrentPONum");
    }

    List<Integer> rpIds = getRPIds(fullPurchaseOrderNumbers);

    if (!rpIds.isEmpty()) {
      if (query.length() > 0) {
        query.append(" UNION ");
      }

      query.append(""
          + "          SELECT "
          + "             CONCAT(po.PoStorePrefix, op.OpCurrentPONum, '-R-', rp.RpID) AS FullPoNumber."
          + "             po.PoStorePrefix, "
          + "             rp.RpPoNum AS PoNum, "
          + "             rp.RpID, "
          + "             sp_rp.SpClassID AS ActualShipClass"
          + "          FROM csn_order.dbo.tblReplacementPart rp WITH(NOLOCK)"
          + "          JOIN csn_order.dbo.tblPurchaseOrder po WITH(NOLOCK) ON po.PONum = rp.RpPoNum"
          + "          JOIN csn_product.dbo.tblplShipSpeed sp_rp WITH(NOLOCK) ON rp.RpSpID=sp_rp.SpID"
          + "          WHERE RpID IN (" + commaSeparatedNumbers(rpIds) + ")");
    }

    return entityManager.createNativeQuery(query.toString(), "ShipClassMapping")
        .getResultList();
  }

  public List<PurchaseOrderItem> getPOItemsData(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    List<Integer> poNumbers = getPONumbers(fullPurchaseOrderNumbers);
    List<Integer> rpIds = getRPIds(fullPurchaseOrderNumbers);
    List<PurchaseOrderItem> itemsDataForPO = null;
    List<PurchaseOrderItem> itemsDataForRP = null;
    int resultSize = 0;

    if (!poNumbers.isEmpty()) {
      itemsDataForPO = getItemsDataForPO(fullPurchaseOrderNumbers);
      resultSize = itemsDataForPO.size();
    }

    if (!rpIds.isEmpty()) {
      itemsDataForRP = getItemsDataForRP(fullPurchaseOrderNumbers);
      resultSize += itemsDataForRP.size();
    }

    List<PurchaseOrderItem> result = new ArrayList<>(resultSize);
    if (itemsDataForRP != null) {
      result.addAll(itemsDataForRP);
    }

    if (itemsDataForPO != null) {
      result.addAll(itemsDataForPO);
    }

    return result;
  }

  private List<PurchaseOrderItem> getItemsDataForPO(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    return entityManager.createNativeQuery(""
            + "SELECT DISTINCT"
            + "   CONCAT(OpCurrentPONum, '-R-', 0) AS ItemId,"
            + "   OpCurrentPONum as PONum,"
            + "   NULL AS RpID,"
            + "   op.OpID as OpID,"
            + "   OpQty,"
            + "   OpComponentManufacturerPartID AS ManufacturerPartID,"
            + "   OdPrManuPartNum AS PrManuPartNum,"
            + "   OdPrName AS PrName,"
            + "   od.OdPrWeight / (CASE ISNULL(od.OdPrMinOrderQty, 1) WHEN 0 THEN 1 ELSE ISNULL(od.OdPrMinOrderQty, "
            + "1) END)"
            + "     AS PrWeight,"
            + "   OpPrSKU,"
            + "   (CASE ISNULL(od.OdPrMinOrderQty, 0) WHEN 0 THEN 1 ELSE od.OdPrMinOrderQty END) as PrMinOrderQty,"
            + "   jppo.RefProdID,"
            + "   convert(int,(select item from csn_product.dbo.Split_CLR_INT("
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\')),\',\') where listpos=1)) AS PiID1,"
            + "   convert(int,(select item from csn_product.dbo.Split_CLR_INT("
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\')),\',\') where listpos=2)) AS PiID2,"
            + "   convert(int,(select item from csn_product.dbo.Split_CLR_INT("
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\')),\',\') where listpos=3)) AS PiID3"
            + " FROM csn_order.dbo.tblOrderProduct as op WITH (NOLOCK)"
            + "   JOIN csn_order.dbo.tbljoinProductPurchaseOrder jppo WITH (NOLOCK) "
            + "     ON jppo.PONum = op.OpCurrentPONum AND jppo.OpID = op.OpID"
            + "   JOIN csn_order.dbo.tblOrderProductDetail od WITH (NOLOCK) ON op.OpID = od.OdOpID"
            + " WHERE OpCurrentPONum IN (" + commaSeparatedNumbers(getPONumbers(fullPurchaseOrderNumbers)) + ") "
            + "   AND (OpCancelled = 0 OR OpPsID <> 11)"
            + " ORDER BY OpCurrentPONum;", "RegistrationPoItemMapping")
        .getResultList();
  }

  private List<PurchaseOrderItem> getItemsDataForRP(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    return entityManager.createNativeQuery(""
            + "SELECT DISTINCT"
            + "   CONCAT(rp.RpPoNum, '-R-', rp.RpID) AS ItemId,"
            + "   rp.RpPoNum AS PONum,"
            + "   rp.RpID AS RpID,"
            + "   rp.RpOpID AS OpID,"
            + "   rp.RpQty AS OpQty,"
            + "   rp.RpPartNumber AS PrManuPartNum,"
            + "   rp.RpPartNeeded AS PrName,"
            + "   ROUND("
            + "     COALESCE(exi.ExiPartWeight, od.OdPrWeight) / "
            + "      COALESCE(exi.ExiPartBoxes, ("
            + "        CASE ISNULL(od.OdPrMinOrderQty, 1) "
            + "          WHEN 0 THEN 1 ELSE ISNULL(od.OdPrMinOrderQty, 1) "
            + "        END)),"
            + "     2"
            + "   ) AS PrWeight,"
            + "   OpPrSKU,"
            + "   (CASE ISNULL(od.OdPrMinOrderQty, 0) WHEN 0 THEN 1 ELSE od.OdPrMinOrderQty END) as PrMinOrderQty,"
            + "   COALESCE(exi.ExiPartNum, rp.RpPartNumber) AS RefProdID,"
            + "   convert(int,(select item from csn_product.dbo.Split_CLR_INT("
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\')),\',\') where listpos=1)) AS PiID1,"
            + "   convert(int,(select item from csn_product.dbo.Split_CLR_INT("
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\')),\',\') where listpos=2)) AS PiID2,"
            + "   convert(int,(select item from csn_product.dbo.Split_CLR_INT("
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\')),\',\') where listpos=3)) AS PiID3"
            + " FROM csn_order.dbo.tblReplacementPart as rp WITH (NOLOCK)"
            + "   JOIN csn_order.dbo.tblOrderProduct as op WITH (NOLOCK) ON op.OpID = rp.RpOpID"
            + "   JOIN csn_order.dbo.tblOrderProductDetail od WITH (NOLOCK) ON rp.RpOpID = od.OdOpID"
            + "   LEFT JOIN csn_extranet_fulfillment.dbo.tblExtranetOutItem exi WITH (NOLOCK) "
            + "     ON exi.ExiPoNum = rp.RpPoNum AND exi.ExiRpID = rp.RpID"
            + " WHERE rp.RpID IN (" + commaSeparatedNumbers(getRPIds(fullPurchaseOrderNumbers)) + ")"
            + " ORDER BY RpPoNum;", "RegistrationPoItemMapping")
        .getResultList();
  }

  public List<PurchaseOrderItemCarton> getItemsCartonsDataForPO(List<BigInteger> opIds) {

    return entityManager.createNativeQuery(""
            + "SELECT"
            + "   NEWID() as ID,"
            + "   op.OpID as OpID,"
            + "   BoxClass,"
            + "   BoxNMFC,"
            + "   BoxWt AS ItemCartonWeight,"
            + "   BoxH AS ItemCartonHeight,"
            + "   BoxW AS ItemCartonWidth,"
            + "   BoxD AS ItemCartonDepth"
            + " FROM csn_order.dbo.tblOrderProduct as op WITH (NOLOCK)"
            + " CROSS APPLY "
            + " csn_shiprates.dbo.fnGetProdCartons(OpPrSKU,(select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\'))) dims"
            + " WHERE OpID IN (" + commaSeparatedNumbers(opIds) + ");", "RegistrationPoItemCartonMapping")
        .getResultList();
  }

  public List<PurchaseOrderItemCarton> getHardcodedItemsCartonsDataForRP(List<BigInteger> opIds) {
    return entityManager.createNativeQuery(""
            + "SELECT"
            + "   NEWID() as ID,"
            + "   op.OpID as OpID,"
            + "   BoxClass,"
            + "   BoxNMFC,"
            + "   BoxWt AS ItemCartonWeight,"
            + "   1 AS ItemCartonHeight,"
            + "   1 AS ItemCartonWidth,"
            + "   13 AS ItemCartonDepth"
            + " FROM csn_order.dbo.tblOrderProduct as op WITH (NOLOCK)"
            + "   CROSS APPLY csn_shiprates.dbo.fnGetProdCartons(OpPrSKU, "
            + "     (select csn_order.dbo.fnGetOpIDOptions(op.OpID,\'\'))) dims"
            + " WHERE OpID IN (" + commaSeparatedNumbers(opIds) + ");", "RegistrationPoItemCartonMapping")
        .getResultList();
  }

  private String buildRPIds(List<Integer> rpIds) {
    if (!rpIds.isEmpty()) {
      return "OR ExoRpID IN (" + commaSeparatedNumbers(rpIds) + ")";
    }
    return "";
  }

  public List<PurchaseOrder> getOrdersData(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers, int supplierId) {
    var replacementParts = new ArrayList<FullPurchaseOrderNumber>();
    var purchaseOrders = new ArrayList<FullPurchaseOrderNumber>();

    for (FullPurchaseOrderNumber fullPONumber : fullPurchaseOrderNumbers) {
      if (fullPONumber.getRPId().isEmpty()) {
        purchaseOrders.add(fullPONumber);
      } else {
        replacementParts.add(fullPONumber);
      }
    }

    var ordersData = new ArrayList<PurchaseOrder>();
    ordersData.addAll(getPOsData(purchaseOrders, supplierId));
    ordersData.addAll(getRPsData(replacementParts, supplierId));

    return ordersData;
  }

  private List<PurchaseOrder> getPOsData(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers, int supplierId) {
    if (fullPurchaseOrderNumbers.isEmpty()) {
      return List.of();
    }

    return entityManager
        .createNativeQuery(
            ""
                + "SELECT DISTINCT"
                + "  CONCAT(po.PoStorePrefix, po.PONum) AS FullPoNumber,"
                + "  po.PoStorePrefix AS PoStorePrefix,"
                + "  po.PONum AS PONum,"
                + "  NULL AS RpID,"
                + "  PoOrID AS OrID,"
                + "  OrSoID AS SoID,"
                + "  SoMkcID AS MkcID,"
                + "  OpReCyID AS RecipientCountryID,"
                + "  OpRePostalCode AS RecipientPostalCode,"
                + "  SuAddress1,"
                + "  SuAddress2,"
                + "  SuAddress3,"
                + "  SuCityName,"
                + "  StShortName AS SuStName,"
                + "  SuPostalCode AS SuPostalCode,"
                + "  CyShortName AS SuCountry,"
                + "  se.SuCyID AS SuCountryID,"
                + "  su.SuID,"
                + "  SuName,"
                + "  SuContactNamePrimary,"
                + "  SuPhoneNumberPrimary,"
                + "  SuFaxNumberPrimary,"
                + "  SuPhoneExtensionPrimary,"
                + "  CASE"
                + "    WHEN ISNULL(sss.SuExtranetAutoLabelCountType, 0) = 0"
                + "      THEN 2"
                + "    ELSE sss.SuExtranetAutoLabelCountType"
                + "  END AS labelCountType,"
                + "  CrName,"
                + "  CASE"
                + "    WHEN ISNULL(CrMetaPackEnabled, 0) = 0"
                + "      THEN 0"
                + "    ELSE CrMetaPackEnabled"
                + "  END AS isLabelPrintEnabledForCarrier,"
                + "  cr.CrID,"
                + "  sp.SpID,"
                + "  PODate,"
                + "  CAST(opse.EstShipDate AS DATE) AS EstShipDate,"
                + "  COALESCE(TPC.TsID, cr.CrTsID) AS TsID,"
                + "  TsCTLCarrierCode AS Scac,"
                + "  COALESCE(exo.ExoClassID, sp.SpClassID, opse.SpClassID) AS ShipClass,"
                + "  CASE"
                + "  WHEN ISNULL(WSID, 0) = 0"
                + "    THEN 0"
                + "  ELSE 1"
                + "  END AS IsWayFairBigParcelFulfillment,"
                + "  po.PoPackingSlipPath AS PackingSlip,"
                + "  NULL AS TransShipAgentID,"
                + "  itl.ItlID as InternationalTransshipLinehaulID,"
                + "  ISNULL(se.SuPartsShipOnSupplierAccount, 0) AS isSupplierShippingPartsOnOwnAccount,"
                + "  ISNULL(se.SuExtranetEnableLTL, 0) AS isLTLLabelPrintEnabled,"
                + "  ISNULL(se.SuExtranetEnableWG, 0) AS isWGLabelPrintEnabled,"
                + "  ISNULL(se.SuExtranetEnableSP, 0) AS isSPLabelPrintEnabled,"
                + "  ISNULL(se.SuExtranetEnableRP, 0) AS isRPLabelPrintEnabled,"
                + "  su.SuStyID AS SupplierSubEntityID,"
                + "  op.OpPrType AS OrderProductType,"
                + "  pr.PrSvID AS ShipVia,"
                + "  POStatusCode,"
                + "  NULL AS RpStatusCode"
                + " FROM csn_order.dbo.tblPurchaseOrder po WITH (NOLOCK)"
                + "  JOIN csn_order.dbo.tblOrder o WITH (NOLOCK) ON o.OrID = po.PoOrID"
                + "  JOIN csn_order.dbo.tbljoinProductPurchaseOrder jppo WITH (NOLOCK) ON jppo.PONum = po.PONum"
                + "  JOIN csn_order.dbo.tblOrderProduct op WITH (NOLOCK) ON op.OpID = jppo.OpID"
                + "  JOIN csn_order.dbo.tblStore so WITH (NOLOCK) ON o.OrSoID = so.SoID"
                + "  JOIN csn_order.dbo.vwOrderProductSupplierShipEstimate opse WITH (NOLOCK) ON opse.OpID = op.OpID"
                + "  LEFT JOIN csn_extranet_fulfillment.dbo.tblExtranetOut exo WITH (NOLOCK) "
                + "      ON exo.ExoPoNum = po.PoNum AND ISNULL(exo.ExoRpID, 0) = 0"
                + "  LEFT JOIN csn_order.dbo.vwActualOrderProductRouteAgents opra WITH (NOLOCK) "
                + "      ON opra.OpID = op.OpID AND ISNULL(opra.RpID, 0) = 0"
                + "  LEFT JOIN csn_order.dbo.tblplServiceAgent sa WITH (NOLOCK) ON opra.TransShipSvaID = sa.SvaID"
                + "  LEFT JOIN csn_order.dbo.tblplState pls1 WITH (NOLOCK) ON pls1.StID = ISNULL(SvaStID, OpReStID)"
                + "  LEFT JOIN csn_order.dbo.tblplCountry a WITH (NOLOCK) ON a.CyID = ISNULL(SvaCyID, OpReCyID)"
                + "  JOIN csn_order.dbo.tblSupplier su WITH (NOLOCK) ON su.SuID = po.PoSuID"
                + "  JOIN csn_order.dbo.tblSupplierExt se WITH (NOLOCK) ON su.SuID = se.SuId"
                + "  LEFT JOIN csn_order.dbo.tblSupplierShippingSettings sss WITH (NOLOCK) ON sss.SuID = su.SuID"
                + "  LEFT JOIN csn_wms.dbo.tblWMSSupplier wmss WITH(NOLOCK) "
                + "    ON (su.SuID = wmss.WsSuID OR su.SuWFSWhID = wmss.WSWHID) AND wmss.WSSvaID IS NOT NULL"
                + "  LEFT JOIN csn_order.dbo.tblShippingLoadManifest slm WITH (NOLOCK) ON SlmFromEntityType = 1"
                + "      AND SlmFromEntityID = op.OpSuID"
                + "      AND EXISTS ("
                + "          SELECT 1 FROM csn_order.dbo.tblShippingLoadItem WITH (NOLOCK)"
                + "          WHERE SliSlmID = slm.SlmID"
                + "            AND po.PONum = SliPONum"
                + "            AND op.OpID = SliOpID"
                + "            AND ISNULL(SliRpID, 0) = 0"
                + "      )"
                + "  LEFT JOIN csn_order.dbo.tblplShipSpeed sp WITH (NOLOCK) ON sp.spID = COALESCE("
                + "     slm.SlmShipSpID, op.OpSpID)"
                + "  OUTER APPLY ( "
                + "     SELECT SfsID AS POStatusCode FROM csn_extranet.dbo.tblplSupplierFacingStatus sfs"
                + "     JOIN csn_extranet.dbo.tblplPurchaseOrderStatus os ON os.PosSfsID = sfs.SfsID"
                + "     WHERE os.PosForPurchaseOrders = 1 AND os.PosID = ("
                + "       SELECT csn_extranet.dbo.fnGetPurchaseOrderStatus(po.PONum))"
                + "  ) AS POStatusCode"
                + "  LEFT JOIN csn_order.dbo.tblThirdPartyCarrier TPC WITH (NOLOCK)"
                + "    ON COALESCE(SlmTsID, OpTsID) = TPC.TsID"
                + "  LEFT JOIN csn_order.dbo.tblplShipCarrier cr WITH (NOLOCK) ON cr.CrID = COALESCE("
                + "     TPC.TsDefaultCrID, NULLIF(slm.SlmCrID, 0), csn_order.dbo.fnGetDefaultCrID(op.OpID))"
                + "  LEFT JOIN csn_order.dbo.tblInternationalTransshipLinehaul itl WITH (NOLOCK)"
                + "    ON opra.TransshipSvaID = itl.ItlTransshipSvaID AND itl.ItlActive = 1"
                + "  INNER JOIN csn_product.dbo.tblProduct pr WITH (NOLOCK) ON op.OpPrSKU = pr.PrSKU"
                + "  WHERE ( "
                + buildWhere(fullPurchaseOrderNumbers)
                + "  )"
                + "  AND po.PoSuID IN (SELECT SuId FROM csn_order.dbo.fnGetSupplierFamily(:supplier_id));",
            "RegistrationPOMapping")
        .setParameter("supplier_id", supplierId)
        .getResultList();
  }

  private List<PurchaseOrder> getRPsData(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers, int supplierId) {
    if (fullPurchaseOrderNumbers.isEmpty()) {
      return List.of();
    }
    return entityManager
        .createNativeQuery(
            ""
                + "SELECT DISTINCT"
                + "  CONCAT(po.PoStorePrefix, po.PONum, '-R-', rp.RpID) AS FullPoNumber,"
                + "  po.PoStorePrefix AS PoStorePrefix,"
                + "  po.PONum AS PONum,"
                + "  rp.RpID AS RpID,"
                + "  PoOrID AS OrID,"
                + "  OrSoID AS SoID,"
                + "  SoMkcID AS MkcID,"
                + "  OpReCyID AS RecipientCountryID,"
                + "  OpRePostalCode AS RecipientPostalCode,"
                + "  SuAddress1,"
                + "  SuAddress2,"
                + "  SuAddress3,"
                + "  SuCityName,"
                + "  StShortName AS SuStName,"
                + "  SuPostalCode AS SuPostalCode,"
                + "  CyShortName AS SuCountry,"
                + "  se.SuCyID AS SuCountryID,"
                + "  su.SuID,"
                + "  SuName,"
                + "  SuContactNamePrimary,"
                + "  SuPhoneNumberPrimary,"
                + "  SuFaxNumberPrimary,"
                + "  SuPhoneExtensionPrimary,"
                + "  CASE"
                + "    WHEN ISNULL(sss.SuExtranetAutoLabelCountType, 0) = 0"
                + "      THEN 2"
                + "    ELSE sss.SuExtranetAutoLabelCountType"
                + "  END AS labelCountType,"
                + "  CrName,"
                + "  CASE"
                + "    WHEN ISNULL(CrMetaPackEnabled, 0) = 0"
                + "      THEN 0"
                + "    ELSE CrMetaPackEnabled"
                + "  END AS isLabelPrintEnabledForCarrier,"
                + "  cr.CrID,"
                + "  sp.SpID,"
                + "  PODate,"
                + "  rp.RpEstFillDate AS EstShipDate,"
                + "  COALESCE(TPC.TsID, cr.CrTsID) AS TsID,"
                + "  TsCTLCarrierCode AS Scac,"
                + "  COALESCE(exo.ExoClassID, sp.SpClassID, opse.SpClassID) AS ShipClass,"
                + "  CASE"
                + "  WHEN ISNULL(WSID, 0) = 0"
                + "    THEN 0"
                + "  ELSE 1"
                + "  END AS IsWayFairBigParcelFulfillment,"
                + "  po.PoPackingSlipPath AS PackingSlip,"
                + "  CASE"
                + "  WHEN ISNULL(rp.RpID, 0) <> 0 AND COALESCE(exo.ExoClassID, sp.SpClassID, opse.SpClassID) = 1"
                + "    THEN csn_order.dbo.fnGetTransShipSvaID(o.OrID, NULL, 1, su.SuID)"
                + "    ELSE NULL"
                + "  END AS TransShipAgentID,"
                + "  itl.ItlID as InternationalTransshipLinehaulID,"
                + "  ISNULL(se.SuPartsShipOnSupplierAccount, 0) AS isSupplierShippingPartsOnOwnAccount,"
                + "  ISNULL(se.SuExtranetEnableLTL, 0) AS isLTLLabelPrintEnabled,"
                + "  ISNULL(se.SuExtranetEnableWG, 0) AS isWGLabelPrintEnabled,"
                + "  ISNULL(se.SuExtranetEnableSP, 0) AS isSPLabelPrintEnabled,"
                + "  ISNULL(se.SuExtranetEnableRP, 0) AS isRPLabelPrintEnabled,"
                + "  su.SuStyID AS SupplierSubEntityID,"
                + "  op.OpPrType AS OrderProductType,"
                + "  pr.PrSvID AS ShipVia,"
                + "  NULL AS POStatusCode,"
                + "  RpStatusCode"
                + " FROM csn_order.dbo.tblPurchaseOrder po WITH (NOLOCK)"
                + "  JOIN csn_order.dbo.tblOrder o WITH (NOLOCK) ON o.OrID = po.PoOrID"
                + "  JOIN csn_order.dbo.tbljoinProductPurchaseOrder jppo WITH (NOLOCK) ON jppo.PONum = po.PONum"
                + "  JOIN csn_order.dbo.tblOrderProduct op WITH (NOLOCK) ON op.OpID = jppo.OpID"
                + "  JOIN csn_order.dbo.tblStore so WITH (NOLOCK) ON o.OrSoID = so.SoID"
                + "  JOIN csn_order.dbo.vwOrderProductSupplierShipEstimate opse WITH (NOLOCK) ON opse.OpID = op.OpID"
                + "  LEFT JOIN"
                + "  ("
                + "      SELECT pq.PqID,pq.PqPoNumForCostAssociation AS PqPONum"
                + "      FROM csn_order.dbo.tblReplaceQueue pq WITH (NOLOCK)"
                + "      WHERE pq.PqPoNumForCostAssociation IS NOT NULL"
                + "      AND pq.PqPoNumForCostAssociation IN ("
                + commaSeparatedNumbers(getPONumbers(fullPurchaseOrderNumbers))
                + "       )"
                + "       UNION ALL"
                + "       SELECT pq.PqID, pq.PqPONum AS PqPONum"
                + "       FROM csn_order.dbo.tblReplaceQueue pq WITH (NOLOCK)"
                + "       WHERE pq.PqPoNumForCostAssociation IS NULL"
                + "       AND pq.PqPONum IN ("
                + commaSeparatedNumbers(getPONumbers(fullPurchaseOrderNumbers))
                + "       )"
                + "  ) pq ON pq.PqPONum=po.PONum"
                + "  LEFT JOIN csn_order.dbo.tblReplacementPart rp WITH (NOLOCK) ON  RpPqID = PqID AND RpOpID = op.OpID"
                + "  LEFT JOIN csn_extranet_fulfillment.dbo.tblExtranetOut exo WITH (NOLOCK) "
                + "      ON exo.ExoPoNum = rp.RpPoNum AND exo.ExoRpID = rp.RpID"
                + "  LEFT JOIN csn_order.dbo.vwActualOrderProductRouteAgents opra WITH (NOLOCK) "
                + "      ON opra.OpID = op.OpID AND ISNULL(opra.RpID, 0) = rp.RpID"
                + "  LEFT JOIN csn_order.dbo.tblplServiceAgent sa WITH (NOLOCK) ON opra.TransShipSvaID = sa.SvaID"
                + "  LEFT JOIN csn_order.dbo.tblplState pls1 WITH (NOLOCK) ON pls1.StID = ISNULL(SvaStID, OpReStID)"
                + "  LEFT JOIN csn_order.dbo.tblplCountry a WITH (NOLOCK) ON a.CyID = ISNULL(SvaCyID, OpReCyID)"
                + "  JOIN csn_order.dbo.tblSupplier su WITH (NOLOCK) ON su.SuID = rp.RpSuID"
                + "  JOIN csn_order.dbo.tblSupplierExt se WITH (NOLOCK) ON su.SuID = se.SuId"
                + "  LEFT JOIN csn_order.dbo.tblSupplierShippingSettings sss WITH (NOLOCK) ON sss.SuID = su.SuID"
                + "  LEFT JOIN csn_wms.dbo.tblWMSSupplier wmss WITH(NOLOCK) "
                + "    ON (su.SuID = wmss.WsSuID OR su.SuWFSWhID = wmss.WSWHID) AND wmss.WSSvaID IS NOT NULL"
                + "  LEFT JOIN csn_order.dbo.tblplShipVia sv WITH (NOLOCK) ON RpSvID = SvID"
                + "  LEFT JOIN csn_order.dbo.tblShippingLoadManifest slm WITH (NOLOCK) ON SlmFromEntityType = 1"
                + "      AND SlmFromEntityID = op.OpSuID"
                + "      AND EXISTS ("
                + "          SELECT 1 FROM csn_order.dbo.tblShippingLoadItem WITH (NOLOCK)"
                + "          WHERE SliSlmID = slm.SlmID"
                + "            AND po.PONum = SliPONum"
                + "            AND op.OpID = SliOpID"
                + "            AND ISNULL(SliRpID, 0) = rp.RpID"
                + "      )"
                + "  LEFT JOIN csn_order.dbo.tblplShipSpeed sp WITH (NOLOCK) ON sp.spID = COALESCE("
                + "     NULLIF(rp.RpSpID, 0), slm.SlmShipSpID, SvDefaultSpID, op.OpSpID)"
                + "  OUTER APPLY ( SELECT TOP 1 * "
                + "    FROM csn_shiprates.dbo.fnGetEntitySingleThirdPartyCarrier(su.SuID, 1, op.OpReCyID, sp.SpClassID)"
                + "  ) AS rpCarrierInfo"
                + "  OUTER APPLY ("
                + "     SELECT SfsID AS RpStatusCode FROM csn_extranet.dbo.tblplSupplierFacingStatus sfs"
                + "     JOIN csn_extranet.dbo.tblplPurchaseOrderStatus os ON os.PosSfsID = sfs.SfsID"
                + "     WHERE os.PosForReplacementParts = 1 AND os.PosID = ("
                + "       SELECT csn_extranet.dbo.fnGetReplacementPartStatus(rp.RpID))"
                + "  ) AS RpStatusCode"
                + "  LEFT JOIN csn_order.dbo.tblThirdPartyCarrier TPC WITH (NOLOCK)"
                + "    ON COALESCE(exo.ExoTsID, SlmTsID, rpCarrierInfo.TsID, RpTsID, OpTsID) = TPC.TsID"
                + "  LEFT JOIN csn_order.dbo.tblplShipCarrier cr WITH (NOLOCK) ON cr.CrID = COALESCE("
                + "     TPC.TsDefaultCrID, NULLIF(slm.SlmCrID, 0), NULLIF(RpCrID, 0), "
                + "       csn_order.dbo.fnGetDefaultCrID(op.OpID))"
                + "  LEFT JOIN csn_order.dbo.tblInternationalTransshipLinehaul itl WITH (NOLOCK)"
                + "    ON opra.TransshipSvaID = itl.ItlTransshipSvaID"
                + "    AND itl.ItlActive = 1"
                + "  INNER JOIN csn_product.dbo.tblProduct pr WITH (NOLOCK) ON op.OpPrSKU = pr.PrSKU"
                + "  WHERE ( "
                + buildWhere(fullPurchaseOrderNumbers)
                + "  )"
                + " AND rp.RpSuID IN (SELECT SuId FROM csn_order.dbo.fnGetSupplierFamily(:supplier_id));",
            "RegistrationPOMapping")
        .setParameter("supplier_id", supplierId)
        .getResultList();
  }

  private String commaSeparatedNumbers(Collection<? extends Number> request) {
    return request.stream().map(String::valueOf).collect(Collectors.joining(","));
  }

  private List<Integer> getPONumbers(Collection<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    return fullPurchaseOrderNumbers.stream().map(FullPurchaseOrderNumber::getPONumber).collect(
        Collectors.toList());
  }

  private List<Integer> getRPIds(Collection<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    return fullPurchaseOrderNumbers.stream().map(FullPurchaseOrderNumber::getRPId).flatMap(Optional::stream)
        .collect(Collectors.toList());
  }

  private String buildWhere(List<FullPurchaseOrderNumber> fullPONumbers) {
    StringBuilder builder = new StringBuilder();
    for (FullPurchaseOrderNumber fullPONumber : fullPONumbers) {
      Integer poNumber = fullPONumber.getPONumber();
      Optional<Integer> rpId = fullPONumber.getRPId();

      if (builder.length() > 0) {
        builder.append(" OR ");
      }

      if (rpId.isPresent()) {
        builder.append(" (po.PONum = ")
            .append(poNumber)
            .append(" AND rp.RpId = ")
            .append(rpId.get())
            .append(") ");
      } else {
        builder.append(" (po.PONum = ")
            .append(poNumber)
            .append(") ");
      }
    }

    return builder.toString();
  }
}
