package com.wayfair.registration.api.request.service;

import com.wayfair.registration.api.client.RegistrationRequestPurestClient;
import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationDataPurestRequest;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.request.RegistrationRequestCreator;
import com.wayfair.registration.api.util.RequestContext;
import io.micrometer.core.annotation.Timed;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class RegistrationRequestCreatorMonolith implements RegistrationRequestCreator {
  public static final String REGISTRATION_DATA_RESPONSE = "registrationDataResponse";

  private final RegistrationRequestPurestClient registrationRequestPuRestClient;

  @Override
  @Timed
  public List<RegistrationPo> createRegistrationRequest(
      int supplierId, List<PoData> poDataList, Integer extranetUserId, Integer employeeId) {

    log.info("[Registration Request Creation] Purest call");

    List<RegistrationPo> registrationDataResponse = registrationRequestPuRestClient.registrationData(
        RegistrationDataPurestRequest.builder()
            .poList(poDataList)
            .supplierId(supplierId)
            .employeeId(employeeId)
            .extranetUserId(extranetUserId)
            .build());

    RequestContext.store(REGISTRATION_DATA_RESPONSE, registrationDataResponse);

    log.info("[Registration Request Creation] Purest call response {}", registrationDataResponse);
    return registrationDataResponse;
  }
}
