package com.wayfair.registration.api.request.carton.orderaccess.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class OrderSupplier {

  @JsonProperty("SuID")
  private Long suID;

  @JsonProperty("SuCuyID")
  private String suCuyID;

  @JsonProperty("VatIDNumber")
  private String vatIDNumber;

  @JsonProperty("SuParentSuID")
  private Long suParentSuID;

  @JsonProperty("SuAllowanceId")
  private Integer suAllowanceId;

  @JsonProperty("SuAllowanceAmount")
  private Float suAllowanceAmount;

}
