package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.READY_FOR_PICKUP_DATE_IN_THE_PAST;
import static com.wayfair.registration.api.purchaseorder.validation.ValidationUtils.singleFailure;
import static java.util.Collections.emptyList;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class PickupDateValidator implements RegistrationPoValidator {

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {

    if (shippingDocumentTypes.size() == 1 && shippingDocumentTypes.contains(ShippingDocumentType.PACKING_SLIP)) {
      // If the request is only for a packing slip, then the requestForPickupDate does not have to be checked
      return emptyList();
    }

    return registrationPo.getRequestForPickupDate() != null
        && registrationPo.getRequestForPickupDate().isInPast()
        ? singleFailure(READY_FOR_PICKUP_DATE_IN_THE_PAST)
        : emptyList();
  }
}
