package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.ORDER_PRODUCT_NO_WEIGHT;
import static com.wayfair.registration.api.domain.Failure.ORDER_PRODUCT_PIECE_COUNT_MISSING;
import static java.util.Collections.emptyList;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItem;
import com.wayfair.registration.api.purchaseorder.validation.ValidationUtils;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.val;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

@Component
public class OrderProductValidator implements RegistrationPoValidator {

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {
    val failures = Optional.ofNullable(registrationPo.getItems()).orElse(emptyList()).stream()
        .map(this::validateRegistrationPoItem)
        .flatMap(Collection::stream)
        .collect(Collectors.toList());

    if (sumOfPieceCountsIsNotPositive(registrationPo)) {
      failures.add(FailureAndMessageArgs.builder().failure(ORDER_PRODUCT_PIECE_COUNT_MISSING).build());
    }

    return failures;
  }

  private List<FailureAndMessageArgs> validateRegistrationPoItem(RegistrationPoItem item) {
    return Stream.of(
            Pair.of(ORDER_PRODUCT_PIECE_COUNT_MISSING, item.getPieceCount() == null
                || item.getPieceCount() < 0),
            Pair.of(ORDER_PRODUCT_NO_WEIGHT, item.getPrWeight() == null
                || item.getPrWeight().compareTo(BigDecimal.ZERO) < 1)
        )
        .filter(Pair::getRight)
        .map(Pair::getLeft)
        .map(failure -> ValidationUtils.singleFailureWithArguments(failure,
            Map.of("opId", Optional.ofNullable(item.getRefProdID()).orElse(""))))
        .flatMap(Collection::stream)
        .collect(Collectors.toList());
  }

  private boolean sumOfPieceCountsIsNotPositive(RegistrationPo registrationPo) {
    return registrationPo.getItems() != null
        && !registrationPo.getItems().isEmpty()
        && registrationPo.getItems().stream()
            .map(RegistrationPoItem::getPieceCount)
            .filter(Objects::nonNull)
            .reduce(0, Integer::sum) <= 0;
  }
}
