package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import org.springframework.lang.Nullable;

/**
 * Class named after what the set of registration data is referred to as in the PHP monolith.
 */
@Builder
@Getter
@ToString
public class PoItemData {

  @JsonProperty("part_number")
  String partNumber;

  @JsonProperty("piece_count")
  Integer pieceCount;

  @JsonProperty("unit_weight")
  BigDecimal unitWeight;

  @JsonProperty("nmfc")
  String nmfc;

  @JsonProperty("freight_class")
  String freightClass;

  @JsonProperty("piece_type")
  String pieceType;

  @JsonProperty("order_product_id")
  @Nullable
  Long orderProductId;
}
