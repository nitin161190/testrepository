package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.wayfair.registration.api.domain.ShippingDocumentType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;

/**
 * Class named after what the set of registration data is referred to as in the PHP monolith.
 */
@Builder
@Getter
@ToString
public class PoData {

  @JsonIgnore
  FullPurchaseOrderNumber fullPurchaseOrderNumber;

  @JsonProperty("full_purchase_order_number")
  String fullPoNumber;

  @JsonProperty("warehouse_id")
  Integer warehouseId;

  @JsonProperty("rfp_date")
  LocalDate rfpDate;

  @JsonProperty("is_palletized")
  boolean isPalletized;

  @JsonProperty("pallet_count")
  Integer palletCount;

  @JsonProperty("pallet_weight")
  BigDecimal palletWeight;

  boolean isRegistrationRequired;

  @JsonProperty("carrier_id")
  Integer carrierId;

  @JsonProperty("third_party_carrier_id")
  Integer thirdPartyCarrierId;

  @JsonProperty("ship_class_id")
  Integer shipClassId;

  List<ShippingDocumentType> shippingDocumentTypes;

  Map<String, PoItemData> items;
}
