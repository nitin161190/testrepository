package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderFailedValidation;
import java.util.List;
import lombok.Builder;
import lombok.Getter;

/**
 * Registration response as defined in the ticket OM-1905. Temporarily replaced with a response
 * returning Registration_PO collection to PHP monolith.
 */
@Builder
@Getter
public class OM1905RegistrationResponse {

  @JsonProperty("successful")
  List<String> successfulPoNumbers;

  @JsonProperty("failed")
  List<PurchaseOrderFailedValidation> poFailedValidations;
}
