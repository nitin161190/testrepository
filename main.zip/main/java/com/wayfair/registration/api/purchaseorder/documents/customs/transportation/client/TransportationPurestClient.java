package com.wayfair.registration.api.purchaseorder.documents.customs.transportation.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "transportation", url = "${monolith.url}")
public interface TransportationPurestClient {

  @GetMapping(value = "/purest/transportation/extranet_customs_relevance_checker_service?pos={encodedPos}")
  CustomsRelevanceResponse getCustomsRelevance(@PathVariable(name = "encodedPos") String encodedPos);

}
