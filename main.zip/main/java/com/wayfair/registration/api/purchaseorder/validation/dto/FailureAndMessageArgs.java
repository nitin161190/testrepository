package com.wayfair.registration.api.purchaseorder.validation.dto;

import com.wayfair.registration.api.domain.Failure;
import java.util.Collections;
import java.util.Map;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@ToString
@EqualsAndHashCode
public class FailureAndMessageArgs {

  private Failure failure;

  @Builder.Default
  private Map<String, String> messageArgs = Collections.emptyMap();
}
