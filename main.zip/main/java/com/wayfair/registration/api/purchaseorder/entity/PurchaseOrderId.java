package com.wayfair.registration.api.purchaseorder.entity;

import java.io.Serializable;
import javax.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PurchaseOrderId implements Serializable {

  @Column(name = "ExoPONum")
  private int purchaseOrderNumber;

  @Column(name = "ExoIsReplacement")
  private boolean isReplacement;

  @Column(name = "ExoRpID")
  private int replacementPartId;
}
