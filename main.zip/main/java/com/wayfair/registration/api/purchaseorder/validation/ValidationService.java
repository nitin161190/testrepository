package com.wayfair.registration.api.purchaseorder.validation;

import static com.wayfair.registration.api.util.MessageFormatter.formatPoMessage;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.TranslationHelper;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderFailedValidation;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderValidationFailureDetails;
import com.wayfair.registration.api.purchaseorder.validation.validators.RegistrationPoValidator;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ValidationService {

  private final List<RegistrationPoValidator> registrationPoValidators;
  private final TranslationService translationService;

  public Optional<PurchaseOrderFailedValidation> validateRegistrationPo(
      List<ShippingDocumentType> shippingDocumentTypes, RegistrationPo registrationPo) {

    List<FailureAndMessageArgs> failures = new ArrayList<>(1);

    failures.addAll(
        registrationPoValidators.stream()
            .map(registrationPoValidator -> registrationPoValidator.validate(shippingDocumentTypes, registrationPo))
            .flatMap(Collection::stream)
            .collect(Collectors.toList()));

    log.info("Validation for registrationPo=[{}] with failures=[{}]", registrationPo, failures);

    return failures.isEmpty()
        ? Optional.empty()
        : Optional.of(mapFailuresToPurchaseOrderFailedValidation(registrationPo, failures));
  }

  private PurchaseOrderFailedValidation mapFailuresToPurchaseOrderFailedValidation(
      RegistrationPo registrationPo, List<FailureAndMessageArgs> failures) {
    return PurchaseOrderFailedValidation.builder()
        .fullPurchaseOrderNumber(registrationPo.getFullPONumber())
        .purchaseOrderValidationFailureDetails(
            failures.stream()
                .map(failure -> PurchaseOrderValidationFailureDetails.builder()
                    .failureCode(failure.getFailure().getFailureCode())
                    .failureTranslationKey(failure.getFailure().getFailureTranslationKey())
                    .failureMessage(
                        formatPoMessage(
                            translationService.getTranslatedMessage(failure.getFailure().getFailureTranslationKey(),
                                Locale.getDefault()), failure.getMessageArgs()))
                    .translationHelper(
                        TranslationHelper.builder()
                            .messageId(failure.getFailure().getFailureTranslationKey())
                            .params(failure.getMessageArgs())
                            .build()
                    )
                    .build())
                .collect(Collectors.toList()))
        .build();
  }
}
