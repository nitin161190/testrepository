package com.wayfair.registration.api.purchaseorder.mapping;

import static com.wayfair.registration.api.domain.ShippingDocumentType.BOL;
import static com.wayfair.registration.api.domain.ShippingDocumentType.CUSTOMS;
import static com.wayfair.registration.api.domain.ShippingDocumentType.MANIFEST;
import static com.wayfair.registration.api.domain.ShippingDocumentType.PACKING_SLIP;
import static com.wayfair.registration.api.domain.ShippingDocumentType.SAMPLE_ORDER_LABEL;
import static com.wayfair.registration.api.domain.ShippingDocumentType.SHIPPING_LABEL;
import static com.wayfair.registration.api.domain.ShippingDocumentType.UCC;
import static java.util.Collections.emptyList;
import static java.util.Collections.emptyMap;
import static java.util.Optional.ofNullable;
import static org.springframework.util.CollectionUtils.isEmpty;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersOrderInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersOrderProductInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import com.wayfair.registration.api.purchaseorder.dto.OrderInput;
import com.wayfair.registration.api.purchaseorder.dto.OrderProduct;
import com.wayfair.registration.api.purchaseorder.dto.PhpDateTime;
import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.PoItemData;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItem;
import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrder;
import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrderItem;
import com.wayfair.registration.api.service.FeatureToggleService;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class MappingService {

  public static final String TIME_ZONE_US_EASTERN = "America/New_York";
  public static final String DEFAULT_ITEM_PIECE_TYPE = "Carton(s)";
  private static final EnumSet<ShippingDocumentType> SHIPPING_DOCUMENTS_REGISTRATION_REQUIRED = EnumSet.of(
      SHIPPING_LABEL, UCC, BOL);

  private static final String ENABLE_REGISTRATION_WITH_OPID_MAPPING = "so_enable_order_registration_with_op_id_mapping";
  private final FeatureToggleService featureToggleService;

  public List<PurchaseOrder> mapToPurchaseOrders(
      List<RegistrationPo> registrationPos, Integer employeeId, Integer extranetUserId
  ) {
    return registrationPos.stream()
        .map(registrationPo -> {
          // Parcel info for secondary RPs in a consolidated unit is included in the primary RP's purchase order item.
          var zeroOutParcelInfo = registrationPo.isReplacementPart() && !registrationPo.isPrimaryReplacementPart();
          return PurchaseOrder.builder()
              .purchaseOrderNumber(registrationPo.getPoNum())
              .orderId(registrationPo.getOrID())
              .storeId(registrationPo.getSoID())
              .marketingCategoryId(registrationPo.getMkcID())
              .supplierAddress1(registrationPo.getSuAddress1())
              .supplierAddress2(registrationPo.getSuAddress2())
              .supplierAddress3(registrationPo.getSuAddress3())
              .supplierState(registrationPo.getSuStName())
              .supplierPostalCode(registrationPo.getSuPostalCode())
              .supplierCountry(registrationPo.getSuCountry())
              .supplierId(registrationPo.getSuID())
              .supplierName(registrationPo.getSuName())
              .supplierContact(registrationPo.getSuContactNamePrimary())
              .supplierPhone(registrationPo.getSuPhoneNumberPrimary())
              .supplierFax(registrationPo.getSuFaxNumberPrimary())
              .supplierPhoneNumberExtension(registrationPo.getSuPhoneExtensionPrimary())
              .carrierName(registrationPo.getCrName())
              .purchaseOrderDate(getLocalDateTimeOrNull(registrationPo.getPoDate()))
              .maxShipDate(getLocalDateTimeOrNull(registrationPo.getEstShipDate()))
              .readyForPickupDate(getLocalDateTimeOrNull(registrationPo.getRequestForPickupDate()))
              .purchaseOrderDateTz(getLocalDateTimeInUsEasternTzOrNull(registrationPo.getPoDate()))
              .maxShipDateTz(getLocalDateTimeInUsEasternTzOrNull(registrationPo.getEstShipDate()))
              .isReplacement(registrationPo.isReplacementPart())
              .replacementPartId(ofNullable(registrationPo.getRpID()).orElse(0))
              .thirdPartyCarrierId(registrationPo.getTsID())
              .scacCode(registrationPo.getScac())
              .classId(registrationPo.getShipClass())
              .isPalletized(zeroOutParcelInfo ? Boolean.FALSE : registrationPo.getIsPOPalletized())
              .palletCount(zeroOutParcelInfo ? (Integer) 0 : registrationPo.getPalletCount())
              .palletWeight(zeroOutParcelInfo ? BigDecimal.ZERO : registrationPo.getPalletWeight())
              .shipClassId(registrationPo.getShipClass())
              .readyForPickupDateTz(getLocalDateTimeInUsEasternTzOrNull(registrationPo.getRequestForPickupDate()))
              .lastReviewedExtranetUserId(extranetUserId)
              .lastReviewedEmployeeId(employeeId)
              .build();
        })
        .collect(Collectors.toList());
  }

  /**
   * Maps RegistrationPo list into two lists of PurchaseOrderItem, one for creating and one for updating. This
   * workaround is required as for items received from monolith there's no ID available to leverage JPA repository. The
   * update is done via a custom method looking for records based on three fields of PurchaseOrderItem.
   *
   * @return first element of the pair is a list of PurchaseOrderItem to create, the latter list is to update existing
   *     entities.
   */
  public Pair<List<PurchaseOrderItem>, List<PurchaseOrderItem>> mapToPurchaseOrderItems(
      List<RegistrationPo> registrationPos, Integer employeeId, Integer extranetUserId) {

    List<PurchaseOrderItem> purchaseOrderItemsToCreate = new ArrayList<>();
    List<PurchaseOrderItem> purchaseOrderItemsToUpdate = new ArrayList<>();

    for (RegistrationPo registrationPo : registrationPos) {
      var purchaseOrderItems = registrationPoToPurchaseOrderItems(registrationPo, employeeId, extranetUserId);

      if (registrationPo.isRegistered()) {
        purchaseOrderItemsToUpdate.addAll(purchaseOrderItems);
      } else {
        purchaseOrderItemsToCreate.addAll(purchaseOrderItems);
      }
    }

    return Pair.of(purchaseOrderItemsToCreate, purchaseOrderItemsToUpdate);
  }

  private List<PurchaseOrderItem> registrationPoToPurchaseOrderItems(
      RegistrationPo registrationPo, Integer employeeId, Integer extranetUserId
  ) {
    return registrationPo.getItems()
        .stream()
        .map(item -> {
          // Parcel info for secondary RPs in a consolidated unit is included in the primary RP's purchase order item.
          var zeroOutParcelInfo = registrationPo.isReplacementPart() && !registrationPo.isPrimaryReplacementPart();
          return PurchaseOrderItem.builder()
              .purchaseOrderNumber(item.getPoNum())
              .orderProductId(item.getOpID())
              .quantity(item.getOpQty())
              .partNumber(item.getRefProdID())
              .itemName(item.getPrName())
              .productSKU(item.getOpPrSKU())
              .estimatedShipDate(getLocalDateTimeOrNull(registrationPo.getRequestForPickupDate()))
              .estimatedShipDatetz(getLocalDateTimeInUsEasternTzOrNull(registrationPo.getRequestForPickupDate()))
              .isReplacement(registrationPo.isReplacementPart())
              .replacementPartId(registrationPo.getRpID())
              .shipClassId(registrationPo.getShipClass())
              .productItemId1(item.getPiID1())
              .productItemId2(item.getPiID2())
              .productItemId3(item.getPiID3())
              .lastReviewedExtranetUserId(extranetUserId)
              .lastReviewedEmployeeId(employeeId)
              .partWeight(zeroOutParcelInfo ? BigDecimal.ZERO : item.getPrWeight())
              .partBoxes(zeroOutParcelInfo ? (Integer) 0 : item.getPieceCount())
              .boxClass(zeroOutParcelInfo || isEmpty(item.getCartons()) ? null : item.getCartons().get(0).getBoxClass())
              .nmfc(zeroOutParcelInfo || isEmpty(item.getCartons()) ? null : item.getCartons().get(0).getBoxNmfc())
              .pieceType(
                  zeroOutParcelInfo || item.getPieceType() == null ? DEFAULT_ITEM_PIECE_TYPE : item.getPieceType())
              .build();
        })
        .collect(Collectors.toList());
  }

  public List<PoData> mapToRegistrationPoDataList(List<OrderInput> orderInputs) {
    return orderInputs.stream()
        .map(orderInput -> PoData.builder()
            .fullPurchaseOrderNumber(new FullPurchaseOrderNumber(orderInput.getFullPoNumber()))
            .fullPoNumber(orderInput.getFullPoNumber())
            .shipClassId(orderInput.getShipClassId())
            .warehouseId(orderInput.getSupplierId())
            .rfpDate(orderInput.getReadyForPickupDate())
            .isPalletized(ofNullable(orderInput.getIsPalletized()).orElse(false))
            .palletCount(ofNullable(orderInput.getPalletCount()).orElse(0))
            .palletWeight(ofNullable(orderInput.getPalletWeight()).orElse(BigDecimal.ZERO))
            .isRegistrationRequired(
                containsAnyOfShippingDocumentTypesForWhichRegistrationIsRequired(
                    orderInput.getShippingDocumentTypes()))
            .carrierId(orderInput.getCarrierId())
            .shippingDocumentTypes(orderInput.getShippingDocumentTypes())
            .items(mapOrderProductsToPoItemData(orderInput))
            .build())
        .collect(Collectors.toList());
  }

  public List<PoData> mapToRegistrationPoDataList(SoOrderManagementRegisterOrdersInput ordersInput) {
    List<ShippingDocumentType> shippingDocumentTypes = mapShippingDocumentTypes(ordersInput.getShippingDocumentTypes());

    return ordersInput.getOrders()
        .stream()
        .map(orderInput -> {
          LocalDate rfpDate = orderInput.getReadyForPickupDate() == null
              ? null : orderInput.getReadyForPickupDate().toLocalDate();

          log.info("readyForPickupDate - input [{}], final [{}]", orderInput.getReadyForPickupDate(), rfpDate);

          return PoData.builder()
              .fullPurchaseOrderNumber(
                  new FullPurchaseOrderNumber(orderInput.getFullPurchaseOrderNumber()))
              .fullPoNumber(orderInput.getFullPurchaseOrderNumber())
              .shipClassId(orderInput.getShipClassId())
              .warehouseId(orderInput.getWarehouseId())
              .rfpDate(rfpDate)
              .isPalletized(isPalletized(orderInput))
              .palletCount(getPalletCount(orderInput))
              .palletWeight(getPalletWeight(orderInput))
              .isRegistrationRequired(
                  containsAnyOfShippingDocumentTypesForWhichRegistrationIsRequired(
                      shippingDocumentTypes))
              .carrierId(orderInput.getCarrierId())
              .thirdPartyCarrierId(orderInput.getThirdPartyCarrierId())
              .shippingDocumentTypes(shippingDocumentTypes)
              .items(mapOrderProductsToPoItemData(orderInput))
              .build();
        })
        .collect(Collectors.toList());
  }

  private BigDecimal getPalletWeight(SoOrderManagementRegisterOrdersOrderInput orderInput) {
    if (orderInput.getPalletization() == null
        || orderInput.getPalletization().getPalletWeight() == null) {
      return BigDecimal.ZERO;
    }

    return BigDecimal.valueOf(orderInput.getPalletization().getPalletWeight());
  }

  private Integer getPalletCount(SoOrderManagementRegisterOrdersOrderInput orderInput) {
    if (orderInput.getPalletization() == null) {
      return 0;
    }

    return orderInput.getPalletization().getPalletCount();
  }

  private boolean isPalletized(SoOrderManagementRegisterOrdersOrderInput orderInput) {
    if (orderInput.getPalletization() == null) {
      return false;
    }

    return orderInput.getPalletization().getIsPalletized();
  }

  private List<ShippingDocumentType> mapShippingDocumentTypes(
      List<SoOrderManagementShippingDocumentType> shippingDocumentTypes
  ) {
    if (shippingDocumentTypes == null) {
      return emptyList();
    }

    return shippingDocumentTypes.stream()
        .map(this::fromSoOrderManagementShippingDocumentType)
        .collect(Collectors.toList());
  }

  private ShippingDocumentType fromSoOrderManagementShippingDocumentType(
      SoOrderManagementShippingDocumentType soOrderManagementShippingDocumentType
  ) {
    switch (soOrderManagementShippingDocumentType) {
      case CUSTOMS:
        return CUSTOMS;
      case MANIFEST:
        return MANIFEST;
      case UCC:
        return UCC;
      case BILL_OF_LADING:
        return BOL;
      case SHIPPING_LABEL:
        return SHIPPING_LABEL;
      case PACKING_SLIP:
        return PACKING_SLIP;
      case SAMPLE_ORDER_LABEL:
        return SAMPLE_ORDER_LABEL;
      default:
        return null;
    }
  }

  private Map<String, PoItemData> mapOrderProductsToPoItemData(OrderInput orderInput) {
    List<OrderProduct> orderProducts = isEmpty(orderInput.getOrderProducts())
        ? orderInput.getReplacementParts()
        : orderInput.getOrderProducts();

    boolean isOpIdMapped = featureToggleService
        .isEnabled(ENABLE_REGISTRATION_WITH_OPID_MAPPING, false);

    return isEmpty(orderProducts)
        ? emptyMap()
        : orderProducts.stream()
        .collect(Collectors.toMap(
            orderProduct -> this.getOrderProductMappingKey(orderProduct, isOpIdMapped),
            orderProduct -> PoItemData.builder()
                .partNumber(orderProduct.getPartNumber())
                .pieceCount(orderProduct.getPieceCount())
                .unitWeight(orderProduct.getUnitWeight())
                .nmfc(orderProduct.getNmfc())
                .freightClass(orderProduct.getFreightClass())
                .pieceType(orderProduct.getPieceType())
                .orderProductId(orderProduct.getOrderProductId())
                .build(), (op1, op2) -> op1
        ));
  }

  private Map<String, PoItemData> mapOrderProductsToPoItemData(
      SoOrderManagementRegisterOrdersOrderInput orderInput
  ) {
    List<SoOrderManagementRegisterOrdersOrderProductInput> orderProducts = isEmpty(
        orderInput.getOrderProducts())
        ? orderInput.getReplacementParts()
        : orderInput.getOrderProducts();

    boolean isOpIdMapped = featureToggleService
        .isEnabled(ENABLE_REGISTRATION_WITH_OPID_MAPPING, false);

    return isEmpty(orderProducts)
        ? emptyMap()
        : orderProducts.stream()
        .collect(Collectors.toMap(
            orderProduct -> this.getOrderProductMappingKey(orderProduct, isOpIdMapped),
            orderProduct -> PoItemData.builder()
                .partNumber(orderProduct.getPartNumber())
                .pieceCount(orderProduct.getPieceCount())
                .unitWeight(BigDecimal.valueOf(orderProduct.getUnitWeight()))
                .nmfc(orderProduct.getNmfc())
                .freightClass(orderProduct.getFreightClass())
                .pieceType(String.valueOf(orderProduct.getPieceType()))
                .orderProductId(orderProduct.getOrderProductId())
                .build(), (op1, op2) -> op1
        ));
  }

  private String getOrderProductMappingKey(OrderProduct orderProduct, boolean isOpIdMapped) {
    //Set OpID as key if present, else PartNumber will be set as key
    if (orderProduct.getOrderProductId() == null) {
      return orderProduct.getPartNumber();
    }

    return isOpIdMapped
        ? orderProduct.getOrderProductId().toString()
        : orderProduct.getPartNumber();
  }

  private String getOrderProductMappingKey(
      SoOrderManagementRegisterOrdersOrderProductInput orderProduct, boolean isOpIdMapped
  ) {
    //Set OpID as key if present, else PartNumber will be set as key
    if (orderProduct.getOrderProductId() == null) {
      return orderProduct.getPartNumber();
    }

    return isOpIdMapped
        ? orderProduct.getOrderProductId().toString()
        : orderProduct.getPartNumber();
  }

  private boolean containsAnyOfShippingDocumentTypesForWhichRegistrationIsRequired(
      List<ShippingDocumentType> documentTypes
  ) {
    return ofNullable(documentTypes).map(shippingDocumentTypes -> shippingDocumentTypes.stream()
        .anyMatch(SHIPPING_DOCUMENTS_REGISTRATION_REQUIRED::contains)).orElse(false);
  }

  private OffsetDateTime getLocalDateTimeInUsEasternTzOrNull(PhpDateTime phpDateTime) {
    return phpDateTime != null ? phpDateTime.getZonedDateTime().toOffsetDateTime() : null;
  }

  private LocalDate getLocalDateTimeOrNull(PhpDateTime phpDateTime) {
    return ofNullable(phpDateTime).map(PhpDateTime::getLocalDate).orElse(null);
  }

  /**
   * Quoting description of the code counterpart in PHP monolith: For replacement part, we need to re-calculate the unit
   * weight. Since, from old order management we are accepting unit-weight as per quantity of the item but in OMR we are
   * accepting unit weight as per piece count. So, for old OM totalWeight = unitWeight * quantity For OMR totalWeight =
   * pieceCount * avgWeight [which is (unitWeight * quantity)] At this point, totalWeight is already calculated in
   * `registration_request_service` We can't change the logic in `registration_request_service` since it is being used
   * in both old OM and new OM
   */
  public void adjustWeightOnReplacementItems(List<RegistrationPo> registrationData) {
    for (RegistrationPo registrationPo : registrationData) {
      if (registrationPo.isReplacementPart() && !isEmpty(registrationPo.getItems())) {
        for (RegistrationPoItem item : registrationPo.getItems()) {
          if (item.getPrWeight() != null && item.getPieceCount() != null) {
            item.setPrWeight(item.getPrWeight()
                .multiply(BigDecimal.valueOf(item.getPieceCount()))
                .divide(BigDecimal.valueOf(ofNullable(item.getOpQty()).orElse(1)), 2,
                    RoundingMode.HALF_UP
                ));
          }
        }
      }
    }
  }
}
