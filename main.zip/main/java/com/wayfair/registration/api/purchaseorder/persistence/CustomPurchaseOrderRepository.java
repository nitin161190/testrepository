package com.wayfair.registration.api.purchaseorder.persistence;

import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import com.wayfair.registration.api.purchaseorder.entity.RequestForPickupDate;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class CustomPurchaseOrderRepository {
  private final EntityManager entityManager;

  public CustomPurchaseOrderRepository(@Qualifier("c149EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public List<RequestForPickupDate> getRegisteredPOData(List<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    List<Integer> poNumbers = getPONumbers(fullPurchaseOrderNumbers);
    List<Integer> rpIds = getRPIds(fullPurchaseOrderNumbers);

    StringBuilder query = new StringBuilder();

    query.append(""
        + "        SELECT "
        + "            CONCAT(exo.ExoPONum, '-R-', exo.ExoRpID) AS ExoId, "
        + "            exo.ExoPONum as PoNum, "
        + "            exo.ExoRpID as RpID, "
        + "            exo.ExoRfpDate as RequestForPickupDate"
        + "        FROM csn_extranet_fulfillment.dbo.tblExtranetOut exo WITH (NOLOCK)"
        + "        WHERE ExoPONum IN (").append(commaSeparatedNumbers(poNumbers)).append(" ) ");

    if (!rpIds.isEmpty()) {
      query.append("UNION"
          + "        SELECT "
          + "           CONCAT(exo.ExoPONum, '-R-', exo.ExoRpID) AS ExoId, "
          + "           exo.ExoPONum as PoNum, "
          + "           exo.ExoRpID as RpID, "
          + "           exo.ExoRfpDate as RequestForPickupDate"
          + "        FROM csn_extranet_fulfillment.dbo.tblExtranetOut exo WITH (NOLOCK)"
          + "        WHERE ExoRpID IN (").append(commaSeparatedNumbers(rpIds)).append(")");
    }

    return entityManager
        .createNativeQuery(query.toString(), "RequestForPickupDateMapping")
        .getResultList();
  }

  private String commaSeparatedNumbers(Collection<? extends Number> request) {
    return request.stream().map(String::valueOf).collect(Collectors.joining(","));
  }

  private List<Integer> getPONumbers(Collection<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    return fullPurchaseOrderNumbers.stream().map(FullPurchaseOrderNumber::getPONumber).collect(
        Collectors.toList());
  }

  private List<Integer> getRPIds(Collection<FullPurchaseOrderNumber> fullPurchaseOrderNumbers) {
    return fullPurchaseOrderNumbers.stream().map(FullPurchaseOrderNumber::getRPId).flatMap(Optional::stream)
        .collect(Collectors.toList());
  }
}
