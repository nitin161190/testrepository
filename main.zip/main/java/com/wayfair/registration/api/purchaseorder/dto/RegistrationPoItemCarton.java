package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.math.BigInteger;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RegistrationPoItemCarton {

  BigInteger opID;
  String boxClass;
  @JsonProperty("boxNMFC")
  String boxNmfc;
  BigDecimal itemCartonWeight;
  BigDecimal itemCartonHeight;
  BigDecimal itemCartonWidth;
  BigDecimal itemCartonDepth;

}
