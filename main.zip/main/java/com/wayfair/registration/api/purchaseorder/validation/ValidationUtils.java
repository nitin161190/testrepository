package com.wayfair.registration.api.purchaseorder.validation;

import static java.util.Collections.singletonList;

import com.wayfair.registration.api.domain.Failure;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.List;
import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ValidationUtils {

  public static List<FailureAndMessageArgs> singleFailure(Failure failure) {
    return singletonList(FailureAndMessageArgs.builder().failure(failure).build());
  }

  public static List<FailureAndMessageArgs> singleFailure(Failure failure, String messageArgumentId,
                                                          String messageArgumentValue) {
    return singletonList(FailureAndMessageArgs.builder()
        .failure(failure)
        .messageArgs(Map.of(messageArgumentId, messageArgumentValue))
        .build());
  }

  public static List<FailureAndMessageArgs> singleFailureWithArguments(Failure failure,
                                                                       Map<String, String> messageArguments) {
    return singletonList(FailureAndMessageArgs.builder()
        .failure(failure)
        .messageArgs(messageArguments)
        .build());
  }
}
