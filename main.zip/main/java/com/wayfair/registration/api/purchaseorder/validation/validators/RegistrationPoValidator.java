package com.wayfair.registration.api.purchaseorder.validation.validators;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.List;

public interface RegistrationPoValidator {

  List<FailureAndMessageArgs> validate(List<ShippingDocumentType> shippingDocumentTypes, RegistrationPo registrationPo);

}
