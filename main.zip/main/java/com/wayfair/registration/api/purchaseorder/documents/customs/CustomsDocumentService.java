package com.wayfair.registration.api.purchaseorder.documents.customs;

import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.TransportationService;
import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.client.CustomsRelevanceResponse;
import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.client.CustomsSettings;
import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.dto.CustomsRelevanceRequest;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomsDocumentService {

  private static final String SUCCESS_RESULT_FIELD_VALUE = "success";

  private final TransportationService transportationService;

  public boolean isCustomsDocumentRequired(FullPurchaseOrderNumber purchaseOrderNumber, int thirdPartyId) {
    try {
      CustomsRelevanceRequest request = CustomsRelevanceRequest.builder()
          .purchaseOrderNumber(purchaseOrderNumber.getFullPONumber())
          .thirdPartyId(thirdPartyId)
          .build();

      CustomsRelevanceResponse customsRelevance = transportationService.getCustomsRelevance(request);

      if (!customsRelevance.getResult().equals(SUCCESS_RESULT_FIELD_VALUE)) {
        throw new RuntimeException("Customs relevance API returned a non-success result");
      }

      CustomsSettings poCustomsRelevanceData = customsRelevance.getData().values().stream().findFirst()
          .orElseThrow(() -> new RuntimeException(
              "Malformed response from Transportation PuREST client, expected one entry: " + customsRelevance));

      return poCustomsRelevanceData.isRequiresCustomDocuments();
    } catch (RuntimeException e) {
      log.error("Could not retrieve customs information for PO=[{}], thirdPartyId=[{}]",
          purchaseOrderNumber.getFullPONumber(), thirdPartyId, e);
      throw new RuntimeException("Could not retrieve customs information", e);
    }

  }

}
