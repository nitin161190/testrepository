package com.wayfair.registration.api.purchaseorder.documents.customs.transportation.client;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class CustomsSettings {

  @JsonProperty("requires_custom_documents")
  boolean requiresCustomDocuments;

  @JsonProperty("consolidation_disabled")
  boolean consolidationDisabled;

  @JsonProperty("multibox_disabled")
  boolean multiboxDisabled;

  @JsonProperty("is_cross_border")
  boolean crossBorder;

}
