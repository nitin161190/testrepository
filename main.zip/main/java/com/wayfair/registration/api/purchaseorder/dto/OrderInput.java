package com.wayfair.registration.api.purchaseorder.dto;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderInput {

  String fullPoNumber;

  Integer supplierId;

  Integer extranetUserId;

  Integer employeeId;

  LocalDate readyForPickupDate;

  Integer shipClassId;

  Boolean isPalletized;

  Integer palletCount;

  BigDecimal palletWeight;

  Integer carrierId;

  List<ShippingDocumentType> shippingDocumentTypes;

  List<OrderProduct> orderProducts;

  List<OrderProduct> replacementParts;
}
