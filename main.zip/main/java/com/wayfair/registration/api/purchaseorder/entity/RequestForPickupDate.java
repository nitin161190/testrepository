package com.wayfair.registration.api.purchaseorder.entity;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Builder
@Getter
@NoArgsConstructor
@AllArgsConstructor
@SqlResultSetMapping(name = "RequestForPickupDateMapping",
    entities = {@EntityResult(entityClass = RequestForPickupDate.class,
        fields = {
            @FieldResult(name = "exoId", column = "ExoId"),
            @FieldResult(name = "poNum", column = "PoNum"),
            @FieldResult(name = "rpId", column = "RpID"),
            @FieldResult(name = "requestForPickupDate", column = "RequestForPickupDate")})})
public class RequestForPickupDate {
  @Id
  String exoId;
  Integer poNum;
  Integer rpId;
  String requestForPickupDate;

}
