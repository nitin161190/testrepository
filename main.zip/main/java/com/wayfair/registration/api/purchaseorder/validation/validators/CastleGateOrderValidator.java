package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.HAS_CASTLE_GATE_ORDER;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.persistence.CastleGateOrdersRepository;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class CastleGateOrderValidator implements RegistrationPoValidator {

  private final CastleGateOrdersRepository castleGateOrdersRepository;

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {
    log.debug("Validating on CG orders for PO number {}", registrationPo.getFullPONumber());

    boolean isCastleGateOrder = castleGateOrdersRepository.isCastleGateOrder(
        registrationPo.getPoNum());

    if (isCastleGateOrder) {
      return List.of(FailureAndMessageArgs.builder()
          .failure(HAS_CASTLE_GATE_ORDER)
          .messageArgs(Map.of("poNum", registrationPo.getFullPONumber()))
          .build());
    }

    return Collections.emptyList();
  }

}
