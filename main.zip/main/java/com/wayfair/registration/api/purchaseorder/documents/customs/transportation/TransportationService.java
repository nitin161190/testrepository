package com.wayfair.registration.api.purchaseorder.documents.customs.transportation;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.client.CustomsRelevanceResponse;
import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.client.TransportationPurestClient;
import com.wayfair.registration.api.purchaseorder.documents.customs.transportation.dto.CustomsRelevanceRequest;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class TransportationService {

  private final TransportationPurestClient transportationClient;

  @SneakyThrows
  public CustomsRelevanceResponse getCustomsRelevance(CustomsRelevanceRequest request) {
    String jsonRequest = new ObjectMapper().writeValueAsString(List.of(request));
    String encodedPos = URLEncoder.encode(jsonRequest, StandardCharsets.UTF_8.toString());

    log.info("Sending customs relevance call for request [{}] with payload [{}]", request, encodedPos);
    CustomsRelevanceResponse customsRelevance = transportationClient.getCustomsRelevance(encodedPos);
    log.info("Received customs relevance response [{}] for request [{}]", customsRelevance, request);

    return customsRelevance;
  }

}
