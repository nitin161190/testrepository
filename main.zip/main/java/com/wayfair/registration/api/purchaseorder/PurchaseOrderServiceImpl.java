package com.wayfair.registration.api.purchaseorder;

import static com.wayfair.registration.api.purchaseorder.PurchaseOrderMetrics.REFRESH_REQUESTS_PROCESSED_TIMER;
import static com.wayfair.registration.api.purchaseorder.PurchaseOrderMetrics.REFRESH_REQUESTS_RECEIVED_COUNTER;
import static com.wayfair.registration.api.purchaseorder.PurchaseOrderMetrics.REGISTRATION_BULK_REQUESTS_RECEIVED_COUNTER;
import static com.wayfair.registration.api.purchaseorder.PurchaseOrderMetrics.REGISTRATION_REQUESTS_RECEIVED_COUNTER;
import static com.wayfair.registration.api.purchaseorder.PurchaseOrderMetrics.REGISTRATION_SINGLE_REQUESTS_RECEIVED_COUNTER;

import com.google.common.annotations.VisibleForTesting;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistration;
import com.wayfair.registration.api.bulkregistration.service.BulkRegistrationService;
import com.wayfair.registration.api.client.DeleteSlmOverpackPuRestClient;
import com.wayfair.registration.api.dto.DeleteSlmOverpackRequest;
import com.wayfair.registration.api.dto.PurchaseOrderNumber;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersOrderRegistrationResult;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersPayload;
import com.wayfair.registration.api.labeldata.LabelDataClient;
import com.wayfair.registration.api.labeldata.LabelDataRefreshRequest;
import com.wayfair.registration.api.ordercrud.OrderCrudEventProducer;
import com.wayfair.registration.api.orderproduct.OrderProductService;
import com.wayfair.registration.api.purchaseorder.dto.OrderInput;
import com.wayfair.registration.api.purchaseorder.dto.PoData;
import com.wayfair.registration.api.purchaseorder.dto.RefreshPurchaseOrderResultMapping;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.TranslationHelper;
import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrderId;
import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrderItem;
import com.wayfair.registration.api.purchaseorder.mapping.MappingService;
import com.wayfair.registration.api.purchaseorder.persistence.PersistenceService;
import com.wayfair.registration.api.purchaseorder.persistence.PurchaseOrderItemRepository;
import com.wayfair.registration.api.purchaseorder.persistence.PurchaseOrderRepository;
import com.wayfair.registration.api.replacementparts.ReplacementPartsClient;
import com.wayfair.registration.api.request.service.RegistrationRequestServiceProxy;
import com.wayfair.registration.api.util.MdcUtil;
import datadog.trace.api.Trace;
import io.github.resilience4j.retry.annotation.Retry;
import io.micrometer.core.annotation.Counted;
import io.micrometer.core.annotation.Timed;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PurchaseOrderServiceImpl implements PurchaseOrderService {
  private final LabelDataClient labelDataClient;
  private final ReplacementPartsClient replacementPartsClient;
  private final OrderProductService orderProductService;
  private final PurchaseOrderRepository purchaseOrderRepository;
  private final PurchaseOrderItemRepository purchaseOrderItemRepository;
  private final OrderCrudEventProducer orderCrudEventProducer;
  private final MappingService mappingService;
  private final PersistenceService persistenceService;
  private final DeleteSlmOverpackPuRestClient deleteSlmOverpackPuRestClient;
  private final RegistrationRequestServiceProxy registrationRequestServiceProxy;
  private final BulkRegistrationService bulkRegistrationService;
  private final PurchaseOrderMetrics purchaseOrderMetrics;

  @Trace
  @Override
  @Counted(REGISTRATION_SINGLE_REQUESTS_RECEIVED_COUNTER)
  public List<RegistrationPo> singleRegistration(OrderInput orderInput) {
    if (orderInput == null) {
      log.info("PurchaseOrderServiceImpl.singleRegistration called with empty Po list");
      return Collections.emptyList();
    }

    return registerPurchaseOrders(List.of(orderInput));
  }

  @Trace
  @Override
  @Counted(REGISTRATION_BULK_REQUESTS_RECEIVED_COUNTER)
  public List<RegistrationPo> bulkRegistration(List<OrderInput> orderInputs) {
    if (orderInputs == null || orderInputs.isEmpty()) {
      log.info("PurchaseOrderServiceImpl.bulkRegistration called with empty Po list");
      return Collections.emptyList();
    }

    return registerPurchaseOrders(orderInputs);
  }

  @Trace
  @Override
  @Counted(REGISTRATION_REQUESTS_RECEIVED_COUNTER)
  // Slight difference in behavior between this method and bulkRegistration(List<OrderInput>) (aka the other). This
  // method is expected to be called directly on user action. And for the other we have the monolith service as proxy,
  // where the monolith does some work prior to calling the method. The difference in behavior is that this method
  // performs extra validation that is not necessary in the other method (as the monolith has already validated input).
  public SoOrderManagementRegisterOrdersPayload bulkRegistration(
      SoOrderManagementRegisterOrdersInput orderInputs, Integer employeeId, Integer userId) {
    if (orderInputs == null || orderInputs.getOrders() == null || orderInputs.getOrders().isEmpty()) {
      log.error("Received invalid OrderInputs: {}", orderInputs);
      throw new IllegalArgumentException("OrderInputs is not valid");
    }

    long requestStartTime = System.currentTimeMillis();
    int purchaseOrdersCount = orderInputs.getOrders().size();
    boolean isSingleRegistration = orderInputs.getIsSingleRegistration();
    purchaseOrderMetrics.recordRegistrationPurchaseOrdersReceived(purchaseOrdersCount);

    try {
      log.info("[START] Starting registration process with input {}", orderInputs);

      var poDataList = mappingService.mapToRegistrationPoDataList(orderInputs);
      var result = registerPurchaseOrders(poDataList, orderInputs.getSupplierId(), employeeId, userId, true);
      if (result.invalid) {
        return SoOrderManagementRegisterOrdersPayload.newBuilder()
            .bulkRegistrationId(null)
            .orderRegistrationResults(result.registrationPos.stream()
                .map(registrationPo ->
                    SoOrderManagementRegisterOrdersOrderRegistrationResult.newBuilder()
                        .fullPurchaseOrderNumber(registrationPo.getFullPONumber())
                        .isSuccessful(registrationPo.getIsValid())
                        .errorMessage(getValidationError(registrationPo.getValidationError()))
                        .build())
                .collect(Collectors.toList()))
            .build();
      }

      var validPOs = result.validPosToReportToCallersAsIncludedInRegistration;
      log.info("[END] Completed registration process with output {}", validPOs);

      BulkRegistration bulkRegistration = bulkRegistrationService.save(orderInputs, userId, employeeId);
      MDC.put(MdcUtil.BULK_REGISTRATION_ID, String.valueOf(bulkRegistration.getId()));
      bulkRegistrationService.sendShippingDocumentsEvents(bulkRegistration, validPOs);

      purchaseOrderMetrics.recordRegistrationSuccess(isSingleRegistration, purchaseOrdersCount, requestStartTime);

      return SoOrderManagementRegisterOrdersPayload.newBuilder()
          .bulkRegistrationId(bulkRegistration.getId())
          .orderRegistrationResults(validPOs.stream()
              .map(registrationPo -> SoOrderManagementRegisterOrdersOrderRegistrationResult.newBuilder()
                  .fullPurchaseOrderNumber(registrationPo.getFullPONumber())
                  .isSuccessful(registrationPo.getIsValid())
                  .errorMessage(getValidationError(registrationPo.getValidationError()))
                  .build())
              .collect(Collectors.toList()))
          .build();
    } catch (Exception ex) {
      purchaseOrderMetrics.recordRegistrationFailure(isSingleRegistration, purchaseOrdersCount, requestStartTime);
      throw ex;
    }
  }

  private List<RegistrationPo> registerPurchaseOrders(List<OrderInput> orderInputs) {
    log.info("[START] Starting registration process with input {}", orderInputs);
    purchaseOrderMetrics.recordRegistrationTotalOrders(orderInputs.size());

    var poDataList = mappingService.mapToRegistrationPoDataList(orderInputs);
    var supplierId = orderInputs.get(0).getSupplierId();
    var employeeId = orderInputs.get(0).getEmployeeId();
    var extranetUserId = orderInputs.get(0).getExtranetUserId();

    var result = registerPurchaseOrders(poDataList, supplierId, employeeId, extranetUserId, false);
    var registrationPos = result.registrationPos;

    log.info("[END] Completed registration process with output {}", registrationPos);
    return registrationPos.stream()
        .filter(it -> {
          var isNotAnRp = it.getRpID() == null;
          return isNotAnRp || it.getIsPrimaryReplacementPart();
        })
        .collect(Collectors.toList());
  }

  @VisibleForTesting
  RegisterPurchaseOrdersResult registerPurchaseOrders(List<PoData> posToRegister, Integer supplierId,
      Integer employeeId, Integer userId, boolean validate) {
    var registrationPos =
        registrationRequestServiceProxy.createRegistrationRequest(supplierId, posToRegister, userId, employeeId);

    // Includes valid POs, plus any secondary RPs we found that were part of consolidated units of RPs being registered.
    var posToRecordAsIncludedInRegistration = registrationPos.stream()
        .filter(it -> {
          var isNotValid = !it.getIsValid();
          if (isNotValid) {
            // Secondary RPs are not necessary to be individually valid. The primary RP of the unit they are in holds
            // all relevant registration data, and the primary RP is representing the unit to suppliers. When the
            // primary RP is valid, the whole consolidated RP unit is considered valid. We keep a record of the
            // secondary RPs for technical reasons, namely to understand which secondary RPs were found during
            // registration.
            var isAnRp = it.isReplacementPart();
            var isSecondaryRpInConsolidatedUnit = !it.isPrimaryReplacementPart();
            return isAnRp && isSecondaryRpInConsolidatedUnit;
          }
          return true;
        })
        .collect(Collectors.toList());

    // Filtered to remove secondary RPs. We do not report to callers any information on the secondary RPs, the primary
    // RPs represent the consolidated RP unit.
    var validPosToReportToCallersAsIncludedInRegistration = posToRecordAsIncludedInRegistration.stream()
        .filter(it -> {
          var notAnRp = !it.isReplacementPart();
          return notAnRp || it.isPrimaryReplacementPart();
        })
        .collect(Collectors.toList());

    if (validate && validPosToReportToCallersAsIncludedInRegistration.size() != posToRegister.size()) {
      List<RegistrationPo> invalidPOs = registrationPos.stream()
          .filter(po -> !po.getIsValid())
          .collect(Collectors.toList());

      log.warn("There are invalid POs in the request. InvalidPOs: [{}].", invalidPOs);
      purchaseOrderMetrics.recordRegistrationPurchaseOrdersInvalid(invalidPOs.size());

      return new RegisterPurchaseOrdersResult(registrationPos, List.of(), true);
    }

    // Update tblOrderProduct with latest SuID and TsID
    posToRecordAsIncludedInRegistration
        .forEach(po -> {
          if (!po.isReplacementPart()) {
            orderProductService.updateOrderProductSupplierAndCarrier(
                po.getPoNum(), po.getSuID(), po.getTsID());
          }
        });

    mappingService.adjustWeightOnReplacementItems(posToRecordAsIncludedInRegistration);

    Pair<List<PurchaseOrderItem>, List<PurchaseOrderItem>> purchaseOrderItems =
        mappingService.mapToPurchaseOrderItems(posToRecordAsIncludedInRegistration, employeeId, userId);

    persistenceService.saveAll(
        mappingService.mapToPurchaseOrders(posToRecordAsIncludedInRegistration, employeeId, userId),
        purchaseOrderItems.getFirst(),
        purchaseOrderItems.getSecond()
    );
    return new RegisterPurchaseOrdersResult(registrationPos, validPosToReportToCallersAsIncludedInRegistration);
  }

  private String getValidationError(TranslationHelper error) {
    if (error != null) {
      return error.getMessageId();
    }

    return null;
  }

  @Trace
  @Override
  @Retry(name = "refreshPurchaseOrder", fallbackMethod = "refreshPurchaseOrderFallback")
  @Timed(REFRESH_REQUESTS_PROCESSED_TIMER)
  @Counted(REFRESH_REQUESTS_RECEIVED_COUNTER)
  public boolean refreshPurchaseOrder(PurchaseOrderNumber purchaseOrderNumber) {
    log.info("Refreshing PO {}", purchaseOrderNumber.getFullPoNumber());

    deletePurchaseOrderData(purchaseOrderNumber);

    LabelDataRefreshRequest request = new LabelDataRefreshRequest(
        purchaseOrderNumber.getFullPoNumber());
    labelDataClient.refresh(request);

    deleteSlmOverpackPuRestClient.deleteShippingLoadManifestOverpack(
        DeleteSlmOverpackRequest.builder()
            .purchaseOrderNumber(purchaseOrderNumber.getPurchaseOrderNumber())
            .replacementPartId(purchaseOrderNumber.getReplacementPartId())
            .isReplacement(purchaseOrderNumber.isReplacement())
            .build());

    if (!purchaseOrderNumber.isReplacement()) {
      orderProductService.updateOrderProductRegisterStatus(
          purchaseOrderNumber.getPurchaseOrderNumber());
    } else {
      replacementPartsClient.deregisterReplacementPart(purchaseOrderNumber.getReplacementPartId());
    }

    orderCrudEventProducer.sendRefreshEvent(purchaseOrderNumber);

    log.info("Finished refreshing PO {}", purchaseOrderNumber.getFullPoNumber());
    purchaseOrderMetrics.recordRefreshSuccess();
    return true;
  }

  @Trace
  @Override
  public List<RefreshPurchaseOrderResultMapping> refreshPurchaseOrders(List<PurchaseOrderNumber> purchaseOrderNumbers) {
    var futures = purchaseOrderNumbers.stream()
        .map(purchaseOrderNumber -> CompletableFuture.supplyAsync(
            () -> new RefreshPurchaseOrderResultMapping(purchaseOrderNumber.getFullPoNumber(),
                refreshPurchaseOrder(purchaseOrderNumber)
            )))
        .collect(Collectors.toList());

    return futures.stream().map(CompletableFuture::join).collect(Collectors.toList());
  }

  private void deletePurchaseOrderData(PurchaseOrderNumber purchaseOrderNumber) {
    PurchaseOrderId purchaseOrderId = PurchaseOrderId.builder()
        .purchaseOrderNumber(purchaseOrderNumber.getPurchaseOrderNumber())
        .isReplacement(purchaseOrderNumber.isReplacement())
        .replacementPartId(
            Optional.ofNullable(purchaseOrderNumber.getReplacementPartId()).orElse(0))
        .build();

    if (!purchaseOrderRepository.existsById(purchaseOrderId)) {
      // No need for any logic because this makes the call idempotent in case there is nothing to delete.
      log.info("Nothing to delete for purchase order number {}", purchaseOrderNumber.getFullPoNumber());
      return;
    }

    purchaseOrderRepository.deleteById(purchaseOrderId);
    purchaseOrderItemRepository.deleteByPurchaseOrderNumber(
        purchaseOrderNumber.getPurchaseOrderNumber());
  }

  /**
   * A fallback method used by {@link #refreshPurchaseOrder(PurchaseOrderNumber)}.
   */
  @SuppressWarnings("unused")
  private boolean refreshPurchaseOrderFallback(PurchaseOrderNumber purchaseOrderNumber, Throwable e) {
    log.error("Purchase order refresh failed for purchase order number {}", purchaseOrderNumber.getFullPoNumber(), e);
    purchaseOrderMetrics.recordRefreshFailure();
    return false;
  }

  @VisibleForTesting
  @AllArgsConstructor
  static class RegisterPurchaseOrdersResult {
    final List<RegistrationPo> registrationPos;
    final List<RegistrationPo> validPosToReportToCallersAsIncludedInRegistration;
    final boolean invalid;

    private RegisterPurchaseOrdersResult(List<RegistrationPo> registrationPos,
        List<RegistrationPo> validPosToReportToCallersAsIncludedInRegistration) {
      this.registrationPos = registrationPos;
      this.validPosToReportToCallersAsIncludedInRegistration = validPosToReportToCallersAsIncludedInRegistration;
      this.invalid = false;
    }
  }
}
