package com.wayfair.registration.api.purchaseorder.documents.dto;

import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class PrintableShippingDocumentsRequest {

  int supplierId;
  int supplierSubEntityId;
  int shipClassId;
  boolean labelPrintEnabledForCarrier;
  int thirdPartyId; // TODO this might be nullable
  FullPurchaseOrderNumber fullPurchaseOrderNumber;

}
