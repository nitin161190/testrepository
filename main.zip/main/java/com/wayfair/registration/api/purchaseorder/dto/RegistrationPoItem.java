package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RegistrationPoItem {

  Integer poNum;
  Integer rpId;
  BigInteger opID;
  Integer opQty;
  Long manufacturerPartID;
  String prManuPartNum;
  String prName;
  BigDecimal prWeight;
  String opPrSKU;
  String refProdID;
  Integer piID1;
  Integer piID2;
  Integer piID3;
  List<RegistrationPoItemCarton> cartons;
  Integer pieceCount;
  String pieceType;
  Integer prMinOrderQty;
  @JsonProperty("measurementUnit")
  MeasurementUnitType measurementUnitType;

  /**
   * Setter required to recalculate weight for replacement items.
   */
  public void setPrWeight(BigDecimal prWeight) {
    this.prWeight = prWeight;
  }
}
