package com.wayfair.registration.api.purchaseorder.dto;

import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.ToString;

@ToString
public class FullPurchaseOrderNumber {

  // CS12345-R-6789
  private static final Pattern FULL_PO_PATTERN = Pattern.compile("([A-Z]+)?(\\d+)(-R-(\\d+))+");
  private static final Pattern PO_PATTERN = Pattern.compile("([A-Z]+)?(\\d+)(-R-(\\d+))?");

  private final String fullPONumber;
  private final Matcher matcher;

  public FullPurchaseOrderNumber(String fullPONumber) {
    this.fullPONumber = fullPONumber;
    this.matcher = PO_PATTERN.matcher(fullPONumber);
    matcher.matches();
  }

  public FullPurchaseOrderNumber(String storePrefix, int poNumber, Integer rpId) {
    this.fullPONumber = storePrefix + poNumber + (rpId != null ? "-R-" + rpId : "");
    this.matcher = PO_PATTERN.matcher(fullPONumber);
    matcher.matches();
  }

  public Integer getPONumber() {
    return Integer.valueOf(matcher.group(2));
  }

  public Optional<Integer> getRPId() {
    Matcher rpIdMatcher = FULL_PO_PATTERN.matcher(fullPONumber);
    if (rpIdMatcher.matches()) {
      return Optional.of(Integer.valueOf(matcher.group(4)));
    }
    return Optional.empty();
  }

  public String getStorePrefix() {
    return matcher.group(1);
  }

  public String getFullPONumber() {
    return fullPONumber;
  }
}
