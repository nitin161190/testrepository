package com.wayfair.registration.api.purchaseorder.validation;

import static lombok.AccessLevel.PRIVATE;
import static org.apache.commons.text.StringEscapeUtils.unescapeJava;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = PRIVATE)
public class TranslationUtil {

  private static final String MSG_ID_PATTERN_CAPTURING_ID = "^msgid\\s+\"(.*)\"\\s*$";
  private static final String MSG_STR_PATTERN_CAPTURING_STRING = "^msgstr\\s+\"(.*)\"\\s*$";

  public static Map<String, String> loadTranslation(File file) throws FileNotFoundException {
    Map<String, String> translation = new HashMap<>();

    Pattern msgIdPattern = Pattern.compile(MSG_ID_PATTERN_CAPTURING_ID);
    Pattern msgStrPattern = Pattern.compile(MSG_STR_PATTERN_CAPTURING_STRING);

    try (Scanner scanner = new Scanner(file)) {
      boolean expectMsgId = true;
      String msgId = null;
      String msgStr;
      while (scanner.hasNextLine()) {
        String line = scanner.nextLine();
        if (expectMsgId) {
          Matcher msgIdMatcher = msgIdPattern.matcher(line);
          if (msgIdMatcher.matches()) {
            msgId = unescapeJava(msgIdMatcher.group(1));
            expectMsgId = false;
          }
        } else {
          Matcher msgStrMatcher = msgStrPattern.matcher(line);
          if (msgStrMatcher.matches()) {
            msgStr = unescapeJava(msgStrMatcher.group(1));
            expectMsgId = true;
            translation.put(msgId, msgStr);
          }
        }
      }
    }

    return translation;
  }
}
