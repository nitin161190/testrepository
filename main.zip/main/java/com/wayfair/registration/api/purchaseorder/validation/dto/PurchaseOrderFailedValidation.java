package com.wayfair.registration.api.purchaseorder.validation.dto;

import java.util.List;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class PurchaseOrderFailedValidation {

  String fullPurchaseOrderNumber;

  List<PurchaseOrderValidationFailureDetails> purchaseOrderValidationFailureDetails;
}
