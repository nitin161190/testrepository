package com.wayfair.registration.api.purchaseorder.dto;

import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
public class TranslationHelper {

  String messageId;
  Map<String, String> params;

  @Override
  public String toString() {
    return messageId;
  }
}
