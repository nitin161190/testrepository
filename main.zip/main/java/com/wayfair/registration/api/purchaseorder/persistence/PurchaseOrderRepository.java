package com.wayfair.registration.api.purchaseorder.persistence;

import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrder;
import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrderId;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PurchaseOrderRepository extends CrudRepository<PurchaseOrder, PurchaseOrderId> {
}
