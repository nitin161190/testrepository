package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.CARRIER_MISSING;
import static com.wayfair.registration.api.domain.Failure.FULL_PO_NUMBER_MISSING;
import static com.wayfair.registration.api.domain.Failure.ORDER_PRODUCTS_EMPTY;
import static com.wayfair.registration.api.domain.Failure.ORDER_PRODUCT_REF_PROD_ID_MISSING;
import static com.wayfair.registration.api.domain.Failure.SUPPLIER_MISSING;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItem;
import com.wayfair.registration.api.purchaseorder.validation.ValidationUtils;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.stereotype.Component;

@Component
public class NullAndEmptyValidator implements RegistrationPoValidator {

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {
    return Stream.of(
            Pair.of(SUPPLIER_MISSING, registrationPo.getSuID() == null || registrationPo.getSuID() <= 0),
            Pair.of(FULL_PO_NUMBER_MISSING, registrationPo.getFullPONumber() == null),
            Pair.of(ORDER_PRODUCTS_EMPTY, registrationPo.getItems() == null
                || registrationPo.getItems().isEmpty()),
            Pair.of(ORDER_PRODUCT_REF_PROD_ID_MISSING, registrationPo.getItems() != null
                && registrationPo.getItems().stream()
                .map(RegistrationPoItem::getRefProdID)
                .anyMatch(StringUtils::isBlank)),
            Pair.of(CARRIER_MISSING, registrationPo.getCrID() == null || registrationPo.getCrID() <= 0)
        )
        .filter(Pair::getRight)
        .map(Pair::getLeft)
        .map(ValidationUtils::singleFailure)
        .flatMap(Collection::stream)
        .collect(Collectors.toList());
  }
}
