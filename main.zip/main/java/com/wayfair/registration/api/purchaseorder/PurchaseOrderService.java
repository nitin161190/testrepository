package com.wayfair.registration.api.purchaseorder;

import com.wayfair.registration.api.dto.PurchaseOrderNumber;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersPayload;
import com.wayfair.registration.api.purchaseorder.dto.OrderInput;
import com.wayfair.registration.api.purchaseorder.dto.RefreshPurchaseOrderResultMapping;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import java.util.List;

public interface PurchaseOrderService {

  List<RegistrationPo> singleRegistration(OrderInput orderInput);

  List<RegistrationPo> bulkRegistration(List<OrderInput> orderInputs);

  SoOrderManagementRegisterOrdersPayload bulkRegistration(
      SoOrderManagementRegisterOrdersInput ordersInput,
      Integer employeeId,
      Integer extranetUserId
  );

  boolean refreshPurchaseOrder(PurchaseOrderNumber purchaseOrderNumber);

  List<RefreshPurchaseOrderResultMapping> refreshPurchaseOrders(List<PurchaseOrderNumber> purchaseOrderNumbers);

}
