package com.wayfair.registration.api.purchaseorder.documents.customs.transportation.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CustomsRelevanceRequest {

  @JsonProperty("po_number")
  String purchaseOrderNumber;

  @JsonProperty("ts_id")
  int thirdPartyId;

}
