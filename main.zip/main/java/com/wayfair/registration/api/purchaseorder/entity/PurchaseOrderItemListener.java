package com.wayfair.registration.api.purchaseorder.entity;

import javax.persistence.PostPersist;
import javax.persistence.PostUpdate;

/**
 * This class has been created strictly for testing purposes. It tracks the number of inserts and updates for the
 * PurchaseOrderItem entity.
 */
public class PurchaseOrderItemListener {

  @PostPersist
  public void onPostPersist(PurchaseOrderItem purchaseOrderItem) {
    purchaseOrderItem.setInsertCount(purchaseOrderItem.getInsertCount() + 1);
  }

  @PostUpdate
  public void afterPersist(PurchaseOrderItem purchaseOrderItem) {
    purchaseOrderItem.setUpdateCount(purchaseOrderItem.getUpdateCount() + 1);
  }

}
