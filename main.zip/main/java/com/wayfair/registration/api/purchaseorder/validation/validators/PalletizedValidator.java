package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.PALLETIZED_INVALID_PALLET_DATA;
import static com.wayfair.registration.api.purchaseorder.validation.ValidationUtils.singleFailure;
import static java.util.Collections.emptyList;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.math.BigDecimal;
import java.util.List;
import org.springframework.stereotype.Component;

@Component
public class PalletizedValidator implements RegistrationPoValidator {

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {
    if (isPalletizedAndPalletDataMissingOrInvalid(registrationPo)
        || isNotPalletizedButPalletDataPresent(registrationPo)) {
      return singleFailure(PALLETIZED_INVALID_PALLET_DATA);
    } else {
      return emptyList();
    }
  }

  private boolean isPalletizedAndPalletDataMissingOrInvalid(RegistrationPo registrationPo) {
    return Boolean.TRUE.equals(registrationPo.getIsPOPalletized())
        && (registrationPo.getPalletCount() == null
        || registrationPo.getPalletCount() <= 0
        || registrationPo.getPalletWeight() == null
        || registrationPo.getPalletWeight().compareTo(BigDecimal.ZERO) <= 0);
  }

  private boolean isNotPalletizedButPalletDataPresent(RegistrationPo registrationPo) {
    return Boolean.FALSE.equals(registrationPo.getIsPOPalletized())
      && registrationPo.getPalletCount() != null
      && registrationPo.getPalletCount() != 0
      && registrationPo.getPalletWeight() != null
      && !registrationPo.getPalletWeight().equals(BigDecimal.ZERO);
  }
}
