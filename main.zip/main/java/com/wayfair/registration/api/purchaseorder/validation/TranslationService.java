package com.wayfair.registration.api.purchaseorder.validation;

import java.io.IOException;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

@Service
public class TranslationService {

  public static final String MESSAGES_PO_FILE_PATTERN_CAPTURING_LOCALE = "messages\\.([^.]+)\\.po";

  private final Map<Locale, Map<String, String>> localeToTranslationsMap = new HashMap<>();
  private final Map<String, String> defaultTranslations = new HashMap<>();

  @Value("classpath*:translations/messages*.po")
  private Resource[] messageFiles;

  @PostConstruct
  private void loadTranslation() throws IOException {
    Pattern translationFilenameWithLocale = Pattern.compile(MESSAGES_PO_FILE_PATTERN_CAPTURING_LOCALE);

    for (Resource messageFile : messageFiles) {
      if (messageFile.isFile() && messageFile.isReadable()) {
        Map<String, String> translations = TranslationUtil.loadTranslation(messageFile.getFile());

        Matcher filenameWithLocaleMatcher = translationFilenameWithLocale.matcher(messageFile.getFilename());
        if (filenameWithLocaleMatcher.matches()) {
          localeToTranslationsMap.put(Locale.forLanguageTag(filenameWithLocaleMatcher.group(1)), translations);
        } else {
          defaultTranslations.putAll(translations);
        }
      }
    }
  }

  public String getTranslatedMessage(String translationKey, Locale locale) {
    Map<String, String> translations = Optional
        .ofNullable(localeToTranslationsMap.get(locale))
        .orElse(defaultTranslations);

    return translations.get(translationKey);
  }
}
