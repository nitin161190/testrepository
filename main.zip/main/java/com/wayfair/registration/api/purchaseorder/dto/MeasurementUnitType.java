package com.wayfair.registration.api.purchaseorder.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum MeasurementUnitType {

  IMPERIAL,
  METRIC;

  public static MeasurementUnitType fromMeasurementId(int measurementId) {
    if (measurementId == 1) {
      return IMPERIAL;
    }

    // Default to metric unit for any other case
    return METRIC;
  }

}
