package com.wayfair.registration.api.purchaseorder.persistence;

import java.util.List;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class CastleGateOrdersRepository {

  private static final int ORDER_IS_CASTLE_GATE = 1;

  private final EntityManager entityManager;

  public CastleGateOrdersRepository(@Qualifier("c149EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public boolean isCastleGateOrder(int purchaseOrderNumber) {
    List<Integer> result = entityManager.createNativeQuery(""
            + "SELECT po.PoNum "
            + "FROM csn_order.dbo.tblPurchaseOrder po WITH (NOLOCK) "
            + "WHERE po.PoIsWFS = " + ORDER_IS_CASTLE_GATE + " "
            + "AND po.PoNum = ?1")
        .setParameter(1, purchaseOrderNumber)
        .getResultList();

    return !result.isEmpty();
  }

}
