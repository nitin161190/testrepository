package com.wayfair.registration.api.purchaseorder;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.wayfair.registration.api.domain.Failure;
import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.OM1905RegistrationResponse;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderFailedValidation;
import com.wayfair.registration.api.purchaseorder.validation.dto.PurchaseOrderValidationFailureDetails;
import com.wayfair.registration.api.util.RequestContext;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class PurchaseOrderControllerAdvice {

  private final ObjectMapper objectMapper;

  @ResponseStatus(BAD_REQUEST)
  @ResponseBody
  @ExceptionHandler(HttpMessageNotReadableException.class)
  public OM1905RegistrationResponse invalidInputHandler(HttpMessageNotReadableException ex) {
    if (ex.getCause() instanceof InvalidFormatException
        && ShippingDocumentType.class.isAssignableFrom(((InvalidFormatException) ex.getCause()).getTargetType())) {
      return OM1905RegistrationResponse.builder()
          .successfulPoNumbers(List.of())
          .poFailedValidations(List.of(
              PurchaseOrderFailedValidation.builder()
                  .purchaseOrderValidationFailureDetails(
                      List.of(PurchaseOrderValidationFailureDetails.builder()
                          .failureMessage("Value provided for {shippingDocumentTypes} is not supported.")
                          .failureCode(Failure.SHIP_CLASS_MISSING.getFailureCode())
                          .failureTranslationKey(Failure.SHIP_CLASS_MISSING.getFailureTranslationKey())
                          .build())
                  ).build()
          ))
          .build();
    }
    return OM1905RegistrationResponse.builder()
        .poFailedValidations(List.of())
        .build();
  }

  @ResponseStatus(INTERNAL_SERVER_ERROR)
  @SneakyThrows
  @ExceptionHandler
  public void runtimeExceptionHandler(RuntimeException e) {
    log.error(objectMapper.writeValueAsString(RequestContext.get()), e);
    RequestContext.clear();
  }
}
