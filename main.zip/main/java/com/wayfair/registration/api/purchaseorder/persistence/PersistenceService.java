package com.wayfair.registration.api.purchaseorder.persistence;

import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrder;
import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrderItem;
import datadog.trace.api.Trace;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PersistenceService {

  private final PurchaseOrderRepository purchaseOrderRepository;
  private final PurchaseOrderItemRepository purchaseOrderItemRepository;

  @Trace
  @Transactional
  public void saveAll(List<PurchaseOrder> purchaseOrders,
                      List<PurchaseOrderItem> purchaseOrderItemsToCreate,
                      List<PurchaseOrderItem> purchaseOrderItemsToUpdate
  ) {
    log.info("Saving: {} purchase orders, {} create items, {} update items", purchaseOrders.size(),
        purchaseOrderItemsToCreate.size(), purchaseOrderItemsToUpdate.size());

    createPurchaseOrderItems(purchaseOrderItemsToCreate);
    updatePurchaseOrderItems(purchaseOrderItemsToUpdate);
    createAllPurchaseOrders(purchaseOrders);
  }

  private void createAllPurchaseOrders(List<PurchaseOrder> purchaseOrders) {
    purchaseOrderRepository.saveAll(purchaseOrders);
  }

  private void createPurchaseOrderItems(List<PurchaseOrderItem> purchaseOrderItemsToCreate) {
    purchaseOrderItemRepository.saveAll(purchaseOrderItemsToCreate);
  }

  private void updatePurchaseOrderItems(List<PurchaseOrderItem> purchaseOrderItemsToUpdate) {
    for (PurchaseOrderItem purchaseOrderItem : purchaseOrderItemsToUpdate) {
      purchaseOrderItemRepository.updatePurchaseOrderItem(
          purchaseOrderItem.getPurchaseOrderNumber(),
          purchaseOrderItem.getOrderProductId(),
          purchaseOrderItem.getReplacementPartId(),
          purchaseOrderItem.getQuantity(),
          purchaseOrderItem.getPartNumber(),
          purchaseOrderItem.getItemName(),
          purchaseOrderItem.getPartWeight(),
          purchaseOrderItem.getPartBoxes(),
          purchaseOrderItem.getEstimatedShipDate(),
          purchaseOrderItem.getEstimatedShipDatetz(),
          purchaseOrderItem.isReplacement(),
          purchaseOrderItem.getShipClassId(),
          purchaseOrderItem.getBoxClass(),
          purchaseOrderItem.getNmfc(),
          purchaseOrderItem.getLastReviewedExtranetUserId(),
          purchaseOrderItem.getLastReviewedEmployeeId(),
          purchaseOrderItem.getPieceType()
      );
    }
  }
}
