package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.FULL_PO_NUMBER_MALFORMED;
import static com.wayfair.registration.api.purchaseorder.validation.ValidationUtils.singleFailure;
import static java.util.Collections.emptyList;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.List;
import java.util.regex.Pattern;
import org.springframework.stereotype.Component;

@Component
public class PurchaseOrderNumberValidator implements RegistrationPoValidator {

  private final Pattern purchaseOrderPattern = Pattern.compile("[a-zA-Z]{2}\\d{1,9}");
  private final Pattern replacementPartsPattern = Pattern.compile("[a-zA-Z]{2}\\d{1,9}-R-.+");

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {
    return registrationPo.getFullPONumber() != null
        && !(purchaseOrderPattern.matcher(registrationPo.getFullPONumber()).matches()
        || replacementPartsPattern.matcher(registrationPo.getFullPONumber()).matches())
        ? singleFailure(FULL_PO_NUMBER_MALFORMED, "poNum", registrationPo.getFullPONumber())
        : emptyList();
  }
}
