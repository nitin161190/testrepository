package com.wayfair.registration.api.purchaseorder.documents;

import com.wayfair.registration.api.domain.ShipClass;
import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.domain.SubEntityRegion;
import com.wayfair.registration.api.purchaseorder.documents.customs.CustomsDocumentService;
import com.wayfair.registration.api.purchaseorder.documents.dto.PrintableShippingDocumentsRequest;
import com.wayfair.registration.api.purchaseorder.documents.ucc.UccLabelService;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import java.util.EnumSet;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class PrintableShippingDocumentsService {

  // Special condition (Exception) for 'NonstopDelivery, Inc.' (TsID = 82)
  private static final Set<Integer> THIRD_PARTY_BOL_EXCEPTIONS = Set.of(
      82
  );

  private static final EnumSet<ShippingDocumentType> DEFAULT_PRINTABLE_SHIPPING_DOCUMENTS = EnumSet.of(
      ShippingDocumentType.PACKING_SLIP,
      ShippingDocumentType.SAMPLE_ORDER_LABEL
  );

  private final UccLabelService uccLabelService;
  private final CustomsDocumentService customsDocumentService;

  public Set<ShippingDocumentType> determinePrintableShippingDocuments(PrintableShippingDocumentsRequest request) {
    if (isUsSupplierSubEntity(request.getSupplierSubEntityId())) {
      log.info("Determining printable shipping documents for US order with request {}", request);

      return determinePrintableShippingDocumentsForUS(
          request.getSupplierId(),
          request.getShipClassId(),
          request.isLabelPrintEnabledForCarrier(),
          request.getThirdPartyId()
      );
    } else {
      log.info("Determining printable shipping documents for EU order with request {}", request);

      return determinePrintableShippingDocumentsForEU(
          request.isLabelPrintEnabledForCarrier(),
          request.getFullPurchaseOrderNumber(),
          request.getThirdPartyId()
      );
    }
  }

  private Set<ShippingDocumentType> determinePrintableShippingDocumentsForEU(
      boolean labelPrintEnabledForCarrier,
      FullPurchaseOrderNumber fullPurchaseOrderNumber,
      int thirdPartyId) {

    Set<ShippingDocumentType> printableShippingDocuments = EnumSet.copyOf(DEFAULT_PRINTABLE_SHIPPING_DOCUMENTS);

    if (labelPrintEnabledForCarrier) {
      printableShippingDocuments.add(ShippingDocumentType.SHIPPING_LABEL);
      printableShippingDocuments.add(ShippingDocumentType.MANIFEST);

      if (customsDocumentService.isCustomsDocumentRequired(fullPurchaseOrderNumber, thirdPartyId)) {
        printableShippingDocuments.add(ShippingDocumentType.CUSTOMS);
      }
    }

    return printableShippingDocuments;
  }

  private Set<ShippingDocumentType> determinePrintableShippingDocumentsForUS(
      int supplierId,
      int shipClassId,
      boolean labelPrintEnabledForCarrier,
      int thirdPartyId) {

    boolean isLargeParcel = isLargeParcelByShipClass(shipClassId);

    Set<ShippingDocumentType> printableShippingDocuments = EnumSet.copyOf(DEFAULT_PRINTABLE_SHIPPING_DOCUMENTS);

    if (!isLargeParcel && labelPrintEnabledForCarrier) {
      printableShippingDocuments.add(ShippingDocumentType.SHIPPING_LABEL);
    }

    if (isLargeParcel && uccLabelService.isUccLabelEnabledForSupplier(supplierId)) {
      printableShippingDocuments.add(ShippingDocumentType.UCC);
    }

    if (isLargeParcel && !THIRD_PARTY_BOL_EXCEPTIONS.contains(thirdPartyId)) {
      printableShippingDocuments.add(ShippingDocumentType.BOL);
    }

    if (printableShippingDocuments.contains(ShippingDocumentType.SHIPPING_LABEL)
        || printableShippingDocuments.contains(ShippingDocumentType.UCC)) {
      printableShippingDocuments.add(ShippingDocumentType.MANIFEST);
    }

    return printableShippingDocuments;
  }

  private boolean isLargeParcelByShipClass(int shipClassId) {
    ShipClass shipClass = ShipClass.valueOf(shipClassId);
    return ShipClass.LARGE_PARCEL_SHIP_CLASSES.contains(shipClass);
  }

  private boolean isUsSupplierSubEntity(int supplierSubEntityId) {
    SubEntityRegion subEntityRegion = SubEntityRegion.fromSupplierSubEntity(supplierSubEntityId);
    return SubEntityRegion.isNorthAmericanSubEntity(subEntityRegion);
  }

}
