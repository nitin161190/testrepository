package com.wayfair.registration.api.purchaseorder.dto;

import java.math.BigDecimal;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.lang.Nullable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderProduct {

  String partNumber;

  Integer pieceCount;

  BigDecimal unitWeight;

  String nmfc;

  String freightClass;

  String pieceType;

  @Nullable
  Long orderProductId;
}
