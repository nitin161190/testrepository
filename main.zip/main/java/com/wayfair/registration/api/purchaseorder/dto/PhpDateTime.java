package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PhpDateTime {

  static final int TZ_TYPE_OFFSET = 1;
  static final int TZ_TYPE_SHORT = 2;
  static final int TZ_TYPE_FULL = 3;

  private static final DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
  private static final DateTimeFormatter dateTimeFormatter = new DateTimeFormatterBuilder()
      .appendPattern("yyyy-MM-dd HH:mm:ss")
      .appendFraction(ChronoField.MILLI_OF_SECOND, 0, 6, true)
      .toFormatter();

  @JsonProperty("date")
  String date;

  @JsonProperty("timezone_type")
  int timezoneType = TZ_TYPE_FULL;

  @JsonProperty("timezone")
  String timezone = "America/New_York";

  public PhpDateTime(String date) {
    this.date = date;
  }

  @JsonIgnore
  public LocalDate getLocalDate() {
    try {
      return LocalDate.parse(date, dateFormatter);
    } catch (DateTimeParseException ex) {
      // Falling back to parse datetime
      LocalDateTime dateTime = LocalDateTime.parse(date, dateTimeFormatter);
      return dateTime.toLocalDate();
    } catch (Exception ex) {
      log.error("Parsing date failed for date [{}], formatter [{}]", date, dateFormatter, ex);
      throw ex;
    }
  }

  public LocalTime getLocalTime() {
    try {
      LocalDateTime dateTime = LocalDateTime.parse(date, dateTimeFormatter);
      return dateTime.toLocalTime();
    } catch (DateTimeParseException ex) {
      // Defaulting to NOON just to avoid exceptions.
      // We are not dealing with "time".
      // All of our operation is only "Date" based.
      return LocalTime.NOON;
    }
  }

  @JsonIgnore
  public ZonedDateTime getZonedDateTime() {
    if (timezoneType != TZ_TYPE_OFFSET && timezoneType != TZ_TYPE_SHORT
        && timezoneType != TZ_TYPE_FULL) {
      throw new IllegalStateException();
    }

    return ZonedDateTime.of(getLocalDate(), getLocalTime(), getZoneId());
  }

  @JsonIgnore
  public LocalDate today() {
    return OffsetDateTime.now(getZoneId()).toLocalDate();
  }

  private ZoneId getZoneId() {
    if (timezoneType == TZ_TYPE_FULL) {
      return ZoneId.of(timezone);
    } else if (timezoneType == TZ_TYPE_OFFSET) {
      return ZoneId.ofOffset("", ZoneOffset.of(timezone));
    } else {
      return ZoneId.of(timezone, ZoneId.SHORT_IDS);
    }
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof PhpDateTime)) {
      return false;
    }

    // We only care about the date for comparison purpose
    return ((PhpDateTime) obj).getLocalDate().equals(this.getLocalDate());
  }

  /**
   * To check whether the created date is in past in the same timezone.
   *
   * @return boolean
   */
  @JsonIgnore
  public boolean isInPast() {
    boolean isDateInPast = this.getLocalDate().isBefore(this.today());
    if (isDateInPast) {
      log.info("[PhpDateTime] Date in past. PO Date {}, Today {}",
          this.getLocalDate(), this.today());
    }

    return isDateInPast;
  }
}
