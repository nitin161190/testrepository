package com.wayfair.registration.api.purchaseorder.entity;

import com.wayfair.registration.api.config.OffsetDateTimeConverter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Getter
@Setter
@Table(name = "tblExtranetOutItem", catalog = "csn_extranet_fulfillment")
@DynamicUpdate
@EntityListeners(PurchaseOrderItemListener.class)
public class PurchaseOrderItem {

  @Id
  @NotNull
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ExiID")
  private int id;

  @NotNull
  @Column(name = "ExiPONum")
  private int purchaseOrderNumber;

  @NotNull
  @Column(name = "ExiOpID")
  private BigInteger orderProductId = BigInteger.valueOf(1001);

  @NotNull
  @Column(name = "ExiQty")
  private int quantity;

  @Column(name = "ExiPartNum")
  private String partNumber;

  @Column(name = "ExiName")
  private String itemName;

  @Column(name = "ExiPartWeight")
  private BigDecimal partWeight;

  @Column(name = "ExiPrSKU")
  private String productSKU;

  @Column(name = "ExiPartBoxes")
  private Integer partBoxes;

  @Column(name = "EstShipDate")
  private LocalDate estimatedShipDate;

  @Column(name = "EstShipDateTZ")
  @Convert(converter = OffsetDateTimeConverter.class)
  private OffsetDateTime estimatedShipDatetz;

  @Column(name = "ExiIsReplacement")
  private boolean isReplacement;

  @Column(name = "ExiRpID")
  private Integer replacementPartId;

  @Column(name = "ExiSpID")
  private Integer shipClassId;

  @Column(name = "ExiClass")
  private String boxClass;

  @Column(name = "ExiNMFC")
  private String nmfc;

  @Column(name = "ExiPieceType")
  private String pieceType;

  @Column(name = "ExiPiID1")
  private Integer productItemId1;

  @Column(name = "ExiPiID2")
  private Integer productItemId2;

  @Column(name = "ExiPiID3")
  private Integer productItemId3;

  @Column(name = "ExiLastRevExuID")
  private Integer lastReviewedExtranetUserId;

  @Column(name = "ExiLastRevEmID")
  private Integer lastReviewedEmployeeId;

  @Transient
  private int insertCount;

  @Transient
  private int updateCount;
}
