package com.wayfair.registration.api.purchaseorder.documents.customs.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CustomsInformationResponse {

  boolean requiresCustomDocuments;
  boolean consolidationDisabled;
  boolean multiboxDisabled;
  boolean crossBorder;

}
