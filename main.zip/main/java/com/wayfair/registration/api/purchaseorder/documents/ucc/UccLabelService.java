package com.wayfair.registration.api.purchaseorder.documents.ucc;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class UccLabelService {

  // TODO better name for this
  private static final int BLESSED_LARGE_PARCEL_TYPE = 2;

  private final UccLabelRepository uccLabelRepository;

  public boolean isUccLabelEnabledForSupplier(int supplierId) {
    Optional<UccLabelSettings> uccLabelSettings = uccLabelRepository.getUccLabelSettings(supplierId);

    uccLabelSettings.ifPresent(
        settings -> log.info("UCC label settings for supplier {} is {}", supplierId, uccLabelSettings)
    );

    if (uccLabelSettings.isPresent()
        && !uccLabelSettings.get().isShowUcc()
        && uccLabelSettings.get().getLargeParcelType() == BLESSED_LARGE_PARCEL_TYPE) {
      return false;
    } else {
      return true;
    }
  }

}
