package com.wayfair.registration.api.purchaseorder.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Builder
@Getter
@AllArgsConstructor
@EqualsAndHashCode
@ToString
public class RefreshPurchaseOrderResultMapping {

  String purchaseOrderNumber;

  boolean refreshPurchaseOrderResult;
}
