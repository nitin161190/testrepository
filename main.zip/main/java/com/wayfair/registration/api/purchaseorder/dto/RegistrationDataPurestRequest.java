package com.wayfair.registration.api.purchaseorder.dto;

import java.util.List;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RegistrationDataPurestRequest {

  List<PoData> poList;
  Integer supplierId;
  Integer extranetUserId;
  Integer employeeId;
}
