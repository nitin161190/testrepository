package com.wayfair.registration.api.purchaseorder.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class RegistrationPo {
  private String poStorePrefix;
  Integer poNum;
  Integer rpID;
  BigInteger orID;
  Integer soID;
  Integer mkcID;
  Integer recipientCountryID;
  String recipientPostalCode;
  /**
   * For some reason, we are reading the supplier ID after it gets updated in DB.
   * Since, these details are not important for request creation, ignoring them from diff.
   */
  String suAddress1;
  String suAddress2;
  String suAddress3;
  String suCityName;
  String suStName;
  String suPostalCode;
  String suCountry;
  Integer suCountryID;
  Integer suID;
  String suName;
  String suContactNamePrimary;
  String suPhoneNumberPrimary;
  String suFaxNumberPrimary;
  String suPhoneExtensionPrimary;
  Integer labelCountType;
  String crName;
  Integer crID;
  Integer spID;
  PhpDateTime poDate;
  PhpDateTime estShipDate;
  Integer tsID;
  String scac;
  Integer shipClass;
  Boolean isRegistered = Boolean.FALSE;
  String shippingLabel;
  String packingSlip;
  Integer transShipAgentID;
  Boolean isWayFairBigParcelFulfillment;
  Integer internationalTransshipLinehaulID;
  List<RegistrationPoItem> items = new ArrayList<>();
  Boolean isValid = Boolean.FALSE;
  TranslationHelper validationError;

  Boolean isPOMultiLegShipment = Boolean.FALSE;
  Boolean isFirstLegHubInjectionShipment = Boolean.FALSE;
  Boolean isCarrierChanged = Boolean.FALSE;
  Boolean isSendASNRequired = Boolean.FALSE;
  Integer firstLegShipmentAgentId;
  Boolean isOPLCreationRequired = Boolean.FALSE;
  Boolean isPrintBOLActivate = Boolean.FALSE;
  Integer firstLegSLMId;
  PhpDateTime requestForPickupDate;
  Boolean isPOPalletized = Boolean.FALSE;
  BigDecimal palletWeight = BigDecimal.ZERO;
  Integer palletCount = 0;
  Integer lastLegSLMId;
  Boolean isShippingLabelPrintAllowed = Boolean.FALSE;
  Boolean isLabelPrintEnabledForCarrier = Boolean.FALSE;
  Boolean isLTLLabelPrintEnabled = Boolean.FALSE;
  Boolean isWGLabelPrintEnabled = Boolean.FALSE;
  Boolean isSPLabelPrintEnabled = Boolean.FALSE;
  Boolean isRPLabelPrintEnabled = Boolean.FALSE;
  Boolean isSupplierShippingPartsOnOwnAccount;
  Integer supplierSubEntityID;
  Integer orderProductType;
  Integer shipVia;
  Integer poStatusCode;
  Integer rpStatusCode;

  Boolean isRegistrationUpdateRequired = Boolean.FALSE;
  Boolean isRFPDateChanged = Boolean.FALSE;
  Integer actualShipClass;

  // Specific property for RP consolidation to determine if an RP is primary
  Boolean isPrimaryReplacementPart;

  public String getFullPONumber() {
    return (new FullPurchaseOrderNumber(poStorePrefix, poNum, rpID)).getFullPONumber();
  }

  @JsonIgnore
  public boolean isReplacementPart() {
    return rpID != null;
  }

  @JsonIgnore
  public boolean isPrimaryReplacementPart() {
    // Prior to RP Consolidation, all RPs were "primary RPs". If we do not have information on whether an
    // RP is part of a consolidated unit or not, it is safer to assume that it is not and is a primary RP.
    return isPrimaryReplacementPart == null || Boolean.TRUE.equals(isPrimaryReplacementPart);
  }

  @JsonIgnore
  public boolean isRegistered() {
    return Boolean.TRUE.equals(isRegistered);
  }
}
