package com.wayfair.registration.api.purchaseorder.validation.dto;

import com.wayfair.registration.api.purchaseorder.dto.TranslationHelper;
import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class PurchaseOrderValidationFailureDetails {

  Integer failureCode;

  String failureMessage;

  String failureTranslationKey;

  TranslationHelper translationHelper;

}
