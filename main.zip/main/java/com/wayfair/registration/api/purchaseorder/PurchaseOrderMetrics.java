package com.wayfair.registration.api.purchaseorder;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import java.util.List;
import java.util.concurrent.TimeUnit;
import lombok.val;
import org.springframework.stereotype.Component;

@Component
public class PurchaseOrderMetrics {

  public static final String REGISTRATION_REQUESTS_RECEIVED_COUNTER = "purchase.order.registration.requests.received";
  private static final String REGISTRATION_REQUESTS_PROCESSED_COUNTER = 
      "purchase.order.registration.requests.processed";
  private static final String REGISTRATION_REQUESTS_PROCESSED_TIMER =
      "purchase.order.registration.requests.processed.duration";
  private static final String REGISTRATION_PURCHASE_ORDERS_RECEIVED_COUNTER =
      "purchase.order.registration.purchase.orders.received";
  private static final String REGISTRATION_PURCHASE_ORDERS_PROCESSED_COUNTER =
      "purchase.order.registration.purchase.orders.processed";
  private static final String PURCHASE_ORDER_REGISTRATION_PURCHASE_ORDERS_INVALID_COUNTER =
      "purchase.order.registration.purchase.orders.invalid";
  public static final String REFRESH_REQUESTS_RECEIVED_COUNTER = "purchase.order.refresh.requests.received";
  public static final String REFRESH_REQUESTS_PROCESSED_TIMER = "purchase.order.refresh.requests.processed.duration";
  private static final String REFRESH_REQUESTS_PROCESSED_COUNTER = "purchase.order.refresh.requests.processed";

  // TODO: metric and related code to be removed after phase 4 completes.
  public static final String REGISTRATION_SINGLE_REQUESTS_RECEIVED_COUNTER =
      "purchase.order.registration.single.requests.received";
  // TODO: metric and related code to be removed after phase 4 completes.
  public static final String REGISTRATION_BULK_REQUESTS_RECEIVED_COUNTER =
      "purchase.order.registration.bulk.requests.received";
  // TODO: metric and related code to be removed after phase 4 completes.
  private static final String REGISTRATION_TOTAL_ORDERS_COUNTER =
      "purchase.order.registration.total.orders";

  private static final String REGISTRATION_TYPE_TAG_NAME = "registration_type";
  private static final String SINGLE_REGISTRATION_TAG_VALUE = "single_registration";
  private static final String BULK_REGISTRATION_TAG_VALUE = "bulk_registration";
  private static final String SUCCESSFUL_TAG_NAME = "successful";

  private final MeterRegistry meterRegistry;
  private final Counter registrationPurchaseOrdersReceived;
  private final Counter registrationPurchaseOrdersInvalid;
  private final Counter refreshSuccess;
  private final Counter refreshFailure;
  private final Counter purchaseOrderRegistrationTotalOrdersCounter;

  public PurchaseOrderMetrics(MeterRegistry meterRegistry) {
    this.meterRegistry = meterRegistry;
    this.registrationPurchaseOrdersReceived = meterRegistry.counter(REGISTRATION_PURCHASE_ORDERS_RECEIVED_COUNTER);
    this.refreshSuccess =
        meterRegistry.counter(REFRESH_REQUESTS_PROCESSED_COUNTER, SUCCESSFUL_TAG_NAME, "true");
    this.refreshFailure =
        meterRegistry.counter(REFRESH_REQUESTS_PROCESSED_COUNTER, SUCCESSFUL_TAG_NAME, "false");
    this.purchaseOrderRegistrationTotalOrdersCounter = meterRegistry.counter(REGISTRATION_TOTAL_ORDERS_COUNTER);
    this.registrationPurchaseOrdersInvalid = meterRegistry.counter(
        PURCHASE_ORDER_REGISTRATION_PURCHASE_ORDERS_INVALID_COUNTER);
  }

  public void recordRegistrationPurchaseOrdersReceived(int count) {
    registrationPurchaseOrdersReceived.increment(count);
  }

  public void recordRegistrationSuccess(boolean isSingleRegistration, int purchaseOrdersCount,
      long requestStartTime) {
    recordRegistrationComplete(true, isSingleRegistration, purchaseOrdersCount, requestStartTime);
  }

  public void recordRegistrationFailure(boolean isSingleRegistration, int purchaseOrdersCount,
      long requestStartTime) {
    recordRegistrationComplete(false, isSingleRegistration, purchaseOrdersCount, requestStartTime);
  }

  private void recordRegistrationComplete(boolean isSuccessful, boolean isSingleRegistration, int purchaseOrdersCount,
      long requestStartTime) {
    String registrationType = isSingleRegistration ? SINGLE_REGISTRATION_TAG_VALUE : BULK_REGISTRATION_TAG_VALUE;
    long requestEndTime = System.currentTimeMillis();

    val tags = List.of(
        Tag.of(SUCCESSFUL_TAG_NAME, String.valueOf(isSuccessful)),
        Tag.of(REGISTRATION_TYPE_TAG_NAME, registrationType)
    );

    meterRegistry.counter(REGISTRATION_PURCHASE_ORDERS_PROCESSED_COUNTER, tags).increment(purchaseOrdersCount);
    meterRegistry.counter(REGISTRATION_REQUESTS_PROCESSED_COUNTER, tags).increment();
    meterRegistry.timer(REGISTRATION_REQUESTS_PROCESSED_TIMER, tags)
        .record(requestEndTime - requestStartTime, TimeUnit.MILLISECONDS);
  }

  public void recordRefreshSuccess() {
    refreshSuccess.increment();
  }

  public void recordRefreshFailure() {
    refreshFailure.increment();
  }

  public void recordRegistrationTotalOrders(int count) {
    purchaseOrderRegistrationTotalOrdersCounter.increment(count);
  }

  public void recordRegistrationPurchaseOrdersInvalid(int count) {
    registrationPurchaseOrdersInvalid.increment(count);
  }
}
