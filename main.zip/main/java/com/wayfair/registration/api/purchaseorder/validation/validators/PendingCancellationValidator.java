package com.wayfair.registration.api.purchaseorder.validation.validators;

import static com.wayfair.registration.api.domain.Failure.PENDING_CANCELLATION_ALERT;

import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.persistence.PendingCancellationRepository;
import com.wayfair.registration.api.purchaseorder.validation.dto.FailureAndMessageArgs;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class PendingCancellationValidator implements RegistrationPoValidator {

  private final PendingCancellationRepository pendingCancellationRepository;

  @Override
  public List<FailureAndMessageArgs> validate(
      List<ShippingDocumentType> shippingDocumentTypes,
      RegistrationPo registrationPo) {
    log.debug("Validating on pending cancellation alerts for PO number {}", registrationPo.getFullPONumber());

    boolean hasPendingCancellationAlerts = pendingCancellationRepository.hasPendingCancellationAlerts(
        registrationPo.getPoNum(), registrationPo.getSuID());

    if (!hasPendingCancellationAlerts) {
      return Collections.emptyList();
    }

    return List.of(
        FailureAndMessageArgs.builder()
            .failure(PENDING_CANCELLATION_ALERT)
            .messageArgs(Map.of("poNum", registrationPo.getFullPONumber()))
            .build()
    );
  }

}
