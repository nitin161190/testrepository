package com.wayfair.registration.api.purchaseorder.documents.ucc;

import javax.persistence.Entity;
import javax.persistence.EntityResult;
import javax.persistence.FieldResult;
import javax.persistence.Id;
import javax.persistence.SqlResultSetMapping;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@Builder
@SqlResultSetMapping(name = "UccLabelSettingsMapping",
    entities = {
        @EntityResult(
            entityClass = UccLabelSettings.class,
            fields = {
                @FieldResult(name = "showUcc", column = "is_show_ucc"),
                @FieldResult(name = "largeParcelType", column = "large_parcel_type"),
            }
        )
    }
)
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class UccLabelSettings {

  @Id
  boolean showUcc;
  Integer largeParcelType;

}
