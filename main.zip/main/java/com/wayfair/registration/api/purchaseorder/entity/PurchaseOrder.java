package com.wayfair.registration.api.purchaseorder.entity;

import com.wayfair.registration.api.config.OffsetDateTimeConverter;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Table(name = "tblExtranetOut", catalog = "csn_extranet_fulfillment")
@IdClass(PurchaseOrderId.class)
@DynamicUpdate
@EntityListeners(PurchaseOrderListener.class)
public class PurchaseOrder  {

  private static final String TIME_ZONE_US_EASTERN = "America/New_York";

  @Builder
  public PurchaseOrder(int purchaseOrderNumber, BigInteger orderId, int storeId, int marketingCategoryId,
                       String supplierAddress1, String supplierAddress2, String supplierAddress3,
                       String supplierCity, String supplierState, String supplierPostalCode,
                       String supplierCountry, int supplierId, String supplierName, String supplierContact,
                       String supplierPhone, String supplierFax, String supplierPhoneNumberExtension,
                       String carrierName, LocalDate purchaseOrderDate, LocalDate maxShipDate,
                       LocalDate readyForPickupDate, OffsetDateTime purchaseOrderDateTz,
                       OffsetDateTime maxShipDateTz, boolean isReplacement, int replacementPartId,
                       Integer thirdPartyCarrierId, String scacCode, Integer classId, Boolean isPalletized,
                       Integer palletCount, BigDecimal palletWeight, Integer shipClassId,
                       OffsetDateTime readyForPickupDateTz, Integer lastReviewedExtranetUserId,
                       Integer lastReviewedEmployeeId, int insertCount, int updateCount) {
    this.purchaseOrderNumber = purchaseOrderNumber;
    this.orderId = orderId;
    this.storeId = storeId;
    this.marketingCategoryId = marketingCategoryId;
    this.supplierAddress1 = supplierAddress1;
    this.supplierAddress2 = supplierAddress2;
    this.supplierAddress3 = supplierAddress3;
    this.supplierCity = supplierCity;
    this.supplierState = supplierState;
    this.supplierPostalCode = supplierPostalCode;
    this.supplierCountry = supplierCountry;
    this.supplierId = supplierId;
    this.supplierName = supplierName;
    this.supplierContact = supplierContact;
    this.supplierPhone = supplierPhone;
    this.supplierFax = supplierFax;
    this.supplierPhoneNumberExtension = supplierPhoneNumberExtension;
    this.carrierName = carrierName;
    this.purchaseOrderDate = purchaseOrderDate;
    this.maxShipDate = maxShipDate;
    this.readyForPickupDate = readyForPickupDate;
    this.purchaseOrderDateTz = purchaseOrderDateTz;
    this.maxShipDateTz = maxShipDateTz;
    this.isReplacement = isReplacement;
    this.replacementPartId = replacementPartId;
    this.thirdPartyCarrierId = thirdPartyCarrierId;
    this.scacCode = scacCode;
    this.classId = classId;
    this.isPalletized = isPalletized;
    this.palletCount = palletCount;
    this.palletWeight = palletWeight;
    this.shipClassId = shipClassId;
    this.readyForPickupDateTz = readyForPickupDateTz;
    this.lastReviewedExtranetUserId = lastReviewedExtranetUserId;
    this.lastReviewedEmployeeId = lastReviewedEmployeeId;
    this.insertCount = insertCount;
    this.updateCount = updateCount;
  }

  @Id
  @NotNull
  @Column(name = "ExoPONum")
  private int purchaseOrderNumber;

  @Column(name = "ExoOrID")
  private BigInteger orderId;

  @NotNull
  @Column(name = "ExoSoID")
  private int storeId;

  @NotNull
  @Column(name = "ExoMkcID")
  private int marketingCategoryId;

  @Column(name = "ExoSupplierAddress1")
  private String supplierAddress1;

  @Column(name = "ExoSupplierAddress2")
  private String supplierAddress2;

  @Column(name = "ExoSupplierAddress3")
  private String supplierAddress3;

  @Column(name = "ExoSupplierCity")
  private String supplierCity;

  @Column(name = "ExoSupplierState")
  private String supplierState;

  @Column(name = "ExoSupplierPostalCode")
  private String supplierPostalCode;

  @Column(name = "ExoSupplierCountry")
  private String supplierCountry;

  @NotNull
  @Column(name = "ExoSuID")
  private int supplierId;

  @Column(name = "ExoSupplierName")
  private String supplierName;

  @Column(name = "ExoSupplierContact")
  private String supplierContact;

  @Column(name = "ExoSupplierPhone")
  private String supplierPhone;

  @Column(name = "ExoSupplierFax")
  private String supplierFax;

  @Column(name = "ExoSupplierPhoneExt")
  private String supplierPhoneNumberExtension;

  @Column(name = "ExoCrName")
  private String carrierName;

  @Column(name = "ExoPODate")
  private LocalDate purchaseOrderDate;

  @Column(name = "ExoMaxShipDate")
  private LocalDate maxShipDate;

  @Column(name = "ExoTimeRegistered", updatable = false)
  private LocalDateTime timeRegistered;

  @Column(name = "ExoRfpDate")
  private LocalDate readyForPickupDate;

  @Column(name = "ExoPODatetz")
  @Convert(converter = OffsetDateTimeConverter.class)
  private OffsetDateTime purchaseOrderDateTz;

  @Column(name = "ExoMaxShipDatetz")
  @Convert(converter = OffsetDateTimeConverter.class)
  private OffsetDateTime maxShipDateTz;

  @Id
  @NotNull
  @Column(name = "ExoIsReplacement")
  private boolean isReplacement;

  @Id
  @NotNull
  @Column(name = "ExoRpID")
  private int replacementPartId;

  @Column(name = "ExoTsID")
  private Integer thirdPartyCarrierId;

  @Column(name = "ExoSCACCode")
  private String scacCode;

  @Column(name = "ExoClassID")
  private Integer classId;

  @Column(name = "ExoIsPalletized")
  private Boolean isPalletized;

  @Column(name = "ExoPalletCount")
  private Integer palletCount;

  @Column(name = "ExoPalletWeight")
  private BigDecimal palletWeight;

  @Column(name = "ExoTimeRegisteredtz", updatable = false)
  @Convert(converter = OffsetDateTimeConverter.class)
  private OffsetDateTime timeRegisteredDateTz;

  @Column(name = "ExoSpClassID")
  private Integer shipClassId;

  @Column(name = "ExoRfpDatetz")
  @Convert(converter = OffsetDateTimeConverter.class)
  private OffsetDateTime readyForPickupDateTz;

  @Column(name = "ExoLastRevExuID")
  private Integer lastReviewedExtranetUserId;

  @Column(name = "ExoLastRevEmID")
  private Integer lastReviewedEmployeeId;

  @Transient
  private int insertCount;

  @Transient
  private int updateCount;

  @PrePersist
  private void prePersistFunction() {
    this.timeRegistered = LocalDateTime.now();
    this.timeRegisteredDateTz = ZonedDateTime.of(LocalDateTime.now(), ZoneId.of(TIME_ZONE_US_EASTERN))
        .toOffsetDateTime();
  }

}
