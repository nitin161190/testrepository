package com.wayfair.registration.api.purchaseorder.documents.ucc;

import java.util.Optional;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class UccLabelRepository {

  private final EntityManager entityManager;

  public UccLabelRepository(@Qualifier("c4EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public Optional<UccLabelSettings> getUccLabelSettings(int supplierId) {
    UccLabelSettings uccLabelSettings =
        (UccLabelSettings) entityManager.createNativeQuery(
            "SELECT SuEnableWayfairUCC AS is_show_ucc,"
                + "            SisLargeParcelUCCType AS large_parcel_type"
                + "        FROM csn_order.dbo.tblSupplierShippingSettings WITH (NOLOCK)"
                + "        LEFT JOIN csn_order.dbo.tblSupplierInventorySettings WITH (NOLOCK) "
                + "               ON SuID = SisSuID"
                + "        WHERE SuID = :supplier_id", "UccLabelSettingsMapping")
        .setParameter("supplier_id", supplierId)
        .getSingleResult();

    return Optional.ofNullable(uccLabelSettings);
  }

}
