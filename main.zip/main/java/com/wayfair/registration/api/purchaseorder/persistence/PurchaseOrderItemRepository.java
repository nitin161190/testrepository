package com.wayfair.registration.api.purchaseorder.persistence;

import com.wayfair.registration.api.purchaseorder.entity.PurchaseOrderItem;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public interface PurchaseOrderItemRepository extends CrudRepository<PurchaseOrderItem, Integer> {

  @Transactional
  void deleteByPurchaseOrderNumber(Integer purchaseOrderNumber);

  @Transactional
  @Modifying
  @Query("update PurchaseOrderItem"
      + " set quantity = :quantity,"
      + " partNumber = :partNumber,"
      + " itemName = :itemName,"
      + " partWeight = :partWeight,"
      + " partBoxes = :partBoxes,"
      + " estimatedShipDate = :estimatedShipDate,"
      + " estimatedShipDatetz = :estimatedShipDatetz,"
      + " isReplacement = :isReplacement,"
      + " shipClassId = :shipClassId,"
      + " boxClass = :boxClass,"
      + " nmfc = :nmfc,"
      + " lastReviewedExtranetUserId = :lastReviewedExtranetUserId,"
      + " lastReviewedEmployeeId = :lastReviewedEmployeeId,"
      + " pieceType = :pieceType"
      + " where purchaseOrderNumber = :purchaseOrderNumber"
      + " and orderProductId = :orderProductId"
      + " and ISNULL(replacementPartId,0) = ISNULL(:replacementPartId,0)")
  void updatePurchaseOrderItem(
      @Param("purchaseOrderNumber") int purchaseOrderNumber,
      @Param("orderProductId") BigInteger orderProductId,
      @Param("replacementPartId") Integer replacementPartId,
      @Param("quantity") int quantity,
      @Param("partNumber") String partNumber,
      @Param("itemName") String itemName,
      @Param("partWeight") BigDecimal partWeight,
      @Param("partBoxes") Integer partBoxes,
      @Param("estimatedShipDate") LocalDate estimatedShipDate,
      @Param("estimatedShipDatetz") OffsetDateTime estimatedShipDatetz,
      @Param("isReplacement") boolean isReplacement,
      @Param("shipClassId") Integer shipClassId,
      @Param("boxClass") String boxClass,
      @Param("nmfc") String nmfc,
      @Param("lastReviewedExtranetUserId") Integer lastReviewedExtranetUserId,
      @Param("lastReviewedEmployeeId") Integer lastReviewedEmployeeId,
      @Param("pieceType") String pieceType
  );
}
