package com.wayfair.registration.api.purchaseorder;

import com.wayfair.registration.api.dto.PurchaseOrderNumber;
import com.wayfair.registration.api.purchaseorder.dto.BulkPurchaseOrderRefreshInput;
import com.wayfair.registration.api.purchaseorder.dto.OrderInput;
import com.wayfair.registration.api.purchaseorder.dto.RefreshPurchaseOrderResultMapping;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.util.MdcUtil;
import io.micrometer.core.annotation.Timed;
import io.swagger.v3.oas.annotations.Operation;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Timed
@RestController
@RequiredArgsConstructor
@Slf4j
public class PurchaseOrderController {

  private final PurchaseOrderService purchaseOrderService;

  @Operation(summary = "Performs single Purchase Order registration")
  @PostMapping(value = "/registration")
  public ResponseEntity<List<RegistrationPo>> singleRegistration(
      @Valid @RequestBody OrderInput orderInput
  ) {
    MdcUtil.init(orderInput);
    val registrationPos = purchaseOrderService.singleRegistration(orderInput);
    return ResponseEntity.ok(registrationPos);
  }

  @Operation(summary = "Performs bulk Purchase Order registration")
  @PostMapping(value = "/bulk-registration")
  public ResponseEntity<List<RegistrationPo>> bulkRegistration(
      @Valid @RequestBody List<OrderInput> orderInputs
  ) {
    MdcUtil.initWithOrderInputs(orderInputs);
    val registrationPos = purchaseOrderService.bulkRegistration(orderInputs);
    return ResponseEntity.ok(registrationPos);
  }

  @Operation(summary = "Refresh Purchase Order")
  @DeleteMapping(value = "/registration/{fullPONumber}")
  public ResponseEntity<Void> refreshPurchaseOrder(@PathVariable String fullPONumber) {
    MdcUtil.init(fullPONumber);
    PurchaseOrderNumber purchaseOrderNumber;
    try {
      purchaseOrderNumber = new PurchaseOrderNumber(fullPONumber);
    } catch (IllegalArgumentException e) {
      log.warn("Full purchase order number {} is not valid", fullPONumber, e);
      return ResponseEntity.badRequest().build();
    }

    purchaseOrderService.refreshPurchaseOrder(purchaseOrderNumber);

    return ResponseEntity.ok().build();
  }

  @Operation(summary = "Refresh Purchase Orders")
  @DeleteMapping(value = "/bulk-registration")
  public ResponseEntity<List<RefreshPurchaseOrderResultMapping>>
      refreshPurchaseOrders(@RequestBody List<BulkPurchaseOrderRefreshInput> bulkPurchaseOrderRefreshInputs) {
    MdcUtil.initWithRefreshInputs(bulkPurchaseOrderRefreshInputs);
    List<PurchaseOrderNumber> purchaseOrderNumbers = new ArrayList<>();
    List<String> invalidPurchaseOrderNumbers = new ArrayList<>();
    for (BulkPurchaseOrderRefreshInput bulkPurchaseOrderRefreshInput : bulkPurchaseOrderRefreshInputs) {
      try {
        purchaseOrderNumbers.add(new PurchaseOrderNumber(bulkPurchaseOrderRefreshInput.getFullPurchaseOrderNumber()));
      } catch (IllegalArgumentException e) {
        log.warn(
                "Full purchase order number {} is not valid",
                bulkPurchaseOrderRefreshInput.getFullPurchaseOrderNumber(), e);
        invalidPurchaseOrderNumbers.add(bulkPurchaseOrderRefreshInput.getFullPurchaseOrderNumber());
      }
    }

    var refreshPurchaseOrderResultMapping = purchaseOrderService.refreshPurchaseOrders(purchaseOrderNumbers);
    invalidPurchaseOrderNumbers.stream().map(
            invalidPurchaseOrderNumber ->
                    new RefreshPurchaseOrderResultMapping(invalidPurchaseOrderNumber, false)
    ).collect(Collectors.toCollection(() -> refreshPurchaseOrderResultMapping));

    return ResponseEntity.ok(refreshPurchaseOrderResultMapping);
  }
}
