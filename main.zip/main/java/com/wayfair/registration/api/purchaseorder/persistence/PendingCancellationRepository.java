package com.wayfair.registration.api.purchaseorder.persistence;

import java.util.List;
import javax.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

@Repository
public class PendingCancellationRepository {

  private static final int PENDING_CANCELLATION_ALERT_EXISTS = 7;
  private static final int STATUS_PENDING_CANCELLATION = 9;

  private final EntityManager entityManager;

  public PendingCancellationRepository(@Qualifier("c43EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  public boolean hasPendingCancellationAlerts(int purchaseOrderNumber, Integer supplierId) {
    List<Integer> result = entityManager.createNativeQuery(""
            + "SELECT"
            + "    w.WtePoNum AS PONum"
            + "  FROM csn_weather.dbo.tblWeatherEventDriven w WITH (NOLOCK)"
            + "    INNER JOIN csn_order.dbo.tblPurchaseOrder po WITH (NOLOCK) ON w.WtePoNum = po.PoNum"
            + "    INNER JOIN csn_order.dbo.tblOrderProduct op WITH (NOLOCK) ON op.OpID = w.WteOpID"
            + "  WHERE w.WteTypeID = " + PENDING_CANCELLATION_ALERT_EXISTS
            + "    AND OpPsID = " + STATUS_PENDING_CANCELLATION
            + "    AND PONum = ?1"
            + "    AND w.WteSuID IN (SELECT SuId FROM csn_order.dbo.fnGetSupplierFamily(?2))"
            + "    AND ISNULL(po.PoIsWFS, 0) = 0"
            + "  GROUP BY WtePoNum")
        .setParameter(1, purchaseOrderNumber)
        .setParameter(2, supplierId)
        .getResultList();

    return !result.isEmpty();
  }
}
