package com.wayfair.registration.api.dto;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.apache.commons.lang3.math.NumberUtils;

@Getter
@EqualsAndHashCode
public class PurchaseOrderNumber {

  private static final String FULL_PO_NUMBER_TEMPLATE = "%s%s-R-%s";
  private static final Pattern FULL_PO_NUMBER_PATTERN =
      Pattern.compile("^(?<storePrefix>[A-Z]+)(?<purchaseOrderNumber>\\d+)(-R-(?<replacementPartId>\\d+))?$");

  private static final String FULL_PO_NUMBER_WITHOUT_REPLACEMENT_TEMPLATE = "%s%s";

  private final String storePrefix;
  private final Integer purchaseOrderNumber;
  private final Integer replacementPartId;

  public PurchaseOrderNumber(String fullPONumber) {
    Matcher matcher = FULL_PO_NUMBER_PATTERN.matcher(fullPONumber);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Cannot parse provided fullPONumber: " + fullPONumber);
    }

    this.storePrefix = matcher.group("storePrefix");
    this.purchaseOrderNumber = NumberUtils.createInteger(matcher.group("purchaseOrderNumber"));
    this.replacementPartId = NumberUtils.createInteger(matcher.group("replacementPartId"));
  }

  public String getFullPoNumber() {
    if (this.isReplacement()) {
      return String.format(FULL_PO_NUMBER_TEMPLATE, storePrefix, purchaseOrderNumber, replacementPartId);
    } else {
      return String.format(FULL_PO_NUMBER_WITHOUT_REPLACEMENT_TEMPLATE, storePrefix, purchaseOrderNumber);
    }
  }

  public boolean isReplacement() {
    return replacementPartId != null;
  }
}
