package com.wayfair.registration.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Builder
@Getter
@EqualsAndHashCode
@JsonIgnoreProperties({"replacement"})
public class DeleteSlmOverpackRequest {

  int purchaseOrderNumber;

  Integer replacementPartId;

  @JsonProperty("isReplacement")
  boolean isReplacement;
}
