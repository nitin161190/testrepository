package com.wayfair.registration.api.ordercrud;

import com.wayfair.registration.api.dto.PurchaseOrderNumber;
import com.wayfair.so.orderfulfillment.OrderActionEnumType;
import com.wayfair.so.orderfulfillment.SoOrderCrudMonolithEvent;
import java.time.Clock;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class KafkaOrderCrudEventProducer implements OrderCrudEventProducer {

  private static final int PURCHASE_ORDER_PROCESSING_STATUS = 13;
  private static final String SOURCE = "so-order-crud-event-refresh-producer";
  public static final String ORDER_CRUD_KAFKA_TOPIC = "so-order-crud-event-monolith";

  private final KafkaTemplate<String, SoOrderCrudMonolithEvent> kafkaTemplate;
  private final Clock clock;

  @Autowired
  public KafkaOrderCrudEventProducer(KafkaTemplate<String, SoOrderCrudMonolithEvent> kafkaTemplate) {
    this(kafkaTemplate, Clock.systemUTC());
  }

  KafkaOrderCrudEventProducer(KafkaTemplate<String, SoOrderCrudMonolithEvent> kafkaTemplate, Clock clock) {
    this.kafkaTemplate = kafkaTemplate;
    this.clock = clock;
  }

  @Override
  public void sendRefreshEvent(PurchaseOrderNumber purchaseOrderNumber) {
    SoOrderCrudMonolithEvent eventData = SoOrderCrudMonolithEvent.newBuilder()
        .setPoNum(purchaseOrderNumber.getPurchaseOrderNumber())
        .setStorePrefix(purchaseOrderNumber.getStorePrefix())
        .setRpId(purchaseOrderNumber.getReplacementPartId())
        .setPoStatus(PURCHASE_ORDER_PROCESSING_STATUS)
        .setSource(SOURCE)
        .setAction(OrderActionEnumType.UPDATE)
        .setSupplierId(null)
        .setRefProdId(null)
        .setOrderDate(null)
        .setMustShipByDate(null)
        .setReadyForPickupDate(null)
        .setOrderType(null)
        .setShipClassId(null)
        .setCarrierId(null)
        .setCarrierName(null)
        .setCustomerName(null)
        .setCustomerAddress1(null)
        .setCustomerAddress2(null)
        .setCustomerCity(null)
        .setCustomerPostalCode(null)
        .setCustomerState(null)
        .setCustomerCountry(null)
        .setShipToName(null)
        .setShipToAddress1(null)
        .setShipToAddress2(null)
        .setShipToCity(null)
        .setShipToPostalCode(null)
        .setShipToState(null)
        .setShipToCountry(null)
        .setIsWDN(null)
        .setTotalPrice(null)
        .setOriginalEventTimestamp(clock.millis())
        .build();
    kafkaTemplate.send(ORDER_CRUD_KAFKA_TOPIC, purchaseOrderNumber.getFullPoNumber(), eventData);
  }
}
