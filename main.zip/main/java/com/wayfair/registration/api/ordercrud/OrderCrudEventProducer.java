package com.wayfair.registration.api.ordercrud;

import com.wayfair.registration.api.dto.PurchaseOrderNumber;

public interface OrderCrudEventProducer {

  void sendRefreshEvent(PurchaseOrderNumber purchaseOrderNumber);

}
