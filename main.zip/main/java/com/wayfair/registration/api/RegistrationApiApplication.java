package com.wayfair.registration.api;

import com.wayfair.registration.api.config.LocalConfigurationApplicationContextInitializer;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class RegistrationApiApplication {

  public static void main(String[] args) {
    new SpringApplicationBuilder(RegistrationApiApplication.class)
        .listeners(new LocalConfigurationApplicationContextInitializer()).run();
  }
}
