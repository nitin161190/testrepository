package com.wayfair.registration.api.replacementparts;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

@FeignClient(value = "replacement-parts", url = "${replacement-parts.url}")
public interface ReplacementPartsClient {

  @PutMapping(value = "/v0/replacement-parts/{replacementPartId}/deregister")
  void deregisterReplacementPart(@PathVariable("replacementPartId") int replacementPartId);

}
