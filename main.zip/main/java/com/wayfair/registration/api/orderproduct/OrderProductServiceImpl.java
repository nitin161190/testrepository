package com.wayfair.registration.api.orderproduct;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.UnexpectedRollbackException;

@Slf4j
@Service
public class OrderProductServiceImpl implements OrderProductService {

  public static final String ORDER_PRODUCT_STATUS_UPDATE_ROLLBACK_COUNTER = "order.product.status.update.rollback";

  private OrderProductRepository orderProductRepository;
  private Counter orderProductStatusUpdateRollbackCounter;

  @Autowired
  public OrderProductServiceImpl(OrderProductRepository orderProductRepository, MeterRegistry meterRegistry) {
    this.orderProductRepository = orderProductRepository;
    this.orderProductStatusUpdateRollbackCounter = meterRegistry.counter(ORDER_PRODUCT_STATUS_UPDATE_ROLLBACK_COUNTER);
  }

  @Override
  public boolean updateOrderProductRegisterStatus(int purchaseOrderNumber) {
    try {
      return orderProductRepository.updateOrderProductRegisterStatus(purchaseOrderNumber);
    } catch (UnexpectedRollbackException ex) {
      // We are ignoring this particular exception because it is expected to happen when the order is already shipped.
      // For details see OM-2261.
      log.warn("Order product update for PO number {} was rolledback. "
          + "This is expected occasionally, ignoring.", purchaseOrderNumber, ex);
      orderProductStatusUpdateRollbackCounter.increment();
      return false;
    }
  }

  @Override
  public boolean updateOrderProductSupplierAndCarrier(
      int purchaseOrderNumber, int supplierId, int thirdPartyCarrierId) {
    try {
      log.info("Updating tblOrderProduct for PO: {} with WarehouseId: {} and carrier ID: {}",
          purchaseOrderNumber, supplierId, thirdPartyCarrierId);
      return orderProductRepository.updateOrderProductSupplierAndCarrier(
          purchaseOrderNumber, supplierId, thirdPartyCarrierId);
    } catch (Exception ex) {
      log.error("Unable to update tblOrderProduct for PO: {}", purchaseOrderNumber, ex);
      return false;
    }

  }
}
