package com.wayfair.registration.api.orderproduct;

public interface OrderProductService {

  boolean updateOrderProductRegisterStatus(int purchaseOrderNumber);

  boolean updateOrderProductSupplierAndCarrier(int purchaseOrderNumber, int supplierId, int thirdPartyCarrierId);

}
