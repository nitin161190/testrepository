package com.wayfair.registration.api.orderproduct;

import javax.persistence.EntityManager;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Repository
public class OrderProductRepository {

  private static final int STT_PENDING_SHIP_CONFIRM = 7;

  private final EntityManager entityManager;

  public OrderProductRepository(@Qualifier("c4EntityManager") EntityManager entityManager) {
    this.entityManager = entityManager;
  }

  @Transactional("c4TransactionManager")
  public boolean updateOrderProductRegisterStatus(int purchaseOrderNumber) {
    try {
      int updatedEntries =
          entityManager
              .createNativeQuery("UPDATE tblOrderProduct "
                  + "SET OpIsRegistered = 0, OpTimeRegistered = NULL, OpPsID = ?1 "
                  + "WHERE OpCurrentPONum = ?2 "
                  + "AND (IsNull(OpIsRegistered, 1) <> 0 OR OpTimeRegistered IS NOT NULL OR OpPsID <> ?3)")
              .setParameter(1, STT_PENDING_SHIP_CONFIRM)
              .setParameter(2, purchaseOrderNumber)
              .setParameter(3, STT_PENDING_SHIP_CONFIRM)
              .executeUpdate();
      return updatedEntries > 0;
    } catch (Exception ex) {
      if (ex.getCause() instanceof SQLGrammarException) {
        // We are ignoring this particular exception because it is expected to happen when the order is already shipped.
        // For details see OM-2204.
        log.warn("Could not update order product for purchase order number {}. "
            + "This is expected occasionally, ignoring.", purchaseOrderNumber, ex);
        return false;
      } else {
        throw ex;
      }
    }
  }

  @Transactional("c4TransactionManager")
  public boolean updateOrderProductSupplierAndCarrier(
      int purchaseOrderNumber, int supplierId, int thirdPartyCarrierId) {
    try {
      int updatedEntries =
          entityManager
              .createNativeQuery("UPDATE csn_order.dbo.tblOrderProduct "
                  + "SET OpSuID = ?1, OpTsID = ?2 "
                  + "WHERE OpCurrentPONum = ?3 "
                  + "AND (OpSuID <> ?4 OR OpTsID <> ?5)")
              .setParameter(1, supplierId)
              .setParameter(2, thirdPartyCarrierId)
              .setParameter(3, purchaseOrderNumber)
              .setParameter(4, supplierId)
              .setParameter(5, thirdPartyCarrierId)
              .executeUpdate();
      return updatedEntries > 0;
    } catch (Exception ex) {
      log.error("Could not update tblOrderProduct for PO {}", purchaseOrderNumber, ex);
      throw ex;
    }
  }
}
