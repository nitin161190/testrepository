package com.wayfair.registration.api.bulkregistration.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum BulkRegistrationBatchPOStatusType {
  NEW(0),
  SUCCESS(1),
  FAILURE(2);

  private final int index;

  public static BulkRegistrationBatchPOStatusType fromIndex(int index) {
    switch (index) {
      case 0: return NEW;
      case 1: return SUCCESS;
      case 2: return FAILURE;
      default: throw new IllegalArgumentException("Could not find index " + index + " in enum.");
    }
  }

}
