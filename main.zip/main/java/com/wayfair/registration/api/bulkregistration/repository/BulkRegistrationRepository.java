package com.wayfair.registration.api.bulkregistration.repository;

import com.wayfair.registration.api.bulkregistration.entity.BulkRegistration;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BulkRegistrationRepository extends CrudRepository<BulkRegistration, Integer> {

}
