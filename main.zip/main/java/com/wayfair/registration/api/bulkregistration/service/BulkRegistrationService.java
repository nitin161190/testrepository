package com.wayfair.registration.api.bulkregistration.service;

import com.wayfair.registration.api.bulkregistration.entity.BulkRegistration;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatch;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatchPO;
import com.wayfair.registration.api.bulkregistration.repository.BulkRegistrationRepository;
import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.purchaseorder.documents.PrintableShippingDocumentsService;
import com.wayfair.registration.api.purchaseorder.documents.dto.PrintableShippingDocumentsRequest;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.so.orderfulfillment.BulkRegistrationShippingDocumentEvent;
import datadog.trace.api.Trace;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.ImmutablePair;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BulkRegistrationService {

  static final String BULK_REGISTRATION_SHIPPING_DOCUMENT_TOPIC = "so-shipping-document-request-event";

  private final BulkRegistrationRepository repository;
  private final BulkRegistrationGraphQLToEntityMappingService bulkRegistrationGraphQLToEntityMappingService;
  private final BulkRegistrationEntityToAvroMappingService bulkRegistrationEntityToAvroMappingService;
  private final PrintableShippingDocumentsService printableShippingDocumentsService;
  private final KafkaTemplate<String, BulkRegistrationShippingDocumentEvent> kafkaTemplate;

  @Trace
  @Transactional
  public BulkRegistration save(
      SoOrderManagementRegisterOrdersInput registrationInput,
      Integer extranetUserId,
      Integer employeeId
  ) {
    BulkRegistration bulkRegistration = bulkRegistrationGraphQLToEntityMappingService.toBulkRegistration(
        registrationInput, extranetUserId, employeeId);
    return repository.save(bulkRegistration);
  }

  @Trace
  public void sendShippingDocumentsEvents(BulkRegistration bulkRegistration, List<RegistrationPo> registrationPos) {
    log.info("Sending events for bulkRegistration=[{}], registrationPos=[{}]", bulkRegistration, registrationPos);

    bulkRegistration.getBulkRegistrationBatches().stream()
        .map(this::createBatchAndBatchPoPairs)
        .flatMap(List::stream)
        .forEach(batchAndBatchPoPair ->
            createAndSendShippingDocumentsEvent(batchAndBatchPoPair, bulkRegistration, registrationPos));
  }

  private void createAndSendShippingDocumentsEvent(
      ImmutablePair<BulkRegistrationBatch, BulkRegistrationBatchPO> batchAndBatchPoPair,
      BulkRegistration bulkRegistration,
      List<RegistrationPo> registrationPos
  ) {
    BulkRegistrationBatch batch = batchAndBatchPoPair.left;
    BulkRegistrationBatchPO batchPo = batchAndBatchPoPair.right;

    RegistrationPo registrationPo = selectRegistrationPo(registrationPos, batchPo);
    Set<ShippingDocumentType> printableShippingDocumentTypes = getPrintableShippingDocumentTypes(registrationPo);

    BulkRegistrationShippingDocumentEvent event =
        bulkRegistrationEntityToAvroMappingService.toShippingDocumentEvent(
            bulkRegistration,
            batch,
            batchPo,
            registrationPo,
            printableShippingDocumentTypes
        );

    kafkaTemplate.send(BULK_REGISTRATION_SHIPPING_DOCUMENT_TOPIC, event);
  }

  private List<ImmutablePair<BulkRegistrationBatch, BulkRegistrationBatchPO>> createBatchAndBatchPoPairs(
      BulkRegistrationBatch bulkRegistrationBatch) {
    return bulkRegistrationBatch.getBulkRegistrationBatchPOs().stream()
        .map(batchPo -> new ImmutablePair<>(bulkRegistrationBatch, batchPo))
        .collect(Collectors.toList());
  }

  private RegistrationPo selectRegistrationPo(List<RegistrationPo> registrationPos, BulkRegistrationBatchPO batchPo) {
    return registrationPos.stream()
        .filter(rp -> rp.getPoNum().equals(batchPo.getPurchaseOrder()))
        .findFirst()
        .orElseThrow(() -> {
          String message = "Cannot find RegistrationPo for batch " + batchPo;
          return new RuntimeException(message);
        });
  }

  private Set<ShippingDocumentType> getPrintableShippingDocumentTypes(RegistrationPo registrationPo) {
    FullPurchaseOrderNumber purchaseOrderNumber = new FullPurchaseOrderNumber(
        registrationPo.getPoStorePrefix(),
        registrationPo.getPoNum(),
        registrationPo.getRpID()
    );

    PrintableShippingDocumentsRequest request = PrintableShippingDocumentsRequest.builder()
        .supplierSubEntityId(registrationPo.getSupplierSubEntityID())
        .thirdPartyId(registrationPo.getTsID())
        .shipClassId(registrationPo.getShipClass())
        .labelPrintEnabledForCarrier(registrationPo.getIsLabelPrintEnabledForCarrier())
        .fullPurchaseOrderNumber(purchaseOrderNumber)
        .supplierId(registrationPo.getSuID())
        .build();

    Set<ShippingDocumentType> shippingDocumentTypes =
        printableShippingDocumentsService.determinePrintableShippingDocuments(request);

    log.info("Printable shipping documents for PO {} are {}", purchaseOrderNumber, shippingDocumentTypes);

    return shippingDocumentTypes;
  }

}
