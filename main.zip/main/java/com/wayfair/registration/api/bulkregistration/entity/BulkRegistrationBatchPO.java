package com.wayfair.registration.api.bulkregistration.entity;

import java.sql.Timestamp;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@Table(name = "tblBulkRegistrationBatchPO", catalog = "csn_extranet_fulfillment")
public class BulkRegistrationBatchPO {

  @Id
  @Column(name = "BrbpID")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "BrbpRpID")
  private Integer replacementPartId;

  @Column(name = "BrbpPackingSlipFilename")
  private String packingSlipFilename;

  @Column(name = "BrbpShippingLabelFilename")
  private String shippingLabelFilename;

  @Column(name = "BrbpBOLFilename")
  private String bolFilename;

  @Column(name = "BrbpUCCFilename")
  private String uccFilename;

  @Column(name = "BrbpStatus")
  private BulkRegistrationBatchPOStatusType status;

  @Column(name = "BrbpFailureErrorMessage")
  private String failureErrorMessage;

  @Column(name = "BrbpCreatedAt")
  private Timestamp createdAt;

  @Column(name = "BrbpUpdatedAt")
  private Timestamp updatedAt;

  @Column(name = "BrbpRfpDate")
  private Timestamp readyForPickupDate;

  @Column(name = "BrbpCustomsDocumentFilename")
  private String customsDocumentFilename;

  @Column(name = "BrbpShipClassID")
  private Integer shipClassId;

  @Column(name = "BrbpShippingLabelSecondLegFilename")
  private String shippingLabelSecondLegFilename;

  @Column(name = "BrbpManifestFilename")
  private String manifestFilename;

  @Column(name = "BrbpSOLabelFilename")
  private String soLabelFilename;

  @Column(name = "BrbpIsPalletized")
  private boolean palletized;

  @Column(name = "BrbpPalletCount")
  private Short palletCount;

  @Column(name = "BrbpPalletWeight")
  private Double palletWeight;

  @ManyToOne
  @JoinColumn(name = "BrbpBrbID", nullable = false)
  @ToString.Exclude
  @EqualsAndHashCode.Exclude
  private BulkRegistrationBatch bulkRegistrationBatch;

  @Column(name = "BrbpPONum")
  private Integer purchaseOrder;

  @Column(name = "BrbpWarehouseId")
  private Integer supplierId;

  @Column(name = "BrbpCarrierID")
  private Integer shipCarrierId;

  @OneToMany(mappedBy = "bulkRegistrationBatchPO",
      fetch = FetchType.EAGER,
      cascade = CascadeType.ALL)
  private Set<BulkRegistrationBatchPOItem> bulkRegistrationBatchPOItems;

  public static BulkRegistrationBatchPOBuilder builder() {
    return new CustomBulkRegistrationBatchPOBuilder();
  }

  private static class CustomBulkRegistrationBatchPOBuilder extends BulkRegistrationBatchPOBuilder {

    @Override
    public BulkRegistrationBatchPO build() {
      BulkRegistrationBatchPO bulkRegistrationBatchPO = super.build();
      bulkRegistrationBatchPO.getBulkRegistrationBatchPOItems()
          .forEach(bulkRegistrationBatch -> bulkRegistrationBatch.setBulkRegistrationBatchPO(
              bulkRegistrationBatchPO));
      return bulkRegistrationBatchPO;
    }
  }

}
