package com.wayfair.registration.api.bulkregistration.entity;

import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@Table(name = "tblBulkRegistrationBatch", catalog = "csn_extranet_fulfillment")
public class BulkRegistrationBatch {

  @Id
  @Column(name = "BrbID")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "BrbStatus")
  private Short status;

  @Column(name = "BrbAttemptsCount")
  private Short attemptsCount;

  @ManyToOne
  @JoinColumn(name = "BrbBrID", nullable = false)
  @ToString.Exclude
  @EqualsAndHashCode.Exclude
  private BulkRegistration bulkRegistration;

  @OneToMany(mappedBy = "bulkRegistrationBatch", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  private Set<BulkRegistrationBatchPO> bulkRegistrationBatchPOs;
}
