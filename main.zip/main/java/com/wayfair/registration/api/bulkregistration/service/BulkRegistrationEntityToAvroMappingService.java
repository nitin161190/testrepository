package com.wayfair.registration.api.bulkregistration.service;

import com.wayfair.registration.api.bulkregistration.entity.BulkRegistration;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatch;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatchPO;
import com.wayfair.registration.api.domain.ShippingDocumentType;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPoItemCarton;
import com.wayfair.so.orderfulfillment.BulkRegistrationShippingDocumentEvent;
import com.wayfair.so.orderfulfillment.MeasurementUnitType;
import com.wayfair.so.orderfulfillment.PurchaseOrder;
import com.wayfair.so.orderfulfillment.PurchaseOrderItem;
import com.wayfair.so.orderfulfillment.PurchaseOrderItemCarton;
import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class BulkRegistrationEntityToAvroMappingService {

  public BulkRegistrationShippingDocumentEvent toShippingDocumentEvent(
      BulkRegistration bulkRegistration,
      BulkRegistrationBatch bulkRegistrationBatch,
      BulkRegistrationBatchPO bulkRegistrationBatchPO,
      RegistrationPo registrationPo,
      Set<ShippingDocumentType> printableShippingDocumentTypes
  ) {
    log.info("Creating Shipping Documents event for bulkRegistration=[{}], bulkRegistrationBatch=[{}], "
        + "bulkRegistrationBatchPO=[{}], registrationPo=[{}], printableShippingDocumentTypes=[{}]", bulkRegistration,
        bulkRegistrationBatch, bulkRegistrationBatchPO, registrationPo, printableShippingDocumentTypes);

    PurchaseOrder purchaseOrder = buildPurchaseOrder(bulkRegistrationBatchPO, registrationPo);

    boolean isPackingSlipNeeded =
        isDocumentNeeded(bulkRegistration.isPackingSlipNeeded(), ShippingDocumentType.PACKING_SLIP,
            printableShippingDocumentTypes);
    boolean isShippingLabelNeeded =
        isDocumentNeeded(bulkRegistration.isShippingLabelNeeded(), ShippingDocumentType.SHIPPING_LABEL,
            printableShippingDocumentTypes);
    boolean isBOLNeeded =
        isDocumentNeeded(bulkRegistration.isBolNeeded(), ShippingDocumentType.BOL,
            printableShippingDocumentTypes);
    boolean isUCCNeeded =
        isDocumentNeeded(bulkRegistration.isUccLabelNeeded(), ShippingDocumentType.UCC,
            printableShippingDocumentTypes);
    boolean isCustomsDocumentNeeded =
        isDocumentNeeded(bulkRegistration.isCustomsDocumentNeeded(), ShippingDocumentType.CUSTOMS,
            printableShippingDocumentTypes);
    boolean isManifestNeeded =
        isDocumentNeeded(bulkRegistration.isManifestNeeded(), ShippingDocumentType.MANIFEST,
            printableShippingDocumentTypes);
    boolean isSOLabelNeeded =
        isDocumentNeeded(bulkRegistration.isSoLabelNeeded(), ShippingDocumentType.SAMPLE_ORDER_LABEL,
            printableShippingDocumentTypes);

    return BulkRegistrationShippingDocumentEvent.newBuilder()
        .setBulkRegistrationId(bulkRegistration.getId())
        .setSupplierId(bulkRegistration.getSupplierId())
        .setIsPackingSlipNeeded(isPackingSlipNeeded)
        .setIsShippingLabelNeeded(isShippingLabelNeeded)
        .setIsBOLNeeded(isBOLNeeded)
        .setIsUCCLabelNeeded(isUCCNeeded)
        .setIsCustomsDocumentNeeded(isCustomsDocumentNeeded)
        .setIsManifestNeeded(isManifestNeeded)
        .setIsSOLabelNeeded(isSOLabelNeeded)
        .setIsSinglePrint(bulkRegistration.isSingleRegistration())
        .setExtranetUserId(bulkRegistration.getExtranetUserId() == null ? 0 : bulkRegistration.getExtranetUserId())
        .setEmployeeId(bulkRegistration.getEmployeeId() == null ? 0 : bulkRegistration.getEmployeeId())
        .setBatchId(bulkRegistrationBatch.getId())
        .setOrders(List.of(purchaseOrder))
        .setEventTime(Instant.now())
        .setEventId(UUID.randomUUID().toString())
        .build();
  }

  private boolean isDocumentNeeded(boolean isDocumentRequested,
                                   ShippingDocumentType shippingDocumentType,
                                   Set<ShippingDocumentType> printableShippingDocumentTypes) {
    return isDocumentRequested && printableShippingDocumentTypes.contains(shippingDocumentType);
  }

  private PurchaseOrder buildPurchaseOrder(BulkRegistrationBatchPO bulkRegistrationBatchPO,
                                           RegistrationPo registrationPo) {
    log.info("Building purchase orders list with bulkRegistrationBatchPO=[{}] and registrationPo=[{}]",
        bulkRegistrationBatchPO, registrationPo);

    String requestForPickupDate = bulkRegistrationBatchPO.getReadyForPickupDate() == null ? null :
        bulkRegistrationBatchPO.getReadyForPickupDate().toLocalDateTime().toLocalDate().toString();

    PurchaseOrder.Builder purchaseOrder = PurchaseOrder.newBuilder()
        .setStorePrefix(registrationPo.getPoStorePrefix())
        .setIsRFPDateChanged(
            registrationPo.getIsRFPDateChanged() != null && registrationPo.getIsRFPDateChanged())
        .setCarrierName(registrationPo.getCrName())
        .setSupplierSubEntityId(registrationPo.getSupplierSubEntityID())
        .setRecipientCountryId(registrationPo.getRecipientCountryID())
        .setRecipientPostalCode(registrationPo.getRecipientPostalCode())
        .setThirdPartyShipperId(registrationPo.getTsID())
        .setRequestForPickupDate(requestForPickupDate)
        .setPurchaseOrderNumber(bulkRegistrationBatchPO.getPurchaseOrder())
        .setReplacementPartId(bulkRegistrationBatchPO.getReplacementPartId())
        .setWarehouseId(bulkRegistrationBatchPO.getSupplierId())
        .setCarrierId(bulkRegistrationBatchPO.getShipCarrierId())
        .setShipClassId(bulkRegistrationBatchPO.getShipClassId())
        .setIsPalletized(bulkRegistrationBatchPO.isPalletized())
        .setPalletCount(bulkRegistrationBatchPO.getPalletCount() == null ? 0 :
            bulkRegistrationBatchPO.getPalletCount().intValue())
        .setPalletWeight(bulkRegistrationBatchPO.getPalletWeight())
        .setItems(buildItems(registrationPo))
        .setIsPalletized(bulkRegistrationBatchPO.isPalletized());

    if (bulkRegistrationBatchPO.isPalletized()) {
      purchaseOrder.setPalletCount(bulkRegistrationBatchPO.getPalletCount().intValue());
    } else {
      purchaseOrder.setPalletCount(0);
    }

    return purchaseOrder.build();

  }

  private List<PurchaseOrderItem> buildItems(RegistrationPo registrationPo) {
    return registrationPo.getItems().stream()
        .map(item -> {
          MeasurementUnitType measurementUnitType = item.getMeasurementUnitType() == null ? MeasurementUnitType.METRIC :
              MeasurementUnitType.valueOf(item.getMeasurementUnitType().name());
          return PurchaseOrderItem.newBuilder()
              .setPurchaseOrderNumber(registrationPo.getPoNum())
              .setReplacementPartId(registrationPo.getRpID())
              .setOrderProductId(item.getOpID().longValue())
              .setQuantity(item.getOpQty())
              .setPartWeight(item.getPrWeight().doubleValue())
              .setProductSKU(item.getOpPrSKU())
              .setPartNumber(item.getRefProdID())
              .setPieceCount(item.getPieceCount())
              .setPieceType(item.getPieceType())
              .setMeasurementUnitType(measurementUnitType)
              .setCartons(buildCartons(item.getCartons()))
              .build();
        })
        .collect(Collectors.toList());
  }

  private List<PurchaseOrderItemCarton> buildCartons(List<RegistrationPoItemCarton> cartons) {
    return cartons.stream()
        .map(carton -> PurchaseOrderItemCarton.newBuilder()
            .setOrderProductId(carton.getOpID().longValue())
            .setBoxClass(carton.getBoxClass())
            .setBoxNMFC(carton.getBoxNmfc())
            .setItemCartonDepth(carton.getItemCartonDepth().doubleValue())
            .setItemCartonHeight(carton.getItemCartonHeight().doubleValue())
            .setItemCartonWeight(carton.getItemCartonWeight().doubleValue())
            .setItemCartonWidth(carton.getItemCartonWidth().doubleValue())
            .build())
        .collect(Collectors.toList());
  }

}
