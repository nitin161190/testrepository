package com.wayfair.registration.api.bulkregistration.service;

import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.BILL_OF_LADING;
import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.CUSTOMS;
import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.MANIFEST;
import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.PACKING_SLIP;
import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.SAMPLE_ORDER_LABEL;
import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.SHIPPING_LABEL;
import static com.wayfair.registration.api.graphql.generated.types.SoOrderManagementShippingDocumentType.UCC;

import com.wayfair.registration.api.bulkregistration.entity.BulkRegistration;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatch;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatchPO;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatchPOItem;
import com.wayfair.registration.api.bulkregistration.entity.BulkRegistrationBatchPOStatusType;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersOrderInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersOrderProductInput;
import com.wayfair.registration.api.graphql.scalars.CustomDateTime;
import com.wayfair.registration.api.purchaseorder.dto.FullPurchaseOrderNumber;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class BulkRegistrationGraphQLToEntityMappingService {

  private static final Integer DEFAULT_STATUS_NEW = 0;
  private static final Integer DEFAULT_DOWNLOAD_ATTEMPTS_COUNT = 0;
  private final Integer batchSize;

  public BulkRegistrationGraphQLToEntityMappingService(
      @Value("${bulk-registration.batch-size}") Integer batchSize
  ) {
    this.batchSize = batchSize;
  }

  public BulkRegistration toBulkRegistration(
      SoOrderManagementRegisterOrdersInput registrationInput,
      Integer extranetUserId,
      Integer employeeId
  ) {
    return BulkRegistration.builder()
        .supplierId(registrationInput.getSupplierId())
        .extranetUserId(extranetUserId == null ? 0 : extranetUserId)
        .employeeId(employeeId == null ? 0 : employeeId)
        .readyForPickupDate(mapReadyForPickupDate(registrationInput.getOrders().get(0).getReadyForPickupDate()))
        .isCustomsDocumentNeeded(registrationInput.getShippingDocumentTypes().contains(CUSTOMS))
        .isManifestNeeded(registrationInput.getShippingDocumentTypes().contains(MANIFEST))
        .uccLabelNeeded(registrationInput.getShippingDocumentTypes().contains(UCC))
        .isPackingSlipNeeded(registrationInput.getShippingDocumentTypes().contains(PACKING_SLIP))
        .isShippingLabelNeeded(
            registrationInput.getShippingDocumentTypes().contains(SHIPPING_LABEL))
        .bolNeeded(registrationInput.getShippingDocumentTypes().contains(BILL_OF_LADING))
        .soLabelNeeded(registrationInput.getShippingDocumentTypes().contains(SAMPLE_ORDER_LABEL))
        .bulkRegistrationBatches(buildBulkRegistrationBatches(registrationInput.getOrders()))
        .createdAt(Timestamp.from(Instant.now()))
        .status(DEFAULT_STATUS_NEW)
        .downloadAttemptsCount(DEFAULT_DOWNLOAD_ATTEMPTS_COUNT)
        .isSingleRegistration(registrationInput.getIsSingleRegistration())
        .build();
  }

  private Timestamp mapReadyForPickupDate(CustomDateTime rfp) {
    return rfp != null ? Timestamp.valueOf(rfp.toLocalDateTime()) : null;
  }

  private Set<BulkRegistrationBatch> buildBulkRegistrationBatches(
      List<SoOrderManagementRegisterOrdersOrderInput> orders
  ) {
    Set<BulkRegistrationBatch> bulkRegistrationBatches = new HashSet<>();
    Set<BulkRegistrationBatchPO> bulkRegistrationBatchPOS = null;
    BulkRegistrationBatch bulkRegistrationBatch = null;

    for (int i = 0; i < orders.size(); i++) {
      if (i % batchSize == 0) {
        bulkRegistrationBatch = new BulkRegistrationBatch();
        bulkRegistrationBatches.add(bulkRegistrationBatch);
        bulkRegistrationBatchPOS = new HashSet<>();
        bulkRegistrationBatch.setBulkRegistrationBatchPOs(bulkRegistrationBatchPOS);
        bulkRegistrationBatch.setAttemptsCount((short) 0);
        bulkRegistrationBatch.setStatus((short) 0);
      }

      BulkRegistrationBatchPO bulkRegistrationBatchPO = toBulkRegistrationBatchPO(orders.get(i));
      bulkRegistrationBatchPO.setBulkRegistrationBatch(bulkRegistrationBatch);
      bulkRegistrationBatchPO.setCreatedAt(Timestamp.from(Instant.now()));
      bulkRegistrationBatchPOS.add(bulkRegistrationBatchPO);
    }

    return bulkRegistrationBatches;
  }

  private BulkRegistrationBatchPO toBulkRegistrationBatchPO(SoOrderManagementRegisterOrdersOrderInput orderInput) {
    Timestamp readyForPickupDate = mapReadyForPickupDate(orderInput.getReadyForPickupDate());
    return BulkRegistrationBatchPO.builder()
        .supplierId(orderInput.getWarehouseId())
        .status(BulkRegistrationBatchPOStatusType.NEW)
        .readyForPickupDate(readyForPickupDate)
        .shipClassId(orderInput.getShipClassId())
        .palletized(orderInput.getPalletization().getIsPalletized())
        .palletCount(getPalletCount(orderInput))
        .palletWeight(orderInput.getPalletization().getPalletWeight())
        .shipCarrierId(orderInput.getCarrierId())
        .purchaseOrder(getPONumber(orderInput.getFullPurchaseOrderNumber()))
        .replacementPartId(getReplacementPartId(orderInput.getFullPurchaseOrderNumber()).orElse(null))
        .bulkRegistrationBatchPOItems(
            toPOItems(orderInput.getOrderProducts(), orderInput.getReplacementParts()))
        .build();
  }

  private Short getPalletCount(SoOrderManagementRegisterOrdersOrderInput orderInput) {
    return orderInput.getPalletization().getPalletCount() != null ? orderInput.getPalletization()
        .getPalletCount()
        .shortValue() : null;
  }

  private Set<BulkRegistrationBatchPOItem> toPOItems(
      List<SoOrderManagementRegisterOrdersOrderProductInput> orderProducts,
      List<SoOrderManagementRegisterOrdersOrderProductInput> replacementParts
  ) {
    return Stream.of(Optional.ofNullable(orderProducts).orElse(Collections.emptyList()),
        Optional.ofNullable(replacementParts).orElse(Collections.emptyList())
    ).flatMap(Collection::stream).map(this::buildPOItem).collect(Collectors.toSet());
  }

  private BulkRegistrationBatchPOItem buildPOItem(SoOrderManagementRegisterOrdersOrderProductInput orderProductInput) {
    return BulkRegistrationBatchPOItem.builder()
        .orderProductId(String.valueOf(orderProductInput.getOrderProductId()))
        .partNumber(orderProductInput.getPartNumber())
        .cartonCount(orderProductInput.getPieceCount())
        .itemWeight(orderProductInput.getUnitWeight())
        .nmfc(orderProductInput.getNmfc())
        .freightClass(orderProductInput.getFreightClass())
        .createdAt(Timestamp.from(Instant.now()))
        .pieceType(orderProductInput.getPieceType() != null
            ? orderProductInput.getPieceType().toString()
            : null)
        .build();
  }

  private Integer getPONumber(String fullPO) {
    FullPurchaseOrderNumber fullPurchaseOrderNumber = new FullPurchaseOrderNumber(fullPO);
    return fullPurchaseOrderNumber.getPONumber();
  }

  private Optional<Integer> getReplacementPartId(String fullPO) {
    FullPurchaseOrderNumber fullPurchaseOrderNumber = new FullPurchaseOrderNumber(fullPO);
    return fullPurchaseOrderNumber.getRPId();
  }

}
