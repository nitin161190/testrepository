package com.wayfair.registration.api.bulkregistration.entity;

import java.sql.Timestamp;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@Table(name = "tblBulkRegistration", catalog = "csn_extranet_fulfillment")
public class BulkRegistration {

  @Id
  @Column(name = "BrID")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "BrStatus")
  private Integer status;

  @Column(name = "BrRfpDate")
  private Timestamp readyForPickupDate;

  @Column(name = "BrBatchesCount")
  private Integer batchesCount;

  @Column(name = "BrSortingOption")
  private Short sortingOption;

  @Column(name = "BrIsPackingSlipNeeded")
  private boolean isPackingSlipNeeded;

  @Column(name = "BrIsShippingLabelNeeded")
  private boolean isShippingLabelNeeded;

  @Column(name = "BrIsBOLNeeded")
  private boolean bolNeeded;

  @Column(name = "BrIsUCCLabelNeeded")
  private boolean uccLabelNeeded;

  @Column(name = "BrIsCustomsDocumentNeeded")
  private boolean isCustomsDocumentNeeded;

  @Column(name = "BrIsManifestNeeded")
  private boolean isManifestNeeded;

  @Column(name = "BrIsSingleRegistration")
  private boolean isSingleRegistration;

  @Column(name = "BrIsSOLabelNeeded")
  private boolean soLabelNeeded;

  @Column(name = "BrCreatedAt")
  private Timestamp createdAt;

  @Column(name = "BrSupplierId")
  private Integer supplierId;

  @Column(name = "BrEmpId")
  private Integer employeeId;

  @Column(name = "BrExUserId")
  private Integer extranetUserId;

  @Column(name = "BrConsolidatedFilename")
  private String consolidatedFilename;

  @Column(name = "BrDownloadAttemptsCount")
  private Integer downloadAttemptsCount;

  @OneToMany(mappedBy = "bulkRegistration", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
  private Set<BulkRegistrationBatch> bulkRegistrationBatches;

  public static BulkRegistrationBuilder builder() {
    return new CustomBulkRegistrationBuilder();
  }

  // this is needed so when we try to save this bulk registration object, as a parent to lots of
  // bulk registration batches, they will also be saved automatically correctly
  private static class CustomBulkRegistrationBuilder extends BulkRegistrationBuilder {

    @Override
    public BulkRegistration build() {
      BulkRegistration bulkRegistration = super.build();
      bulkRegistration.getBulkRegistrationBatches()
          .forEach(
              bulkRegistrationBatch -> bulkRegistrationBatch.setBulkRegistration(bulkRegistration));
      bulkRegistration.setBatchesCount(bulkRegistration.getBulkRegistrationBatches().size());
      return bulkRegistration;
    }
  }
}
