package com.wayfair.registration.api.bulkregistration.entity;

import java.sql.Timestamp;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@Table(name = "tblBulkRegistrationBatchPOItem", catalog = "csn_extranet_fulfillment")
public class BulkRegistrationBatchPOItem {

  @Id
  @Column(name = "BrbpiID")
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @ManyToOne
  @JoinColumn(name = "BrbpiBrbpID")
  @ToString.Exclude
  @EqualsAndHashCode.Exclude
  private BulkRegistrationBatchPO bulkRegistrationBatchPO;

  @Column(name = "BrbpiOpID")
  private String orderProductId;

  @Column(name = "BrbpiPartNumber")
  private String partNumber;

  @Column(name = "BrbpiCartonCount")
  private Integer cartonCount;

  @Column(name = "BrbpiItemWeight")
  private Double itemWeight;

  @Column(name = "BrbpiQuantity")
  private Integer quantity;

  @Column(name = "BrbpiCreatedAt")
  private Timestamp createdAt;

  @Column(name = "BrbpiUpdatedAt")
  private Timestamp updatedAt;

  @Column(name = "BrbpiPieceType")
  private String pieceType;

  @Column(name = "BrbpiNMFC")
  private String nmfc;

  @Column(name = "BrbpiFreightClass")
  private String freightClass;
}
