package com.wayfair.registration.api.labeldata;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(value = "label-data", url = "${label-data.url}")
public interface LabelDataClient {

  @PostMapping(value = "/api/cia/label-data/refresh")
  void refresh(LabelDataRefreshRequest request);

  @PostMapping(value = "/api/cia/label-data/history")
  List<LabelDataHistoryResponse> history(LabelDataHistoryRequest request);

}
