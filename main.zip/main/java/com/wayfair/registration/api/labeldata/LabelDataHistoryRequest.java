package com.wayfair.registration.api.labeldata;

import java.util.List;
import lombok.Value;

@Value
public class LabelDataHistoryRequest {

  List<String> shipmentIdentifiers;   //$fullPoNumbers
  boolean isLabelDataRequested = false;
  boolean latestOnly = true;
  boolean active = true;
}
