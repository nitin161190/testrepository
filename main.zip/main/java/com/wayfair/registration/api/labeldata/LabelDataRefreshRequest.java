package com.wayfair.registration.api.labeldata;

import lombok.Value;

@Value
public class LabelDataRefreshRequest {

  String shipmentIdentifier;

}
