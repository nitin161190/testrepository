package com.wayfair.registration.api.domain;

import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ShipClass {
  SMALL_PARCEL(1, "SP"),
  TRUCK_FREIGHT(2, "LTL"),
  WHITE_GLOVE(3, "WG"),
  TRUCK_LOAD(4, "LTL");

  public static final Set<ShipClass> LARGE_PARCEL_SHIP_CLASSES = Set.of(
      TRUCK_FREIGHT,
      WHITE_GLOVE,
      TRUCK_LOAD
  );

  private final int shipClassId;
  private final String shipClassName;

  public static ShipClass valueOf(int shipClassId) {
    for (ShipClass e : values()) {
      if (e.shipClassId == shipClassId) {
        return e;
      }
    }

    return null;
  }
}
