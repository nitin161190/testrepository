package com.wayfair.registration.api.domain;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.Getter;
import org.apache.commons.lang3.math.NumberUtils;

@Getter
public class PurchaseOrderIdentifier {

  /** The regex used is based on <a href="https://github.csnzoo.com/shared/wgcp-return-rp-milestone-publisher/blob/main/DomainEntities/Entities/PurchaseOrder.cs#L9">
   *  wgcp-return-rp-milestone-publisher PurchaseOrder class</a>. */
  private static final Pattern FULL_PO_NUMBER_PATTERN = Pattern.compile("^(?<prefix>[A-Z]+)(?<number>[0-9]+)"
      + "(?:(?:-R-|R|-R|FIX|REPL|REP)(?<replacementPartId>[0-9]+))?(?<return>RA|R|C|RPT|-RPT)?$");

  private final String storePrefix;
  private final Integer purchaseOrderNumber;
  private final Integer replacementPartId;

  public PurchaseOrderIdentifier(String fullPONumber) {
    Matcher matcher = FULL_PO_NUMBER_PATTERN.matcher(fullPONumber);

    if (!matcher.find()) {
      throw new IllegalArgumentException("Cannot parse provided fullPONumber: " + fullPONumber);
    }

    this.storePrefix = matcher.group("prefix");
    this.purchaseOrderNumber = NumberUtils.createInteger(matcher.group("number"));
    this.replacementPartId = NumberUtils.createInteger(matcher.group("replacementPartId"));
  }

  public boolean isReplacement() {
    return replacementPartId != null;
  }
}
