package com.wayfair.registration.api.domain;

import java.util.Arrays;
import java.util.Set;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum SubEntityRegion {

  USA(1),
  UK(2),
  GERMANY(3),
  AUSTRALIA(4),
  FRANCE(5),
  CANADA(6),
  IRELAND(7);

  private static final Set<SubEntityRegion> NORTH_AMERICAN_SUBENTITIES = Set.of(
      USA, CANADA
  );

  private final int supplierSubEntity;

  public static SubEntityRegion fromSupplierSubEntity(int supplierSubEntity) {
    return Arrays.stream(SubEntityRegion.values())
        .filter(value -> value.supplierSubEntity == supplierSubEntity)
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Could not find SubEntityRegion based on supplierSubEntity "
            + supplierSubEntity));
  }

  public static boolean isNorthAmericanSubEntity(SubEntityRegion subEntityRegion) {
    return NORTH_AMERICAN_SUBENTITIES.contains(subEntityRegion);
  }
}
