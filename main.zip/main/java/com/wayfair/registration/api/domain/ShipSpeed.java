package com.wayfair.registration.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ShipSpeed {
  METHOD_GROUND(1),
  METHOD_SMALL_PARCEL_COURIER(65);

  int shipSpeedId;

}
