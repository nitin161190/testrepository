package com.wayfair.registration.api.domain;

import lombok.Getter;

@Getter
public enum Failure {

  SHIP_CLASS_MISSING(1, "errorShipClassMissing"),
  ORDER_PRODUCT_NO_WEIGHT(2, "errorPoItemHasNoWeight"),
  READY_FOR_PICKUP_DATE_IN_THE_PAST(7, "errorInvalidInputRfpDate"),
  FULL_PO_NUMBER_MISSING(100, "errorFullPoNumberMissing"),
  FULL_PO_NUMBER_MALFORMED(101, "errorFullPoNumberMalformed"),
  SUPPLIER_MISSING(102, "errorSupplierIdMissing"),
  CARRIER_MISSING(103, "errorCarrierIdMissing"),
  EXTRANET_USER_AND_EMPLOYEE_MISSING(104, "errorExtranetUserIdAndEmployeeIdMissing"),
  SHIPPING_DOCUMENTS_TYPES_EMPTY(106, "errorShippingDocumentsTypesEmpty"),
  INVALID_TOTAL_PIECE_COUNT(107, "errorInvalidRequestMissingTotalPieceCount"),
  ORDER_PRODUCTS_EMPTY(200, "errorOrderProductsEmpty"),
  ORDER_PRODUCT_PART_NUMBER_MISSING(201, "errorOrderProductPartNumberMissing"),
  ORDER_PRODUCT_PIECE_COUNT_MISSING(202, "errorOrderProductPieceCountMissing"),
  ORDER_PRODUCT_REF_PROD_ID_MISSING(203, "errorOrderProductRefProdIDMissing"),
  PALLETIZED_MISSING(300, "errorPalletizedMissing"),
  PALLETIZED_INVALID_PALLET_DATA(301, "errorPalletizedInvalidData"),
  COULD_NOT_FIND_PURCHASE_ORDER(401, "errorPODoesNotBelongToSupplier"),
  PENDING_CANCELLATION_ALERT(402, "errorPOHasPendingCancellationAlert"),
  HAS_CASTLE_GATE_ORDER(403, "errorPOHasCastleGateOrder");

  private final int failureCode;
  private final String failureTranslationKey;

  Failure(int failureCode, String failureTranslationKey) {
    this.failureCode = failureCode;
    this.failureTranslationKey = failureTranslationKey;
  }
}
