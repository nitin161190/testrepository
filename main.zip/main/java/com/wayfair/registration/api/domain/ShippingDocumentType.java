package com.wayfair.registration.api.domain;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum ShippingDocumentType {

  @JsonProperty("PackingSlip")
  PACKING_SLIP,

  @JsonProperty("ShippingLabel")
  SHIPPING_LABEL,

  @JsonProperty("BOL")
  BOL,

  @JsonProperty("UCC")
  UCC,

  @JsonProperty("Customs")
  CUSTOMS,

  @JsonProperty("Manifest")
  MANIFEST,

  @JsonProperty("SampleOrderLabel")
  SAMPLE_ORDER_LABEL
}
