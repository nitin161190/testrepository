package com.wayfair.registration.api.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum SupplierLabelCountType {
  ONE_LABEL_PER_ORDER(1),
  ONE_LABEL_PER_BOX(2),
  ;

  private final int value;
}
