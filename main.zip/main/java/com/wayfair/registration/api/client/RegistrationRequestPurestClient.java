package com.wayfair.registration.api.client;

import com.wayfair.registration.api.purchaseorder.dto.RegistrationDataPurestRequest;
import com.wayfair.registration.api.purchaseorder.dto.RegistrationPo;
import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "registration-request-purest-client", url = "${monolith.url}")
public interface RegistrationRequestPurestClient {

  @PostMapping(
      value = "/purest/extranet/registration_request",
      consumes = MediaType.APPLICATION_JSON_VALUE)
  List<RegistrationPo> registrationData(RegistrationDataPurestRequest request);
}
