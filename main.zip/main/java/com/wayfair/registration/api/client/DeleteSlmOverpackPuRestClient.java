package com.wayfair.registration.api.client;

import com.wayfair.registration.api.dto.DeleteSlmOverpackRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(name = "delete-slm-overpack-purest-client", url = "${monolith.url}")
public interface DeleteSlmOverpackPuRestClient {

  @PostMapping(
      value = "/purest/extranet/delete_slm_overpack",
      consumes = MediaType.APPLICATION_JSON_VALUE)
  void deleteShippingLoadManifestOverpack(DeleteSlmOverpackRequest request);
}
