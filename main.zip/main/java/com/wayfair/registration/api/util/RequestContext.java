package com.wayfair.registration.api.util;

import static lombok.AccessLevel.PRIVATE;

import java.util.HashMap;
import java.util.Map;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = PRIVATE)
public class RequestContext {

  private static final ThreadLocal<Map<String, Object>> localRequestStore = ThreadLocal.withInitial(HashMap::new);

  public static void store(String name, Object value) {
    localRequestStore.get().put(name, value);
  }

  public static Map<String, Object> get() {
    return localRequestStore.get();
  }

  public static void clear() {
    localRequestStore.remove();
  }
}
