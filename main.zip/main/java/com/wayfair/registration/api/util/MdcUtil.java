package com.wayfair.registration.api.util;

import static java.util.Collections.emptyList;
import static lombok.AccessLevel.PRIVATE;
import static org.springframework.util.CollectionUtils.isEmpty;

import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersInput;
import com.wayfair.registration.api.graphql.generated.types.SoOrderManagementRegisterOrdersOrderInput;
import com.wayfair.registration.api.purchaseorder.dto.BulkPurchaseOrderRefreshInput;
import com.wayfair.registration.api.purchaseorder.dto.OrderInput;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.NoArgsConstructor;
import org.slf4j.MDC;

@NoArgsConstructor(access = PRIVATE)
public class MdcUtil {

  static final String FULL_PO_NUMBER = "full-po-number";
  static final String FULL_PO_NUMBERS = "full-po-numbers";
  public static final String BULK_REGISTRATION_ID = "bulk-registration-id";

  public static void init(OrderInput orderInput) {
    MDC.put(FULL_PO_NUMBER, orderInput.getFullPoNumber());
  }

  public static void init(String fullPONumber) {
    MDC.put(FULL_PO_NUMBER, fullPONumber);
  }

  public static void init(SoOrderManagementRegisterOrdersInput input) {
    MDC.put(FULL_PO_NUMBERS, String.valueOf(graphQLInputToFullPoNumbers(input)));
  }

  public static void initWithOrderInputs(List<OrderInput> orderInputs) {
    MDC.put(FULL_PO_NUMBERS, String.valueOf(orderInputsToFullPoNumbers(orderInputs)));
  }

  public static void initWithRefreshInputs(List<BulkPurchaseOrderRefreshInput> bulkPurchaseOrderRefreshInputs) {
    MDC.put(FULL_PO_NUMBERS, String.valueOf(refreshInputsToFullPoNumbers(bulkPurchaseOrderRefreshInputs)));
  }

  private static List<String> refreshInputsToFullPoNumbers(
      List<BulkPurchaseOrderRefreshInput> bulkPurchaseOrderRefreshInputs) {
    if (isEmpty(bulkPurchaseOrderRefreshInputs)) {
      return emptyList();
    } else {
      return bulkPurchaseOrderRefreshInputs.stream()
          .map(BulkPurchaseOrderRefreshInput::getFullPurchaseOrderNumber)
          .filter(Objects::nonNull)
          .collect(Collectors.toList());
    }
  }

  private static List<String> orderInputsToFullPoNumbers(List<OrderInput> orderInputs) {
    if (isEmpty(orderInputs)) {
      return emptyList();
    } else {
      return orderInputs.stream()
          .map(OrderInput::getFullPoNumber)
          .filter(Objects::nonNull)
          .collect(Collectors.toList());
    }
  }

  private static List<String> graphQLInputToFullPoNumbers(SoOrderManagementRegisterOrdersInput input) {
    if (input == null || isEmpty(input.getOrders())) {
      return emptyList();
    } else {
      return input.getOrders().stream()
          .map(SoOrderManagementRegisterOrdersOrderInput::getFullPurchaseOrderNumber)
          .filter(Objects::nonNull)
          .collect(Collectors.toList());
    }
  }
}
