package com.wayfair.registration.api.util;

import static lombok.AccessLevel.PRIVATE;

import java.util.Map;
import java.util.Optional;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = PRIVATE)
public class MessageFormatter {

  public static String formatPoMessage(String message, Map<String, String> messageArguments) {

    if (message != null && messageArguments != null) {
      for (var messageArgument : messageArguments.entrySet()) {
        message = message.replace("{" + messageArgument.getKey() + "}", Optional.ofNullable(
            messageArgument.getValue()).orElse("null"));
      }
    }

    return message;
  }
}
