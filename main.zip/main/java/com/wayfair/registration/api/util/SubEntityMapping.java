package com.wayfair.registration.api.util;

import java.util.Optional;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum SubEntityMapping {

  /**
   * These subentities are coming from csn_order.dbo.tblSubEntity.
   */
  USA(1),
  UK(2),
  GERMANY(3),
  AUSTRALIA(4),
  FRANCE(5),
  CANADA(6),
  IRELAND(7);

  private int subEntityId;

  private static final Set<SubEntityMapping> EUROPE_SUB_ENTITIES = Set.of(UK, GERMANY,
      FRANCE, IRELAND
  );
  private static final Set<SubEntityMapping> EUROPEAN_UNION_SUB_ENTITIES = Set.of(GERMANY,
      FRANCE, IRELAND
  );
  private static final Set<SubEntityMapping> NORTH_AMERICA_SUB_ENTITIES = Set.of(USA,
      CANADA
  );

  public static Optional<SubEntityMapping> valueOf(int subEntityId) {
    for (SubEntityMapping e : values()) {
      if (e.subEntityId == subEntityId) {
        return Optional.of(e);
      }
    }

    return Optional.empty();
  }

  public static boolean isNorthAmerica(int subEntityId) {
    Optional<SubEntityMapping> subEntity = valueOf(subEntityId);
    return subEntity.isPresent() && NORTH_AMERICA_SUB_ENTITIES.contains(subEntity.get());
  }

  public static boolean isEurope(int subEntityId) {
    Optional<SubEntityMapping> subEntity = valueOf(subEntityId);
    return subEntity.isPresent() && EUROPE_SUB_ENTITIES.contains(subEntity.get());
  }

  public static boolean isEuropeanUnion(int subEntityId) {
    Optional<SubEntityMapping> subEntity = valueOf(subEntityId);
    return subEntity.isPresent() && EUROPEAN_UNION_SUB_ENTITIES.contains(subEntity.get());
  }
}
